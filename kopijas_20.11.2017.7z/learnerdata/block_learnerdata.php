<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Newblock block caps.
 *
 * @package    block_newblock
 * @copyright  Vija Vagale <vija.vagale@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 
//man ir nodefinēts
//$_SESSION['instance']=$this->instance->id; (apm. 120lpp)
//tas redzams visos failos
 
 
defined('MOODLE_INTERNAL') || die();
global $CFG;
global $PAGE;
global $COURSE;
global $DB;

class block_learnerdata extends block_base {

    function init() {
        $this->title = get_string('learnerdata', 'block_learnerdata');
    }

function get_content() {
        global $CFG, $OUTPUT;
		global $USER, $DB;
	

        if ($this->content !== null) {
            return $this->content;
        }

        if (empty($this->instance)) {
            $this->content = '';
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->items = array();
        $this->content->icons = array();
 	
		//----------------------------------------------------------
        // user/index.php expect course context, so get one if page has module context.
        $currentcontext = $this->page->context->get_course_context(false);

        if (! empty($this->config->text)) {
            $this->content->text = $this->config->text;
        }

        $this->content = '';
        if (empty($currentcontext)) {
            return $this->content;
        }
        if ($this->page->course->id == SITEID) {
            $this->context->text .= "site context";
        }

        if (! empty($this->config->text)) {
            $this->content->text .= $this->config->text;
        }
		
		 $this->content->items[] = html_writer::tag('a', 'Menu Option 1');
		 
//dazi parametri
$_SESSION['instance']=$this->instance->id;
$_SESSION['courseid']=$this->page->course->id; 
$instanceid=$this->instance->id;
$courseid=$this->page->course->id;
$course_grupas_ir = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
					if (!empty($course_grupas_ir)) {	$cgr="Exist";} else {$cgr="Not Exist";}
$adscenarios_ir = 0;//$DB->get_records('v_scenario',array('courseid'=>$courseid)); 
					if (!empty($adscenarios_ir)) {	$ad="Exist";} else {$ad="Not Exist";}
$userpeddata= $DB->get_records('v_user_pedagogical_data', array('courseid'=>$courseid));
$upds=sizeof($userpeddata);
$testsanswers= $DB->get_records('v_tests_answers', array('courseid'=>$courseid));
$ta=sizeof($testsanswers);
$vark3= $DB->get_records('v_user_artefact_all', array('source'=>'vark3'));
$vark3s=sizeof($vark3);
$vark2= $DB->get_records('v_user_artefact_all', array('source'=>'vark2'));
$vark2s=sizeof($vark2);
$vark1= $DB->get_records('v_user_artefact_all', array('source'=>'vark1'));
$vark1s=sizeof($vark1);
//$cgroup= $DB->get_records('v_clg', array('courseid'=>$courseid));
//$cgroups=sizeof($cgroup);

 
$this->content->text="For students</br>";
$this->content->text.='<ol>
 <li>Testing Learning Styles 
	<ul>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/testi/data/course_data_test.php">Course Data</a> (mandatory, amount='.$upds.')'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/testi/lstyles/vark3/test1.php">VARK3</a> (mandatory, amount='.$vark3s.')'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/testi/lstyles/vark2/test1.php">VARK2</a> (amount='.$vark2s.')'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/testi/lstyles/vark1/test1.php">VARK1</a> (amount='.$vark1s.')'.'</li>
	</ul></li>
 <li>Course Evaluation(after course finishing)
	<ul>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/testi/evaluation/course_evaluation.php">Course Evaluation</a> (amount='.$ta.')'.'</li>	
	</ul>
</ol>  ';
$this->content->text.="<br>For teachers</br>";
//labotais
//bija iznemu
//<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/assign_lg.php">Assign LG</a>'.'</li>
//<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/update_tables.php">Experiment</a>'.'</li>

$this->content->text.='<ol>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/pazimes.php">Create Group, Scenario</a>'.' ('.$cgr.')'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/test_result.php">Update Students LS</a>'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/evaluation_results.php">Course Evaluation Results</a>'.'</li>
	<li><a href="'.$CFG->wwwroot.'/blocks/learnerdata/work/student_information.php">Information about Student</a>'.'</li>
						</ol>  ';

/*	$this->content->text.='<ol>
	<li>'."<a href=\"".$CFG->wwwroot."/blocks/learnerdata/work/pazimes.php?instanceid=".$this->instance->id."\">Create Group</a>".'</li*/

		//$this->content->text.=$this->title;
		//$this->content->text.=" id=".$this->instance->id;
		//$this->content->text.=" cid= ".$this->page->course->id;
		
		return $this->content;
    }
//<a href="http://www.w3schools.com/">Visit W3Schools</a>//
    // my moodle can only have SITEID and it's redundant here, so take it away
    public function applicable_formats() {
        return array('all' => false,
                     'site' => true,
                     'site-index' => true,
                     'course-view' => true, 
                     'course-view-social' => false,
                     'mod' => true, 
                     'mod-quiz' => false);
    }

    public function instance_allow_multiple() {
          return true;
    }

    //function has_config() {return true;}

    /*public function cron() {
            mtrace( "Hey, my cron script is running" );
             
                 // do something
                  
                      return true;
    }*/
}
