<?php

function xmldb_block_learnerdata_upgrade($oldversion) {
    global $DB;
    $dbman = $DB->get_manager();

    /// Add a new column newcol to the mdl_myqtype_options
 

	  if ($oldversion < 2017052300) {
		    // Define field courseid to be added to v_clg_members.
        $table = new xmldb_table('v_clg_members');
        $field = new xmldb_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null, 'group_number');

        // Conditionally launch add field courseid.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // Learnerdata savepoint reached.
        upgrade_block_savepoint(true, 2017052300, 'learnerdata');
/*
	   // Define field id to be added to v_tests_answers.
        $table = new xmldb_table('v_tests_answers');
        $field = new xmldb_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null, null);
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
		$field = new xmldb_field('time', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'id');
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
		$field = new xmldb_field('courseid', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'time');
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
		$field = new xmldb_field('userid', XMLDB_TYPE_INTEGER, '10', null, null, null, null, 'courseid');
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
		$field = new xmldb_field('answers', XMLDB_TYPE_TEXT, null, null, null, null, null, 'userid');
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
         $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));
		if (!$dbman->field_exists($table, $field)) {$dbman->add_field($table, $field);}
		// Learnerdata savepoint reached.
        upgrade_block_savepoint(true, 2017012803, 'learnerdata');  
	  //-----------------------
	  

        	  //-----------------
        // Define table v_adaptation_features_values to be created.
        $table = new xmldb_table('v_adaptation_features_values');

        // Adding fields to table v_adaptation_features_values.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('featureid', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
        $table->add_field('value', XMLDB_TYPE_CHAR, '255', null, null, null, null);

        // Adding keys to table v_adaptation_features_values.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // Conditionally launch create table for v_adaptation_features_values.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

//---------------------------------------------------------------
          // Define table v_clg_description to be created.
        $table = new xmldb_table('v_clg_description');

        // Adding fields to table v_clg_description.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('clgid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('adaptation_features_valueid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);

        // Adding keys to table v_clg_description.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // Conditionally launch create table for v_clg_description.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

//------------------------------------------
		 // Define table v_adaptation_features to be created.
        $table = new xmldb_table('v_adaptation_features');

        // Adding fields to table v_adaptation_features.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('feature', XMLDB_TYPE_CHAR, '45', null, null, null, null);

        // Adding keys to table v_adaptation_features.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // Conditionally launch create table for v_adaptation_features.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        } 

//----------------------------------------------------------------------------
		 // Define table v_adaptation_scenario to be created.
        $table = new xmldb_table('v_adaptation_scenario');

        // Adding fields to table v_adaptation_scenario.
        $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
        $table->add_field('clgid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, null);
        $table->add_field('theory_basic_content', XMLDB_TYPE_CHAR, '45', null, null, null, null);
        $table->add_field('theory_explanation', XMLDB_TYPE_INTEGER, '1', null, null, null, null);
        $table->add_field('practice_exercise', XMLDB_TYPE_CHAR, '45', null, null, null, null);
        $table->add_field('assessment_task', XMLDB_TYPE_CHAR, '45', null, null, null, null);
        $table->add_field('assessment_quiz', XMLDB_TYPE_CHAR, '45', null, null, null, null);

        // Adding keys to table v_adaptation_scenario.
        $table->add_key('primary', XMLDB_KEY_PRIMARY, array('id'));

        // Conditionally launch create table for v_adaptation_scenario.
        if (!$dbman->table_exists($table)) {
            $dbman->create_table($table);
        }

 upgrade_block_savepoint(true, 2017012800, 'learnerdata');       
*/
    }
	
	
    return true;
}
?>