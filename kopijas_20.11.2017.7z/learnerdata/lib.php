<?php
//echo "AAAAAAAAA";

//global $CFG;
//global $COURSE;
//global $DB;
//global $USER;
//require_once("../../config.php") ;
//require_login();

function user_rights(){
//kurss
///1. lomas id meklesana
$s=	'manager';		
$rez = $DB->get_records_menu('role',array('shortname'=>$s),'id','shortname,id'); 
echo "manid= ".$rez[$s];
$s=	'coursecreator';		
$rez = $DB->get_records_menu('role',array('shortname'=>$s),'id','shortname,id'); 
echo "ccid= ".$rez[$s];
$s=	'editingteacher';		
$rez = $DB->get_records_menu('role',array('shortname'=>$s),'id','shortname,id'); 
echo "etid= ".$rez[$s];
$s=	'teacher';		
$rez = $DB->get_records_menu('role',array('shortname'=>$s),'id','shortname,id'); 
echo "tid= ".$rez[$s];
//useram kada loma
//(SELECT userid FROM {$CFG->prefix}role_assignments WHERE (roleid='$role_student'))))
$userid=$USER->id;
echo "<br>uid = ".$userid;
$rez = $DB->get_records_menu('role_assignments',array('userid'=>$userid),'id','userid,roleid'); 
echo "uis= ".($rez[$userid]);

//return true;
}

?>