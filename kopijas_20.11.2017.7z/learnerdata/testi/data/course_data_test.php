<meta charset='utf-8'>
<?php
global $CFG;
global $COURSE;
global $DB;
require_once("../../../../config.php") ;
require_once("../../my_lib.php") ;

$instanceid=$_SESSION['instance'];

if(isset($_POST['submit']))
{
include('course_data_result.php');
exit();
}
?>
<div>
		<h1>Tests par kursa datiem</h1>

<b>Lūdzu nesteidzieties un apdomājiet atbildes!</b><br/>
	
		<form action="" method="post" id="quiz">

            <ol>
   				<li style="padding: 0px;">              
                    <b>Vai Jums ir priekšzināšanas apgūstāmajā kursā:</b>                   
                    <div><input type="radio" name="question-25-answers" id="question-25-answers-A" value="n" />
                        <label for="question-25-answers-A">A) Nav</label></div>
                    <div><input type="radio" name="question-25-answers" id="question-25-answers-B" value="y" />
                        <label for="question-25-answers-B">B) Ir</label></div>         
                </li><br />
				<li style="padding: 0px;">              
                    <b>Līdz kādai maksimālai atzīmi Jūs izvēlētos apgūt šo kursu (kursā uzdevumi un testi būs atbilstoši izvēlētajam līmenim)</b>                   
                    <div><input type="radio" name="question-26-answers" id="question-26-answers-A" value="e" />
                        <label for="question-26-answers-A">A) Vienkāršajā līmenī (vērtējums būtu līdz maksimālai atzīmei 6)</label></div>
                    <div><input type="radio" name="question-26-answers" id="question-26-answers-B" value="m" />
                        <label for="question-26-answers-B">B) Vidējā līmenī (vērtējums būtu līdz maksimālai atzīmei 8)</label></div>  
					<div><input type="radio" name="question-26-answers" id="question-26-answers-C" value="d" />
                        <label for="question-26-answers-C">C) Augstākajā līmenī (vērtējums būtu līdz maksimālai atzīmei 10)</label></div> 
                </li><br />
				<li style="padding: 0px;">
				<b>Jūsu dzimums: </b><br/>
				<div><input type="radio" name="dz" id="dzf" value="f" />
                        <label for="dzf">A) Sieviešu </label></div>
				<div><input type="radio" name="dz" id="dzm" value="m" />
                        <label for="dzm">B) Vīriešu</label></div> </li>
               </ol> 
            

<fieldset class="date"> 
  <legend><b>Ievadiet savu dzimšanas datumu </b></legend>
<label for="day_start">Diena</label> 
  <select id="day_start" 
          name="day_start" /> 
    <option>1</option>       
    <option>2</option>       
    <option>3</option>       
    <option>4</option>       
    <option>5</option>       
    <option>6</option>       
    <option>7</option>       
    <option>8</option>       
    <option>9</option>       
    <option>10</option>       
    <option>11</option>       
    <option>12</option>       
    <option>13</option>       
    <option>14</option>       
    <option>15</option>       
    <option>16</option>       
    <option>17</option>       
    <option>18</option>       
    <option>19</option>       
    <option>20</option>       
    <option>21</option>       
    <option>22</option>       
    <option>23</option>       
    <option>24</option>       
    <option>25</option>       
    <option>26</option>       
    <option>27</option>       
    <option>28</option>       
    <option>29</option>       
    <option>30</option>       
    <option>31</option>       
  </select>   
  <label for="month_start">Mēnesis</label> 
  <select id="month_start" 
          name="month_start" /> 
    <option>Janvāris</option>       
    <option>Februāris</option>       
    <option>Marts</option>       
    <option>Aprīlis</option>       
    <option>Maijs</option>       
    <option>Jūnijs</option>       
    <option>Jūlijs</option>       
    <option>Augusts</option>       
    <option>Septembris</option>       
    <option>Oktobris</option>       
    <option>Novembris</option>       
    <option>Decembris</option>       
  </select>  
   
  <label for="year_start">Gads</label> 
  <input type="textbox" name="year_start" style="width:40px"></input>
  
</fieldset> 

</br>

<input type="submit" name="submit" value="Iesniegt datus" />
			</form>
		</div>
	