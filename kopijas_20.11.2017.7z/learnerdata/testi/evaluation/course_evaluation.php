<meta charset='utf-8'>

<h2>&nbsp;&nbsp;&nbsp;&nbsp;E-studiju kursu novērtēšana</h2>
<?php
global $CFG;
global $COURSE;
global $DB;
global $USER; 
require_once("../../../../config.php") ;
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;

//-------------------- pārbauda vai ir ieraksts db tabulaa 	v_user_artefact_type vai pievieno jauno testa nosaukumu 
//definee klasi
$testname='courseevaluation';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= 'courseevaluation';
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}

$artefacttypeid=$res[$testname];
//izvelk jau eksistejosos datus
$sql="SELECT
ta.id
	FROM
		 mdl_v_tests_answers ta
	WHERE
		ta.artefacttypeid='$artefacttypeid' and
		ta.courseid = '$courseid' and
		ta.userid = '$userid'
		ORDER BY ta.id";
$rez=array();			
$rez = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($rez);
//echo "</pre>";

if (!empty($rez))
{ echo "</br>Jūs šo testu jau esat veicis agrāk, tāpēc ieraksts datu bāzē netiks veikts!";
echo "<a href='javascript:window.history.go(-1);'><br/>Atpakaļ uz Kursu</a>";
die();
}			
			else
{	
//sakuma dati
//$is_answer=0; 
$atb_tek_skaits1d=0;
$atb_tek_skaits2d=0;
$pdala_kop_skaits=8;
$odala_kop_skaits=46;
$kop_skaits=$pdala_kop_skaits+$odala_kop_skaits;
$atbildes=array();
//------------------------------------------------------------------------
//vāc atbildes un skaita, cik to ir 1.daļā un 2.daļā, tad sasummē
if(isset($_POST['submit']))
{
	//1.daļa
for ($i=1; isset($_POST['a'.$i]) && $i<=$pdala_kop_skaits ; $i++)
  { 
  $answer = $_POST['a'.$i];
  //echo "<br/>1.daļa ".$i." jaut.atbilde= ".$answer;
  array_push($atbildes,$answer);
  $atb_tek_skaits1d++;
    }	

	//2.daļa
for ($i=1; $i<=$odala_kop_skaits; $i++)
  { 
	for ($j=1;isset($_POST['b'.$i.$j]) && $j<=2; $j++){
		$answer = $_POST['b'.$i.$j];
		//echo "<br/>2.daļa atbilde= ".$answer;
	array_push($atbildes,$answer);
	$atb_tek_skaits2d++;
	}
 }
//}//if 
//echo "<pre>";	
//print_r($atbildes);
//echo "</pre>";

//echo "<br>tek skaits= ".$atb_tek_skaits;
  if ($atb_tek_skaits1d+$atb_tek_skaits2d!=$pdala_kop_skaits+$odala_kop_skaits*2)
  { echo "<b>Lūdzu aizpildiet uzmanīgāk!<Br/>Nav ievadītas atbildes uz vienu vai vairākiem jautājumiem!</b>";
	if ($atb_tek_skaits1d!=$pdala_kop_skaits) echo "<br/>Nav ievadītas visas atbildes 1. daļā";
	if ($atb_tek_skaits2d!=$odala_kop_skaits) echo "<br/>Nav ievadītas visas atbildes 2. daļā";
	$raadiitjaut=0;
	echo "<br/><br/>";
	echo "<a href='javascript:history.back(-1);'>Atpakaļ uz testu</a>";
	die();}
  else{
	  //ierakstiit db
 //------------------------------------------------------------- 
/*$sql="SELECT
			ta.id
			FROM
				 mdl_v_tests_answers ta
			WHERE
			ta.artefacttypeid='$artefacttypeid' and
			ta.courseid = '$courseid' and
			ta.userid = '$userid'
			ORDER BY ta.id";
$result=array();			
$rez = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($rez);
//echo "</pre>";*/

//if (empty($rez))
	//	{
		//ierakstiisana db
		//------------		ieraksta tabulaa			v_tests_answers-----
		$atb_string=implode("", $atbildes);
		$record = new stdClass();
		$record->artefacttypeid= $artefacttypeid;
		$record->time= time();
		$record->courseid= $courseid;
		$record->userid= $userid;
		$record->answers= $atb_string;
		$DB->insert_record('v_tests_answers', $record);
		echo "<br/>Paldies par atbildēm! Dati tika ierakstīti datu bāzē!";
		echo "<a href='javascript:window.history.go(-2);'><br/>Atpakaļ uz Kursu</a>";
		//else echo "</br>Jūs šo testu jau esat veicis agrāk, tāpēc ieraksts datu bāzē netika veikts!";*/
echo "</br></br>";		
die();	
		}//else atbilzu pietiek
  
} //if post masiivs
}//ja bija tukss
?>
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<div>Lūdzu Jūs izteikt savu viedokli, aizpildot aptaujas anketu, kura sastāv no 1. un 2. daļas.<br/>
1. daļā ir 8 jautājumi, 2. daļā ir 46 jautājumi.<br/><br/>
Aptaujas rezultāti tiks izmantoti zinātniskajam pētījumam kursa uzlabošanai.<div> 
<b>Lūdzu nesteidzieties un apdomājiet atbildes!</b><br/><br/>
<form action=""  method="post" id="cevaluation">
<table border="0" cellpadding="6" width="80%">
<tr>
<td></td>
<td>
<h3 style="background-color:#DCDCDC">1. daļa. Informācija par respondentu:</h3>

<b>1. Jūsu dzimums:</b><br />
	<div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a1" id="a11" value="1" />
     <label for="a11">vīriešu</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a1" id="a12" value="2" />
     <label for="a12">sieviešu</label></div>
	 <br/>
<b>2. Jūsu vecums (pilni gadi):</b><br />
	<div>&nbsp;&nbsp;&nbsp;&nbsp;
	<select id="gadi" name="a2"/>    
    <option>17</option>       
    <option>18</option>       
    <option>19</option>       
    <option selected>20</option>       
    <option>21</option>       
    <option>22</option>       
    <option>23</option>       
    <option>24</option>       
    <option>25</option>       
    <option>26</option>       
    <option>27</option>       
    <option>28</option>       
    <option>29</option>       
    <option>30</option>             
  </select> </div>  
<br/>
<b>3. Jūsu izglītība:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a3" id="a31" value="1" />
     <label for="a31">vidējā vispārējā izglītība </label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a3" id="a32" value="2" />
     <label for="a32">vidējā profesionālā izglītība</label></div>
	 <br/>
<b>4. Apgūstāmā izglītības programma:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a4" id="a41" value="1" />
     <label for="a41">bakalaura</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a4" id="a42" value="2" />
     <label for="a42">maģistrantūras</label></div>
	 <br/>	 
<b>5. Studiju gads:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a5" id="a51" value="1" />
     <label for="a51">1. kurss</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a5" id="a52" value="2" />
     <label for="a52">2. kurss</label></div>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a5" id="a53" value="3" />
     <label for="a53">3. kurss</label></div>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a5" id="a54" value="4" />
     <label for="a54">4. kurss</label></div>
	 <br/>	
<b>6. Cik ilgi Jūs jau izmantojat e-studiju vadības sistēmu Moodle:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a6" id="a61" value="1" />
     <label for="a61">mazāk nekā 1 gadu</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a6" id="a62" value="2" />
     <label for="a62">no 1 - 3 gadiem</label></div>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a6" id="a63" value="3" />
     <label for="a63">vairāk nekā 4 gadus</label></div>
	 <br/>	
<b>7. Vai esat kādreiz lietoj-is/usi citas e-studiju vadības sistēmas:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a7" id="a71" value="1" />
     <label for="a71">jā</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a7" id="a72" value="2" />
     <label for="a72">nē</label></div>
	 <br/>
<b>8. Kā Jūs vērtējat savu IT (informāciju tehnoloģiju) līmeni:</b><br/>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a8" id="a81" value="1" />
     <label for="a81">augsts</label></div>
     <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a8" id="a82" value="2" />
     <label for="a82">vidējs</label></div>
	 <div>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="a8" id="a83" value="3" />
     <label for="a83">zems</label></div>
	 <br/>
</td></tr>
<tr><td></td><td></td></tr>
<tr><td></td>
<td><h3 style="background-color:#DCDCDC">2. daļa. E-studiju kursu novērtēšana:</h3>
<div>Ar punktiem novērtējiet zemāk minētos apgalvojumus gan <b>neadaptīva kursa</b>, gan <b>adaptīva kursa</b> gadījumā, izmantojot sekojošu skalu:</div></td></tr>
<tr><td></td>
<td>
	<table frame="box">
	<tr ><td><b>&nbsp;&nbsp;1 - pilnībā nepiekrītu,</b></td>
	<td><b>&nbsp;&nbsp;2 - nepiekrītu,</b></td>
	<td><b>&nbsp;&nbsp;3 - nezinu,</b></td>
	<td><b>&nbsp;&nbsp;4 - piekrītu,</b></td>
	<td><b>&nbsp;&nbsp;5 - pilnībā piekrītu<b></td></tr>
	</table>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>1. E-kursa izmantošana mācību vielas apguvē bija ērta:</b><br/>
	 <table>
	 <tr><td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b11" id="b111" value="1" /></td>
	 <td><input type="radio" name="b11" id="b112" value="2" /></td>
	 <td><input type="radio" name="b11" id="b113" value="3" /></td>
	 <td><input type="radio" name="b11" id="b114" value="4" /></td>
	 <td><input type="radio" name="b11" id="b115" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b12" id="b121" value="1" /></td>
	 <td><input type="radio" name="b12" id="b122" value="2" /></td>
	 <td><input type="radio" name="b12" id="b123" value="3" /></td>
	 <td><input type="radio" name="b12" id="b124" value="4" /></td>
	 <td><input type="radio" name="b12" id="b125" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>2. E-kursa izmantošana sniedza jēgpilnu manu profesionālo iemaņu attīstību un izaugsmi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b21" id="b211" value="1" /></td>
	 <td><input type="radio" name="b21" id="b212" value="2" /></td>
	 <td><input type="radio" name="b21" id="b213" value="3" /></td>
	 <td><input type="radio" name="b21" id="b214" value="4" /></td>
	 <td><input type="radio" name="b21" id="b215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b22" id="b221" value="1"  /></td>
	 <td><input type="radio" name="b22" id="b222" value="2" /></td>
	 <td><input type="radio" name="b22" id="b223" value="3" /></td>
	 <td><input type="radio" name="b22" id="b224" value="4" /></td>
	 <td><input type="radio" name="b22" id="b225" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>3. E-kurss veicināja manu izglītības mērķu sasniegšanu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b31" id="b311" value="1"  /></td>
	 <td><input type="radio" name="b31" id="b312" value="2" /></td>
	 <td><input type="radio" name="b31" id="b313" value="3" /></td>
	 <td><input type="radio" name="b31" id="b314" value="4" /></td>
	 <td><input type="radio" name="b31" id="b315" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b32" id="b321" value="1"  /></td>
	 <td><input type="radio" name="b32" id="b322" value="2" /></td>
	 <td><input type="radio" name="b32" id="b323" value="3" /></td>
	 <td><input type="radio" name="b32" id="b324" value="4" /></td>
	 <td><input type="radio" name="b32" id="b325" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>4. E-kurss veicināja motivāciju personiskai izaugsmi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b41" id="b411" value="1"  /></td>
	 <td><input type="radio" name="b41" id="b412" value="2" /></td>
	 <td><input type="radio" name="b41" id="b413" value="3" /></td>
	 <td><input type="radio" name="b41" id="b414" value="4" /></td>
	 <td><input type="radio" name="b41" id="b415" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b42" id="b421" value="1"  /></td>
	 <td><input type="radio" name="b42" id="b422" value="2" /></td>
	 <td><input type="radio" name="b42" id="b423" value="3" /></td>
	 <td><input type="radio" name="b42" id="b424" value="4" /></td>
	 <td><input type="radio" name="b42" id="b425" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>5. E-kurss rosināja personisku atbildību un ieinteresētību par mācību procesu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b51" id="b511" value="1"  /></td>
	 <td><input type="radio" name="b51" id="b512" value="2" /></td>
	 <td><input type="radio" name="b51" id="b513" value="3" /></td>
	 <td><input type="radio" name="b51" id="b514" value="4" /></td>
	 <td><input type="radio" name="b51" id="b515" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b52" id="b521" value="1"  /></td>
	 <td><input type="radio" name="b52" id="b522" value="2" /></td>
	 <td><input type="radio" name="b52" id="b523" value="3" /></td>
	 <td><input type="radio" name="b52" id="b524" value="4" /></td>
	 <td><input type="radio" name="b52" id="b525" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>6. E-kurss veicināja mācīšanās procesu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b61" id="b611" value="1"  /></td>
	 <td><input type="radio" name="b61" id="b612" value="2" /></td>
	 <td><input type="radio" name="b61" id="b613" value="3" /></td>
	 <td><input type="radio" name="b61" id="b614" value="4" /></td>
	 <td><input type="radio" name="b61" id="b615" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b62" id="b621" value="1"  /></td>
	 <td><input type="radio" name="b62" id="b622" value="2" /></td>
	 <td><input type="radio" name="b62" id="b623" value="3" /></td>
	 <td><input type="radio" name="b62" id="b624" value="4" /></td>
	 <td><input type="radio" name="b62" id="b625" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>7. E-kurss atviegloja studiju kursa apguvi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b71" id="b711" value="1"  /></td>
	 <td><input type="radio" name="b71" id="b712" value="2" /></td>
	 <td><input type="radio" name="b71" id="b713" value="3" /></td>
	 <td><input type="radio" name="b71" id="b714" value="4" /></td>
	 <td><input type="radio" name="b71" id="b715" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b72" id="b721" value="1"  /></td>
	 <td><input type="radio" name="b72" id="b722" value="2" /></td>
	 <td><input type="radio" name="b72" id="b723" value="3" /></td>
	 <td><input type="radio" name="b72" id="b724" value="4" /></td>
	 <td><input type="radio" name="b72" id="b725" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>8. E-kurss veicināja kvalitatīvāku studiju kursa apguvi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b81" id="b811" value="1"  /></td>
	 <td><input type="radio" name="b81" id="b812" value="2" /></td>
	 <td><input type="radio" name="b81" id="b813" value="3" /></td>
	 <td><input type="radio" name="b81" id="b814" value="4" /></td>
	 <td><input type="radio" name="b81" id="b815" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b82" id="b821" value="1"  /></td>
	 <td><input type="radio" name="b82" id="b822" value="2" /></td>
	 <td><input type="radio" name="b82" id="b823" value="3" /></td>
	 <td><input type="radio" name="b82" id="b824" value="4" /></td>
	 <td><input type="radio" name="b82" id="b825" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>9. E-kursa izmantošana deva iespēju studiju kursu apgūt patstāvīgi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b91" id="b911" value="1"  /></td>
	 <td><input type="radio" name="b91" id="b912" value="2" /></td>
	 <td><input type="radio" name="b91" id="b913" value="3" /></td>
	 <td><input type="radio" name="b91" id="b914" value="4" /></td>
	 <td><input type="radio" name="b91" id="b915" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b92" id="b921" value="1"  /></td>
	 <td><input type="radio" name="b92" id="b922" value="2" /></td>
	 <td><input type="radio" name="b92" id="b923" value="3" /></td>
	 <td><input type="radio" name="b92" id="b924" value="4" /></td>
	 <td><input type="radio" name="b92" id="b925" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>10. Izmantojot e-kursu, studiju kursa apguvei nepieciešamais laiks samazinājās</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b101" id="b1011" value="1"  /></td>
	 <td><input type="radio" name="b101" id="b1012" value="2" /></td>
	 <td><input type="radio" name="b101" id="b1013" value="3" /></td>
	 <td><input type="radio" name="b101" id="b1014" value="4" /></td>
	 <td><input type="radio" name="b101" id="b1015" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b102" id="b1021" value="1"  /></td>
	 <td><input type="radio" name="b102" id="b1022" value="2" /></td>
	 <td><input type="radio" name="b102" id="b1023" value="3" /></td>
	 <td><input type="radio" name="b102" id="b1024" value="4" /></td>
	 <td><input type="radio" name="b102" id="b1025" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>11. E-kursa izmantošana nebija sarežģīta</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b111" id="b1111" value="1"  /></td>
	 <td><input type="radio" name="b111" id="b1112" value="2" /></td>
	 <td><input type="radio" name="b111" id="b1113" value="3" /></td>
	 <td><input type="radio" name="b111" id="b1114" value="4" /></td>
	 <td><input type="radio" name="b111" id="b1115" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b112" id="b1121" value="1"  /></td>
	 <td><input type="radio" name="b112" id="b1122" value="2" /></td>
	 <td><input type="radio" name="b112" id="b1123" value="3" /></td>
	 <td><input type="radio" name="b112" id="b1124" value="4" /></td>
	 <td><input type="radio" name="b112" id="b1125" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>12. E-kursa funkcionalitāte bija pietiekoša</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b121" id="b1211" value="1"  /></td>
	 <td><input type="radio" name="b121" id="b1212" value="2" /></td>
	 <td><input type="radio" name="b121" id="b1213" value="3" /></td>
	 <td><input type="radio" name="b121" id="b1214" value="4" /></td>
	 <td><input type="radio" name="b121" id="b1215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b122" id="b1221" value="1"  /></td>
	 <td><input type="radio" name="b122" id="b1222" value="2" /></td>
	 <td><input type="radio" name="b122" id="b1223" value="3" /></td>
	 <td><input type="radio" name="b122" id="b1224" value="4" /></td>
	 <td><input type="radio" name="b122" id="b1225" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>13. E-kursa lietotāja saskarne bija ērta</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b131" id="b1311" value="1"  /></td>
	 <td><input type="radio" name="b131" id="b1312" value="2" /></td>
	 <td><input type="radio" name="b131" id="b1313" value="3" /></td>
	 <td><input type="radio" name="b131" id="b1314" value="4" /></td>
	 <td><input type="radio" name="b131" id="b1315" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b132" id="b1321" value="1"  /></td>
	 <td><input type="radio" name="b132" id="b1322" value="2" /></td>
	 <td><input type="radio" name="b132" id="b1323" value="3" /></td>
	 <td><input type="radio" name="b132" id="b1324" value="4" /></td>
	 <td><input type="radio" name="b132" id="b1325" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>14. E-kursa struktūra bija ērta</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b141" id="b1411" value="1"  /></td>
	 <td><input type="radio" name="b141" id="b1412" value="2" /></td>
	 <td><input type="radio" name="b141" id="b1413" value="3" /></td>
	 <td><input type="radio" name="b141" id="b1414" value="4" /></td>
	 <td><input type="radio" name="b141" id="b1415" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b142" id="b1421" value="1"  /></td>
	 <td><input type="radio" name="b142" id="b1422" value="2" /></td>
	 <td><input type="radio" name="b142" id="b1423" value="3" /></td>
	 <td><input type="radio" name="b142" id="b1424" value="4" /></td>
	 <td><input type="radio" name="b142" id="b1425" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>15. E-kurss bija piemērots manām vajadzībām</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b151" id="b1511" value="1"  /></td>
	 <td><input type="radio" name="b151" id="b1512" value="2" /></td>
	 <td><input type="radio" name="b151" id="b1513" value="3" /></td>
	 <td><input type="radio" name="b151" id="b1514" value="4" /></td>
	 <td><input type="radio" name="b151" id="b1515" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b152" id="b1521" value="1"  /></td>
	 <td><input type="radio" name="b152" id="b1522" value="2" /></td>
	 <td><input type="radio" name="b152" id="b1523" value="3" /></td>
	 <td><input type="radio" name="b152" id="b1524" value="4" /></td>
	 <td><input type="radio" name="b152" id="b1525" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>16. E-kursā es varēju kontrolēt savu mācīšanās procesu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b161" id="b1611" value="1"  /></td>
	 <td><input type="radio" name="b161" id="b1612" value="2" /></td>
	 <td><input type="radio" name="b161" id="b1613" value="3" /></td>
	 <td><input type="radio" name="b161" id="b1614" value="4" /></td>
	 <td><input type="radio" name="b161" id="b1615" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b162" id="b1621" value="1"  /></td>
	 <td><input type="radio" name="b162" id="b1622" value="2" /></td>
	 <td><input type="radio" name="b162" id="b1623" value="3" /></td>
	 <td><input type="radio" name="b162" id="b1624" value="4" /></td>
	 <td><input type="radio" name="b162" id="b1625" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>17. Ja tēma nebija apgūta, sistēma brīdināja mani par to</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b171" id="b1711" value="1"  /></td>
	 <td><input type="radio" name="b171" id="b1712" value="2" /></td>
	 <td><input type="radio" name="b171" id="b1713" value="3" /></td>
	 <td><input type="radio" name="b171" id="b1714" value="4" /></td>
	 <td><input type="radio" name="b171" id="b1715" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b172" id="b1721" value="1"  /></td>
	 <td><input type="radio" name="b172" id="b1722" value="2" /></td>
	 <td><input type="radio" name="b172" id="b1723" value="3" /></td>
	 <td><input type="radio" name="b172" id="b1724" value="4" /></td>
	 <td><input type="radio" name="b172" id="b1725" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>18. Bija pieejama e-kursa apguves iespēju dažādošana</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b181" id="b1811" value="1"  /></td>
	 <td><input type="radio" name="b181" id="b1812" value="2" /></td>
	 <td><input type="radio" name="b181" id="b1813" value="3" /></td>
	 <td><input type="radio" name="b181" id="b1814" value="4" /></td>
	 <td><input type="radio" name="b181" id="b1815" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b182" id="b1821" value="1"  /></td>
	 <td><input type="radio" name="b182" id="b1822" value="2" /></td>
	 <td><input type="radio" name="b182" id="b1823" value="3" /></td>
	 <td><input type="radio" name="b182" id="b1824" value="4" /></td>
	 <td><input type="radio" name="b182" id="b1825" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>19. Es ieteiktu izmantot e-kursu citiem studentiem</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b191" id="b1911" value="1"  /></td>
	 <td><input type="radio" name="b191" id="b1912" value="2" /></td>
	 <td><input type="radio" name="b191" id="b1913" value="3" /></td>
	 <td><input type="radio" name="b191" id="b1914" value="4" /></td>
	 <td><input type="radio" name="b191" id="b1915" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b192" id="b1921" value="1"  /></td>
	 <td><input type="radio" name="b192" id="b1922" value="2" /></td>
	 <td><input type="radio" name="b192" id="b1923" value="3" /></td>
	 <td><input type="radio" name="b192" id="b1924" value="4" /></td>
	 <td><input type="radio" name="b192" id="b1925" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>20. Izmantojot e-kursu bija bieži jākomunicē ar kursa pasniedzēju</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b201" id="b2011" value="1"  /></td>
	 <td><input type="radio" name="b201" id="b2012" value="2" /></td>
	 <td><input type="radio" name="b201" id="b2013" value="3" /></td>
	 <td><input type="radio" name="b201" id="b2014" value="4" /></td>
	 <td><input type="radio" name="b201" id="b2015" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b202" id="b2021" value="1"  /></td>
	 <td><input type="radio" name="b202" id="b2022" value="2" /></td>
	 <td><input type="radio" name="b202" id="b2023" value="3" /></td>
	 <td><input type="radio" name="b202" id="b2024" value="4" /></td>
	 <td><input type="radio" name="b202" id="b2025" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>21. E-kursu var apgūt bez komunikācijas vai ar minimālu komunikāciju ar pasniedzēju</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b211" id="b2111" value="1"  /></td>
	 <td><input type="radio" name="b211" id="b2112" value="2" /></td>
	 <td><input type="radio" name="b211" id="b2113" value="3" /></td>
	 <td><input type="radio" name="b211" id="b2114" value="4" /></td>
	 <td><input type="radio" name="b211" id="b2115" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b212" id="b2121" value="1"  /></td>
	 <td><input type="radio" name="b212" id="b2122" value="2" /></td>
	 <td><input type="radio" name="b212" id="b2123" value="3" /></td>
	 <td><input type="radio" name="b212" id="b2124" value="4" /></td>
	 <td><input type="radio" name="b212" id="b2125" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>22. E-kursā mana uzmanība netika sadalīta, kas varētu apgrūtināt manu mācīšanās procesu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b221" id="b2211" value="1"  /></td>
	 <td><input type="radio" name="b221" id="b2212" value="2" /></td>
	 <td><input type="radio" name="b221" id="b2213" value="3" /></td>
	 <td><input type="radio" name="b221" id="b2214" value="4" /></td>
	 <td><input type="radio" name="b221" id="b2215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b222" id="b2221" value="1"  /></td>
	 <td><input type="radio" name="b222" id="b2222" value="2" /></td>
	 <td><input type="radio" name="b222" id="b2223" value="3" /></td>
	 <td><input type="radio" name="b222" id="b2224" value="4" /></td>
	 <td><input type="radio" name="b222" id="b2225" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>23. Piedāvātā e-kursa tēmas struktūra atbilda manām vajadzībām</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b231" id="b2311" value="1"  /></td>
	 <td><input type="radio" name="b231" id="b2312" value="2" /></td>
	 <td><input type="radio" name="b231" id="b2313" value="3" /></td>
	 <td><input type="radio" name="b231" id="b2314" value="4" /></td>
	 <td><input type="radio" name="b231" id="b2315" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b232" id="b2321" value="1"  /></td>
	 <td><input type="radio" name="b232" id="b2322" value="2" /></td>
	 <td><input type="radio" name="b232" id="b2323" value="3" /></td>
	 <td><input type="radio" name="b232" id="b2324" value="4" /></td>
	 <td><input type="radio" name="b232" id="b2325" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>24. Tēmas struktūra nodrošināja tēmā ievietoto resursu un aktivitāšu pārskatāmību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b241" id="b211" value="1"  /></td>
	 <td><input type="radio" name="b241" id="b212" value="2" /></td>
	 <td><input type="radio" name="b241" id="b213" value="3" /></td>
	 <td><input type="radio" name="b241" id="b214" value="4" /></td>
	 <td><input type="radio" name="b241" id="b215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b242" id="b2421" value="1"  /></td>
	 <td><input type="radio" name="b242" id="b2422" value="2" /></td>
	 <td><input type="radio" name="b242" id="b2423" value="3" /></td>
	 <td><input type="radio" name="b242" id="b2424" value="4" /></td>
	 <td><input type="radio" name="b242" id="b2425" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>25. E-kursa vienas tēmas struktūra uzskatāmi parādīja tēmā izmantoto resursu un aktivitāšu vietu un nozīmi konkrētajā tēmā</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b251" id="b211" value="1"  /></td>
	 <td><input type="radio" name="b251" id="b212" value="2" /></td>
	 <td><input type="radio" name="b251" id="b213" value="3" /></td>
	 <td><input type="radio" name="b251" id="b214" value="4" /></td>
	 <td><input type="radio" name="b251" id="b215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b252" id="b2521" value="1"  /></td>
	 <td><input type="radio" name="b252" id="b2522" value="2" /></td>
	 <td><input type="radio" name="b252" id="b2523" value="3" /></td>
	 <td><input type="radio" name="b252" id="b2524" value="4" /></td>
	 <td><input type="radio" name="b252" id="b2525" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>26. Es sapratu e-kursa tēmas struktūru</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b261" id="b2611" value="1"  /></td>
	 <td><input type="radio" name="b261" id="b2612" value="2" /></td>
	 <td><input type="radio" name="b261" id="b2613" value="3" /></td>
	 <td><input type="radio" name="b261" id="b2614" value="4" /></td>
	 <td><input type="radio" name="b261" id="b2615" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b262" id="b2621" value="1"  /></td>
	 <td><input type="radio" name="b262" id="b2622" value="2" /></td>
	 <td><input type="radio" name="b262" id="b2623" value="3" /></td>
	 <td><input type="radio" name="b262" id="b2624" value="4" /></td>
	 <td><input type="radio" name="b262" id="b2625" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>27. E-kursa tēmas struktūra bija vienkārša</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b271" id="b2711" value="1"  /></td>
	 <td><input type="radio" name="b271" id="b2712" value="2" /></td>
	 <td><input type="radio" name="b271" id="b2713" value="3" /></td>
	 <td><input type="radio" name="b271" id="b2714" value="4" /></td>
	 <td><input type="radio" name="b271" id="b2715" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b272" id="b2721" value="1"  /></td>
	 <td><input type="radio" name="b272" id="b2722" value="2" /></td>
	 <td><input type="radio" name="b272" id="b2723" value="3" /></td>
	 <td><input type="radio" name="b272" id="b2724" value="4" /></td>
	 <td><input type="radio" name="b272" id="b2725" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>28. E-kursā bija nodrošināts mācīšanās ceļš vienas tēmas ietvaros</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b281" id="b2811" value="1"  /></td>
	 <td><input type="radio" name="b281" id="b2812" value="2" /></td>
	 <td><input type="radio" name="b281" id="b2813" value="3" /></td>
	 <td><input type="radio" name="b281" id="b2814" value="4" /></td>
	 <td><input type="radio" name="b281" id="b2815" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b282" id="b2821" value="1"  /></td>
	 <td><input type="radio" name="b282" id="b2822" value="2" /></td>
	 <td><input type="radio" name="b282" id="b2823" value="3" /></td>
	 <td><input type="radio" name="b282" id="b2824" value="4" /></td>
	 <td><input type="radio" name="b282" id="b2825" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>29. E-kursā nebija nekā lieka</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b291" id="b2911" value="1"  /></td>
	 <td><input type="radio" name="b291" id="b2912" value="2" /></td>
	 <td><input type="radio" name="b291" id="b2913" value="3" /></td>
	 <td><input type="radio" name="b291" id="b2914" value="4" /></td>
	 <td><input type="radio" name="b291" id="b2915" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b292" id="b2921" value="1"  /></td>
	 <td><input type="radio" name="b292" id="b2922" value="2" /></td>
	 <td><input type="radio" name="b292" id="b2923" value="3" /></td>
	 <td><input type="radio" name="b292" id="b2924" value="4" /></td>
	 <td><input type="radio" name="b292" id="b2925" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>30. E-kursā informācijas apjoms bija pietiekošs</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b301" id="b3011" value="1"  /></td>
	 <td><input type="radio" name="b301" id="b3012" value="2" /></td>
	 <td><input type="radio" name="b301" id="b3013" value="3" /></td>
	 <td><input type="radio" name="b301" id="b3014" value="4" /></td>
	 <td><input type="radio" name="b301" id="b3015" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b302" id="b3021" value="1"  /></td>
	 <td><input type="radio" name="b302" id="b3022" value="2" /></td>
	 <td><input type="radio" name="b302" id="b3023" value="3" /></td>
	 <td><input type="radio" name="b302" id="b3024" value="4" /></td>
	 <td><input type="radio" name="b302" id="b3025" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>31. E-kursa saturs bija pielāgots man piemītošajam mācīšanās stilam</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b311" id="b3111" value="1"  /></td>
	 <td><input type="radio" name="b311" id="b3112" value="2" /></td>
	 <td><input type="radio" name="b311" id="b3113" value="3" /></td>
	 <td><input type="radio" name="b311" id="b3114" value="4" /></td>
	 <td><input type="radio" name="b311" id="b3115" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b312" id="b3121" value="1"  /></td>
	 <td><input type="radio" name="b312" id="b3122" value="2" /></td>
	 <td><input type="radio" name="b312" id="b3123" value="3" /></td>
	 <td><input type="radio" name="b312" id="b3124" value="4" /></td>
	 <td><input type="radio" name="b312" id="b3125" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>32. Izmantojot e-kursu samazinājās nepieciešamība pēc papildus materiāliem no citiem ārējiem informācijas avotiem</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b321" id="b3211" value="1"  /></td>
	 <td><input type="radio" name="b321" id="b3212" value="2" /></td>
	 <td><input type="radio" name="b321" id="b3213" value="3" /></td>
	 <td><input type="radio" name="b321" id="b3214" value="4" /></td>
	 <td><input type="radio" name="b321" id="b3215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b322" id="b3221" value="1"  /></td>
	 <td><input type="radio" name="b322" id="b3222" value="2" /></td>
	 <td><input type="radio" name="b322" id="b3223" value="3" /></td>
	 <td><input type="radio" name="b322" id="b3224" value="4" /></td>
	 <td><input type="radio" name="b322" id="b3225" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>33. Atbilstoši manam zināšanu līmenim e-kursa teorijas apguvē man nebija nepieciešami papildus paskaidrojumi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b331" id="b3311" value="1"  /></td>
	 <td><input type="radio" name="b331" id="b3312" value="2" /></td>
	 <td><input type="radio" name="b331" id="b3313" value="3" /></td>
	 <td><input type="radio" name="b331" id="b3314" value="4" /></td>
	 <td><input type="radio" name="b331" id="b3315" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b332" id="b3321" value="1"  /></td>
	 <td><input type="radio" name="b332" id="b3322" value="2" /></td>
	 <td><input type="radio" name="b332" id="b3323" value="3" /></td>
	 <td><input type="radio" name="b332" id="b3324" value="4" /></td>
	 <td><input type="radio" name="b332" id="b3325" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>34. E-kursā mani interesēja tikai piedāvātie mācību resursi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b341" id="b3411" value="1"  /></td>
	 <td><input type="radio" name="b341" id="b3412" value="2" /></td>
	 <td><input type="radio" name="b341" id="b3413" value="3" /></td>
	 <td><input type="radio" name="b341" id="b3414" value="4" /></td>
	 <td><input type="radio" name="b341" id="b3415" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b342" id="b3421" value="1"  /></td>
	 <td><input type="radio" name="b342" id="b3422" value="2" /></td>
	 <td><input type="radio" name="b342" id="b3423" value="3" /></td>
	 <td><input type="radio" name="b342" id="b3424" value="4" /></td>
	 <td><input type="radio" name="b342" id="b3425" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>35. E-kursā bija nodrošināts mācību vielas apguves ceļš visa kursa ietvaros</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b351" id="b3511" value="1"  /></td>
	 <td><input type="radio" name="b351" id="b3512" value="2" /></td>
	 <td><input type="radio" name="b351" id="b3513" value="3" /></td>
	 <td><input type="radio" name="b351" id="b3514" value="4" /></td>
	 <td><input type="radio" name="b351" id="b3515" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b352" id="b3521" value="1"  /></td>
	 <td><input type="radio" name="b352" id="b3522" value="2" /></td>
	 <td><input type="radio" name="b352" id="b3523" value="3" /></td>
	 <td><input type="radio" name="b352" id="b3524" value="4" /></td>
	 <td><input type="radio" name="b352" id="b3525" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>36. Pēc noklusējuma piedāvātā tēmu secība pilnībā apmierināja manas vajadzības</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b361" id="b3611" value="1"  /></td>
	 <td><input type="radio" name="b361" id="b3612" value="2" /></td>
	 <td><input type="radio" name="b361" id="b3613" value="3" /></td>
	 <td><input type="radio" name="b361" id="b3614" value="4" /></td>
	 <td><input type="radio" name="b361" id="b3615" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b362" id="b3621" value="1"  /></td>
	 <td><input type="radio" name="b362" id="b3622" value="2" /></td>
	 <td><input type="radio" name="b362" id="b3623" value="3" /></td>
	 <td><input type="radio" name="b362" id="b3624" value="4" /></td>
	 <td><input type="radio" name="b362" id="b3625" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>37. Man nebija vēlmes mainīt apgūstāmo tēmu secību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b371" id="b3711" value="1"  /></td>
	 <td><input type="radio" name="b371" id="b3712" value="2" /></td>
	 <td><input type="radio" name="b371" id="b3713" value="3" /></td>
	 <td><input type="radio" name="b371" id="b3714" value="4" /></td>
	 <td><input type="radio" name="b371" id="b3715" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b372" id="b3721" value="1"  /></td>
	 <td><input type="radio" name="b372" id="b3722" value="2" /></td>
	 <td><input type="radio" name="b372" id="b3723" value="3" /></td>
	 <td><input type="radio" name="b372" id="b3724" value="4" /></td>
	 <td><input type="radio" name="b372" id="b3725" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>38. Nevēlējos sevi apgrūtināt ar tēmu secības maiņu</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b381" id="b3811" value="1"  /></td>
	 <td><input type="radio" name="b381" id="b3812" value="2" /></td>
	 <td><input type="radio" name="b381" id="b3813" value="3" /></td>
	 <td><input type="radio" name="b381" id="b3814" value="4" /></td>
	 <td><input type="radio" name="b381" id="b3815" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b382" id="b3821" value="1"  /></td>
	 <td><input type="radio" name="b382" id="b3822" value="2" /></td>
	 <td><input type="radio" name="b382" id="b3823" value="3" /></td>
	 <td><input type="radio" name="b382" id="b3824" value="4" /></td>
	 <td><input type="radio" name="b382" id="b3825" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>39. Es sapratu piedāvāto tēmu secības veidu dažādību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b391" id="b3911" value="1"  /></td>
	 <td><input type="radio" name="b391" id="b3912" value="2" /></td>
	 <td><input type="radio" name="b391" id="b3913" value="3" /></td>
	 <td><input type="radio" name="b391" id="b3914" value="4" /></td>
	 <td><input type="radio" name="b391" id="b3915" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b392" id="b3921" value="1"  /></td>
	 <td><input type="radio" name="b392" id="b3922" value="2" /></td>
	 <td><input type="radio" name="b392" id="b3923" value="3" /></td>
	 <td><input type="radio" name="b392" id="b3924" value="4" /></td>
	 <td><input type="radio" name="b392" id="b3925" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>40. Es sapratu tēmu secības veidu izmantošanas būtību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b401" id="b4011" value="1"  /></td>
	 <td><input type="radio" name="b401" id="b4012" value="2" /></td>
	 <td><input type="radio" name="b401" id="b4013" value="3" /></td>
	 <td><input type="radio" name="b401" id="b4014" value="4" /></td>
	 <td><input type="radio" name="b401" id="b4015" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b402" id="b4021" value="1"  /></td>
	 <td><input type="radio" name="b402" id="b4022" value="2" /></td>
	 <td><input type="radio" name="b402" id="b4023" value="3" /></td>
	 <td><input type="radio" name="b402" id="b4024" value="4" /></td>
	 <td><input type="radio" name="b402" id="b4025" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td style="background-color:#F5F5F5">
<b>41. Es izmantoju ne tikai pēc noklusējuma piedāvāto tēmu secību, bet arī citus tēmu secības veidus</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b411" id="b4111" value="1"  /></td>
	 <td><input type="radio" name="b411" id="b4112" value="2" /></td>
	 <td><input type="radio" name="b411" id="b4113" value="3" /></td>
	 <td><input type="radio" name="b411" id="b4114" value="4" /></td>
	 <td><input type="radio" name="b411" id="b4115" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b412" id="b4121" value="1"  /></td>
	 <td><input type="radio" name="b412" id="b4122" value="2" /></td>
	 <td><input type="radio" name="b412" id="b4123" value="3" /></td>
	 <td><input type="radio" name="b412" id="b4124" value="4" /></td>
	 <td><input type="radio" name="b412" id="b4125" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>
<tr><td></td>
<td>
<b>42. Tēmu secības izmantošana palīdzēja man kvalitatīvāk veikt studiju kursa apguvi</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b421" id="b4211" value="1"  /></td>
	 <td><input type="radio" name="b421" id="b4212" value="2" /></td>
	 <td><input type="radio" name="b421" id="b4213" value="3" /></td>
	 <td><input type="radio" name="b421" id="b4214" value="4" /></td>
	 <td><input type="radio" name="b421" id="b4215" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b422" id="b4221" value="1"  /></td>
	 <td><input type="radio" name="b422" id="b4222" value="2" /></td>
	 <td><input type="radio" name="b422" id="b4223" value="3" /></td>
	 <td><input type="radio" name="b422" id="b4224" value="4" /></td>
	 <td><input type="radio" name="b422" id="b4225" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>43. Tēmu secības maiņas izmantošana man palīdzēja apgūt kursu atbilstoši manām vajadzībām</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b431" id="b4311" value="1"  /></td>
	 <td><input type="radio" name="b431" id="b4312" value="2" /></td>
	 <td><input type="radio" name="b431" id="b4313" value="3" /></td>
	 <td><input type="radio" name="b431" id="b4314" value="4" /></td>
	 <td><input type="radio" name="b431" id="b4315" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b432" id="b4321" value="1"  /></td>
	 <td><input type="radio" name="b432" id="b4322" value="2" /></td>
	 <td><input type="radio" name="b432" id="b4323" value="3" /></td>
	 <td><input type="radio" name="b432" id="b4324" value="4" /></td>
	 <td><input type="radio" name="b432" id="b4325" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>44. E-kursa apgūšanai izmantoju tikai/arī paša veidoto tēmu secību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b441" id="b4411" value="1"  /></td>
	 <td><input type="radio" name="b441" id="b4412" value="2" /></td>
	 <td><input type="radio" name="b441" id="b4413" value="3" /></td>
	 <td><input type="radio" name="b441" id="b4414" value="4" /></td>
	 <td><input type="radio" name="b441" id="b4415" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b442" id="b4421" value="1"  /></td>
	 <td><input type="radio" name="b442" id="b4422" value="2" /></td>
	 <td><input type="radio" name="b442" id="b4423" value="3" /></td>
	 <td><input type="radio" name="b442" id="b4424" value="4" /></td>
	 <td><input type="radio" name="b442" id="b4425" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td style="background-color:#F5F5F5">
<b>45. E-kursa apguvē svarīga ir iepriekšējo apmācāmo kursa apguvē gūtā pieredze</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b451" id="b4511" value="1"  /></td>
	 <td><input type="radio" name="b451" id="b4512" value="2" /></td>
	 <td><input type="radio" name="b451" id="b4513" value="3" /></td>
	 <td><input type="radio" name="b451" id="b4514" value="4" /></td>
	 <td><input type="radio" name="b451" id="b4515" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b452" id="b4521" value="1" /></td>
	 <td><input type="radio" name="b452" id="b4522" value="2" /></td>
	 <td><input type="radio" name="b452" id="b4523" value="3" /></td>
	 <td><input type="radio" name="b452" id="b4524" value="4" /></td>
	 <td><input type="radio" name="b452" id="b4525" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr><tr><td></td>
<td>
<b>46. Es izmantoju tikai/arī kursa apguves optimālo tēmu secību</b><br/>
	 <table>
	 <tr>
	 <td></td>
	 <td>&nbsp;&nbsp;1</td><td>&nbsp;&nbsp;2</td><td>&nbsp;&nbsp;3</td><td>&nbsp;&nbsp;4</td><td>&nbsp;&nbsp;5</td></tr>
	 <tr>
	 <td>Neadaptīvs kurss</td>
	 <td><input type="radio" name="b461" id="b4611" value="1"  /></td>
	 <td><input type="radio" name="b461" id="b4612" value="2" /></td>
	 <td><input type="radio" name="b461" id="b4613" value="3" /></td>
	 <td><input type="radio" name="b461" id="b4614" value="4" /></td>
	 <td><input type="radio" name="b461" id="b4615" value="5" /></td></tr>
	 <tr>   
      <td>Adaptīvs kurss</td>
	 <td><input type="radio" name="b462" id="b4621" value="1"  /></td>
	 <td><input type="radio" name="b462" id="b4622" value="2" /></td>
	 <td><input type="radio" name="b462" id="b4623" value="3" /></td>
	 <td><input type="radio" name="b462" id="b4624" value="4" /></td>
	 <td><input type="radio" name="b462" id="b4625" value="5" /></td></tr>
	 </table>
	 <br/>
</td></tr>

</table>



<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><input type="submit" name="submit" value="Iesniegt testu"></b><br>
</form>