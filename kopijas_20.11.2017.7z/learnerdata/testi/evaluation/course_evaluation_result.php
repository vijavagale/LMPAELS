<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">	
<title>lapa</title>	
</head>
<body>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Kursu</a>

<p>Testu var veikt vairākas reizes, taču tikai pirmājā reizē testa rezultāti tiks ierakstīti datu bāzē!</p>
	<div>

<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
require_once("../../../../config.php") ;
require_once("../../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;

//datu savaksana
$testname = "coursedata"; 
$answer25=0;
$answer26=0;
$dz=0;
$year1=0;
if(isset($_POST['question-25-answers'])){$pk = $_POST['question-25-answers'];} 
if(isset($_POST['question-26-answers'])){$dl = $_POST['question-26-answers'];} 

if(isset($_POST['dz'])){$dz = $_POST['dz'];}
if(isset($_POST['day_start'])){$day1 = $_POST['day_start'];}  
if(isset($_POST['month_start'])){$month1 = $_POST['month_start'];} 
if(isset($_POST['year_start'])){$year1 = $_POST['year_start'];}

if(($year1<1930)||($year1>2010)||($dz=='')||($pk=="")||($dl=="")) {echo "<i>Nav ievadītas atbildes uz vienu vai vairākiem jautājumiem!</i><br/><br/><a href='javascript:history.back(1);'>Atpakaļ</a>"; die();}

if ($month1=='Janvāris') $month2=1;
if ($month1=='Februāris') $month2=2;
if ($month1=='Marts') $month2=3;
if ($month1=='Aprīlis') $month2=4;
if ($month1=='Maijs') $month2=5;
if ($month1=='Jūnijs') $month2=6;
if ($month1=='Jūlijs') $month2=7;
if ($month1=='Augusts') $month2=8;
if ($month1=='Septembris') $month2=9;
if ($month1=='Oktobris') $month2=10;
if ($month1=='Novembris') $month2=11;
if ($month1=='Decembris') $month2=12;
//echo "<p>Dzimšanas datums: ".$day1." ".$month2." ".$year1."</p>";

if ($pk=='n') $pk1=0;
if ($pk=='y') $pk1=1;
if ($dl=='e') $dl1=1;
if ($dl=='m') $dl1=2;
if ($dl=='d') $dl1=3;

//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------

//definee klasi
$testname='coursedata';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= 'coursedata';
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
		else {
			$artefacttypeid=$res[$testname];
			//echo "<br>AR= ".$artefacttypeid;
		}

//------------------------------------------------------------

		echo "<H3>Kursa datu rezultāti</H3>";

		$userpeddata_ir = $DB->get_record('v_user_pedagogical_data', array('userid'=>$USER->id,'courseid'=>$courseid));
		//print_r($userpeddata_ir);
		$userperdata_ir = $DB->get_record('v_user_personal_data', array('userid'=>$USER->id));
		//echo "<br/>";
		//print_r($userperdata_ir);
		$k=0;	
		//echo "<br/>Empty1= ".empty($userpeddata_ir);
		//echo "<br/>Empty1= ".empty($userperdata_ir);
		if (empty($userpeddata_ir) || empty($userperdata_ir) )
				{//			tabula			'v_user_artefact_all'
						
						$record0 = new stdClass();
						$record0->artefacttypeid=$artefacttypeid;
						$record0->userid=$userid;
						$record0->ctime=time();
						$record0->source=$testname;
						$record0->description= 'course data';
						$table='v_user_artefact_all';
						$lastid=$DB->insert_record($table, $record0);
				
					
				}
				//jaaieraksta konkrtetos datus	
	
		if (empty($userpeddata_ir))
						{//			tabula			v_user_pedagogical_data
						$record1 = new stdClass();
						$record1->userid= $USER->id;
						$record1->courseid= $courseid;
						$record1->preknow= $pk1;
						$record1->dlevel= $dl1;
						$record1->ctime= time();
						$DB->insert_record('v_user_pedagogical_data', $record1);
						$k++;
						}

		if (empty($userperdata_ir))
						{//			tabula			v_user_personal_data

						$record2 = new stdClass();
						$record2->userid= $USER->id;
						$record2->bday= $day1;
						$record2->bmonth= $month2;
						$record2->byear= $year1;
						$record2->gender= $dz;
						$DB->insert_record('v_user_personal_data', $record2);
						$k++;
						
						}
	if ($k>0) echo "<br>Dati tika ierakstīti datu bāzē!"; else 	echo "<br>Datu bāzē dati par Jums jau eksistē!";
		
		
?>