﻿<meta charset='utf-8 '>
<html lang="en">
<head>
	<title>lapa</title>	
</head>
<body>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Kursu</a>
<h2>Mācīšanās stilu noteikšana (VARK1)</h2>
<p>Testu var veikt vairākas reizes!</p>
	<div>
		
		
<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;

require_login(); //Won't do any good to 'get' a username 'til sombody's logged in.  


			$viz=0;
			$taustes=0;
			$dzirdes=0;
			
$answer1=0;
$answer2=0;	
$answer3=0;
$answer4=0;
$answer5=0;
$answer6=0;
$answer7=0;
$answer8=0;
$answer9=0;
$answer10=0;
$answer11=0;
$answer12=0;
$answer13=0;
$answer14=0;
$answer15=0;
$answer16=0;
$answer17=0;
$answer18=0;
$answer19=0;	
$answer20=0;
$answer21=0;
$answer22=0;
$answer23=0;
$answer24=0;	


if(isset($_POST['question-1-answers'])){$answer1 = $_POST['question-1-answers'];}
if(isset($_POST['question-2-answers'])){$answer2 = $_POST['question-2-answers'];}
if(isset($_POST['question-3-answers'])){$answer3 = $_POST['question-3-answers'];}
if(isset($_POST['question-4-answers'])){$answer4 = $_POST['question-4-answers'];}
if(isset($_POST['question-5-answers'])){$answer5 = $_POST['question-5-answers'];}
if(isset($_POST['question-6-answers'])){$answer6 = $_POST['question-6-answers'];}
if(isset($_POST['question-7-answers'])){$answer7 = $_POST['question-7-answers'];}
if(isset($_POST['question-8-answers'])){$answer8 = $_POST['question-8-answers'];}
if(isset($_POST['question-9-answers'])){$answer9 = $_POST['question-9-answers'];}
if(isset($_POST['question-10-answers'])){$answer10 = $_POST['question-10-answers'];}
if(isset($_POST['question-11-answers'])){$answer11 = $_POST['question-11-answers'];}
if(isset($_POST['question-12-answers'])){$answer12 = $_POST['question-12-answers'];}
if(isset($_POST['question-13-answers'])){$answer13 = $_POST['question-13-answers'];}
if(isset($_POST['question-14-answers'])){$answer14 = $_POST['question-14-answers'];}
if(isset($_POST['question-15-answers'])){$answer15 = $_POST['question-15-answers'];}
if(isset($_POST['question-16-answers'])){$answer16 = $_POST['question-16-answers'];}
if(isset($_POST['question-17-answers'])){$answer17 = $_POST['question-17-answers'];}
if(isset($_POST['question-18-answers'])){$answer18 = $_POST['question-18-answers'];}
if(isset($_POST['question-19-answers'])){$answer19 = $_POST['question-19-answers'];}
if(isset($_POST['question-20-answers'])){$answer20 = $_POST['question-20-answers'];}
if(isset($_POST['question-21-answers'])){$answer21 = $_POST['question-21-answers'];}
if(isset($_POST['question-22-answers'])){$answer22 = $_POST['question-22-answers'];}
if(isset($_POST['question-23-answers'])){$answer23 = $_POST['question-23-answers'];}
if(isset($_POST['question-24-answers'])){$answer24 = $_POST['question-24-answers'];} 

if ($answer1 == "A") { $dzirdes+=5; }
if ($answer1 == "B") { $dzirdes+=3; }
if ($answer1 == "C") { $dzirdes+=1; }
if ($answer5 == "A") { $dzirdes+=5; }
if ($answer5 == "B") { $dzirdes+=3; }
if ($answer5 == "C") { $dzirdes+=1; }
if ($answer8 == "A") { $dzirdes+=5; }
if ($answer8 == "B") { $dzirdes+=3; }
if ($answer8 == "C") { $dzirdes+=1; }
if ($answer11 == "A") { $dzirdes+=5; }
if ($answer11 == "B") { $dzirdes+=3; }
if ($answer11 == "C") { $dzirdes+=1; }
if ($answer13 == "A") { $dzirdes+=5; }
if ($answer13 == "B") { $dzirdes+=3; }
if ($answer13 == "C") { $dzirdes+=1; } 
if ($answer18 == "A") { $dzirdes+=5; }
if ($answer18 == "B") { $dzirdes+=3; }
if ($answer18 == "C") { $dzirdes+=1; } 
if ($answer21 == "A") { $dzirdes+=5; }
if ($answer21 == "B") { $dzirdes+=3; }
if ($answer21 == "C") { $dzirdes+=1; } 
if ($answer24 == "A") { $dzirdes+=5; }
if ($answer24 == "B") { $dzirdes+=3; }
if ($answer24 == "C") { $dzirdes+=1; } 
//  **dzirdes punkti saskaitīti**
if ($answer2 == "A") { $viz+=5; }
if ($answer2 == "B") { $viz+=3; }
if ($answer2 == "C") { $viz+=1; } 
if ($answer3 == "A") { $viz+=5; }
if ($answer3 == "B") { $viz+=3; }
if ($answer3 == "C") { $viz+=1; }   
if ($answer7 == "A") { $viz+=5; }
if ($answer7 == "B") { $viz+=3; }
if ($answer7 == "C") { $viz+=1; }
if ($answer10 == "A") { $viz+=5; }
if ($answer10 == "B") { $viz+=3; }
if ($answer10 == "C") { $viz+=1; }
if ($answer14 == "A") { $viz+=5; }
if ($answer14 == "B") { $viz+=3; }
if ($answer14 == "C") { $viz+=1; } 
if ($answer16 == "A") { $viz+=5; }
if ($answer16 == "B") { $viz+=3; }
if ($answer16 == "C") { $viz+=1; } 
if ($answer19 == "A") { $viz+=5; }
if ($answer19 == "B") { $viz+=3; }
if ($answer19 == "C") { $viz+=1; } 
if ($answer22 == "A") { $viz+=5; }
if ($answer22 == "B") { $viz+=3; }
if ($answer22 == "C") { $viz+=1; }
//  **vizuālie punkti saskaitīti**
if ($answer4 == "A") { $taustes+=5; }
if ($answer4 == "B") { $taustes+=3; }
if ($answer4 == "C") { $taustes+=1; }
if ($answer6 == "A") { $taustes+=5; }
if ($answer6 == "B") { $taustes+=3; }
if ($answer6 == "C") { $taustes+=1; }
if ($answer9 == "A") { $taustes+=5; }
if ($answer9 == "B") { $taustes+=3; }
if ($answer9 == "C") { $taustes+=1; }
if ($answer12== "A") { $taustes+=5; }
if ($answer12== "B") { $taustes+=3; }
if ($answer12== "C") { $taustes+=1; }
if ($answer15== "A") { $taustes+=5; }
if ($answer15== "B") { $taustes+=3; }
if ($answer15== "C") { $taustes+=1; }
if ($answer17== "A") { $taustes+=5; }
if ($answer17== "B") { $taustes+=3; }
if ($answer17== "C") { $taustes+=1; }
if ($answer20== "A") { $taustes+=5; }
if ($answer20== "B") { $taustes+=3; }
if ($answer20== "C") { $taustes+=1; }
if ($answer23== "A") { $taustes+=5; }
if ($answer23== "B") { $taustes+=3; }
if ($answer23== "C") { $taustes+=1; }
//  **taustes punkti saskaitīti**
    //vizuālie  - 2,3,7,10,14,16,19,22
	//taustes   - 4,6,9,12,15,17,20,23
	//dzirdes   - 1,5,8,11,13,18,21,24 
	
//pārbaudes uz lauku aizpildīsanu	
	if($dzirdes>40||$taustes>40||$viz>40) {echo "<i>Nav ievadītas atbildes uz vienu vai vairākiem jautājumiem!</i><br/><br/><a href='javascript:history.back(1);'>Atpakaļ</a>"; die();}
	//exit("Nav pareizi atbildēts");
	


 
//	
									//ierakstīšana db
//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------
 
//definee klasi
$testtype='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testtype),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testtype;
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
							else {
								$artefacttypeid=$res[$testtype];
								//echo "<br>AR= ".$artefacttypeid;
							}

//--------------------------------------------------------------------------------------
			if ($courseid!=0)
{



//parbauda vai ir ieraksts v_user_artefact_all
//$source_ir = $DB->get_record('v_user_artefact_all', array('userid'=>$userid,'source'=>$testname));
$table = 'v_user_artefact_all';
$select="userid='$USER->id' and source='$testname'";
$source_ir = $DB->get_records_select($table,$select);

//vispirms ieprieksejos dzes
if (!empty($source_ir)) {
$DB->delete_records_select($table, $select); 	}


//if (empty($source_ir)) //nav ieraksta par testu
			//{
			//-----		ieraksta tabulaa					v_user_artefact_all-----------

			$record3 = new stdClass();
			$record3->artefacttypeid= $artefacttypeid;
			$record3->userid= $userid;
			$record3->ctime= time();
			$record3->source= $testname;
			$record3->description= 'mācīšanās stils';
			//dabūt artefactid
			$lastid=$DB->insert_record('v_user_artefact_all', $record3);

			//------------		ieraksta tabulaa			v_user_learningstyle-----
			$recordlsv = new stdClass();
			$recordlsv->artefactallid= $lastid;
			$recordlsv->lstylename= 'v';
			$recordlsv->value= $viz;
			$DB->insert_record('v_user_learningstyle', $recordlsv,false);

			$recordlsa = new stdClass();
			$recordlsa->artefactallid= $lastid;
			$recordlsa->lstylename= 'a';
			$recordlsa->value= $dzirdes;
			$DB->insert_record('v_user_learningstyle', $recordlsa);

			$recordlsk = new stdClass();
			$recordlsk->artefactallid= $lastid;
			$recordlsk->lstylename= 'k';
			$recordlsk->value= $taustes;
			$DB->insert_record('v_user_learningstyle', $recordlsk);
		



echo "</br>Dati ierakstīti datu bāzē!<br/>";

//-------------- ieraksta beigas db
//} //beidzas ieraksts
//else
{//echo "</br>Šo testu Jūs esat veicis atkārtoti, tāpēc datu bāzē ieraksts netika veikts!</br></br>";




}
}//kursa parbaude
            echo "<div id='results'>Dzirdes atmiņas punkti:</br>  $dzirdes / 40 </div>";
		    echo "<div id='results'>Redzes atmiņas punkti:</br>  $viz / 40 </div>";
		    echo "<div id='results'>Taustes atmiņas punkti:</br>  $taustes / 40 </div>";
if($dzirdes==$taustes&&$dzirdes==$viz){echo "<h3>Tests norāda, ka jums ir visi trīs atmiņas veidi. </br></br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Irakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";	
//exit;
}	else 	
if ($viz>$taustes&&$viz>$dzirdes)echo "<h3>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>"; else
if ($taustes>$viz&&$taustes>$dzirdes)echo "<h3>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</h3>"; else
if ($dzirdes>$taustes&&$dzirdes>$viz)echo "<h3>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Rakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</h3>";
else if ($dzirdes==$viz)echo "<h3>Tests norāda, ka jums ir dzirdes un redzes atmiņa. </br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Ierakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";
else if($viz==$taustes)echo "<h3>Tests norāda, ka jums ir taustes un redzes atmiņa. </br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot 
visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";
else if($dzirdes==$taustes)echo "<h3>Tests norāda, ka jums ir taustes un dzirdes atmiņa. </br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Irakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</h3>";
            

 ?>
	
	</div>


</body>
</html>