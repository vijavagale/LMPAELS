﻿<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Kursu</a>
<h2>VAK mācīšanās stila rezultāti (VARK2)</h2>
<p>Testu var veikt vairākas reizes!</p>
<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
//require_once("../../../../../config.php") ;
$testname = "vark2";
$c_visual=0;
$c_auditory=0;
$c_kinesthetic=0;

foreach(array_keys($_POST) as $i){
if (substr($i,0,1)=='s') $c_visual+=$_POST[$i];
if (substr($i,0,1)=='x') $c_auditory+=$_POST[$i];
if (substr($i,0,1)=='y') $c_kinesthetic+=$_POST[$i];
}

//paarbaude

$source_ir = $DB->get_record('v_user_artefact_all', array('userid'=>$USER->id,'source'=>$testname));

//if ($source_ir==false)
//{
$testtype='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testtype),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testtype;
					$artefacttypeid=$DB->insert_record('v_user_artefact_type', $record);}
					else $artefacttypeid=$res[$testtype];

					
//dzes ieprieksejos
$table = 'v_user_artefact_all';
$select="userid='$USER->id' and source='$testname'";
$source_ir = $DB->get_records_select($table,$select);
if (!empty($source_ir)) {
$DB->delete_records_select($table, $select); 	}					
					
$record = new stdClass();
$record->artefacttypeid= $artefacttypeid;
$record->userid= $USER->id;
$record->ctime= time();
$record->source= $testname;
$record->description= 'mācīšanās stils';
//dabūt artefactid
$lastid=$DB->insert_record('v_user_artefact_all', $record);

//------------		ieraksta tabulaa			v_user_learningstyle-----
$recordlsv = new stdClass();
$recordlsv->artefactallid= $lastid;
$recordlsv->lstylename= 'v';
$recordlsv->value= $c_visual;
$DB->insert_record('v_user_learningstyle', $recordlsv,false);

$recordlsa = new stdClass();
$recordlsa->artefactallid= $lastid;
$recordlsa->lstylename= 'a';
$recordlsa->value= $c_auditory;
$DB->insert_record('v_user_learningstyle', $recordlsa);

$recordlsk = new stdClass();
$recordlsk->artefactallid= $lastid;
$recordlsk->lstylename= 'k';
$recordlsk->value= $c_kinesthetic;
$DB->insert_record('v_user_learningstyle', $recordlsk);
echo "</br>Dati ierakstīti datu bāzē!";
//} else echo "</br>Jūs šo testu jau esat veicis agrāk, tāpēc ieraksts datu bāzē netika veikts!</br>";
//-------------- ieraksta beigas db
        
		
echo '</br>Kopējais punktu skaits katram mācīšanās stilam : </br></br>';

echo '<table border="2" cellpadding="6" width="50%">
<tr>
<td align="center"><b>Vizuālais mācīšanās stils</b></td>
<td align="center"><b>Dzirdes mācīšanās stils</b></td>
<td align="center"><b>Kinestētiskais mācīšanās stils</b></td>
</tr>
<td align="center">Punktu skaits :<br/>'.$c_visual.'</td>
<td align="center">Punktu skaits:<br/>'.$c_auditory.'</td>
<td align="center">Punktu skaits:<br/>'.$c_kinesthetic.'</td>
<tr>

</tr>
</table>';
echo "<br/>";

?>
	
</body>
</html>