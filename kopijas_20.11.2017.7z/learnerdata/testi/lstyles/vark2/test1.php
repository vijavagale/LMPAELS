﻿<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
require_once("../../../../../config.php") ;
require_once("../../../my_lib.php") ;

$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;


$testname = "vark2";  	
//22.05.2017	
$table = 'v_user_artefact_all';
$select="userid='$USER->id' and source='$testname'";
$source_ir = $DB->get_records_select($table,$select);
//$source_ir = $DB->get_records_menu('v_user_artefact_all', array('userid'=>$USER->id,'id','source'=>$testname));
if (!empty($source_ir) and !isset($_POST['submit']))
{
echo "</br><b>Jūs šo testu jau esat veicis agrāk, tāpēc ja nevēlaties vēlreiz pildīt, tad izejiet no testa, citādi dati tiks pārrakstīti! </b>";
echo "<a href='javascript:window.history.go(-1);'><br/>Atpakaļ uz Kursu</a>";
//die();
}	



if(isset($_POST['submit']))
{
include('rez.php');
exit();
}
?>

<html>
<title> stili</title>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>

<h1>Mācīšanās stila noteikšana (VAK2)</h1>
<p>Atkarībā no Jūsu sniegtajām atbildēm tiks noteikts Jums piemērotākais mācību stils, kuru sistēma izmantos Jūsu adaptīvā kursa izveidei!</p>

<div>Rūpīgi izlasiet katru apgalvojumu.
Pa kreisi no katra apgalvojuma, ievadiet skaitli, kas visprecīzāk raksturo veidu, kā katrs apgalvojums attiecas uz jums, izmantojot šādus norādījumus :</div>&nbsp;

<table border="2" cellpadding="6" width="50%">
<tr>
<td align="center"><b>1</b></td>
<td align="center"><b>2</b></td>
<td align="center"><b>3</b></td>
<td align="center"><b>4</b></td>
<td align="center"><b>5</b></td>
</tr>
<td align="center">Gandrīz nekad neattiecas</td>
<td align="center">Ļoti reti attiecas</td>
<td align="center">Dažreiz attiecas</td>
<td align="center">Bieži attiecas</td>
<td align="center">Gandrīz vienmēr attiecas</td>
<tr>

</tr>
</table>
</br>
Atbildiet godīgi, jo nav ne pareizo, ne nepareizo atbilžu.<br/>
Labāk pārāk ilgi nedomājiet par jautājumu, jo tas var novest līdz nepareizajam rezultātam.<br/><br/>
 Jums vajadzēs atbildēt uz 36 jautājumiem (12 jautājumi katrā sadaļā).

<form action="" method="post">

<h1>Vizuālais mācīšanās stils</h1>
&nbsp;&nbsp;&nbsp;
<select name="s1" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;1. Es pierakstu piezīmes un/vai prātā veidoju domu kartes.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s2" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;2. Kad es runāju ar kādu, man ir grūti saprast tos, kuri nesaglabā acu kontaktu ar mani.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s3" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;3. Es veidoju sarakstus un piezīmes, jo es labāk atceros lietas, ja pierakstu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s4" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;4. Kad es lasu kādu literāru darbu, es pievēršu lielu uzmanību fragmentiem, kuri man palīdz iztēloties dekorācijas, apģērbu un vietu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s5" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;5. Man vajag pierakstīt virzienus, jo tā es tos labāk atceros.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s6" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;6. Man vajag redzēt personu, ar kuru es runāju, lai saglabātu uzmanību sarunas tematam.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s7" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;7. Kad es satieku cilvēku pirmo reizi, vispirms es ievēroju viņa ģērbšanās stilu,vizuālās īpatnības un kārtīgumu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s8" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;8. Kad es esmu ballītē, viena no lietām, ko man patīk darīt, ir stāvēt malā un vērot citus cilvēkus.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s9" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;9. Kad es atceros informāciju, es to redzu savā prātā un atceros, kur esmu to redzējis.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s10" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;10. Ja man ir jāpaskaidro kāda procedūra vai darbības tehnika, es dodu priekšroku to uzrakstīt.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s11" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;11. Savā brīvajā laikā es, visdrīzāk, skatos televīziju vai lasu grāmatas.<br/>
&nbsp;&nbsp;&nbsp;
<select name="s12" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;12. Ja mans priekšnieks vēlas man ko paziņot, tad man visērtāk, ja viņš nosūta to kā ziņojumu.<br/>
&nbsp;&nbsp;&nbsp;
<h1>Audiālais mācīšanās stils</h1>
&nbsp;&nbsp;&nbsp;
<select name="x1" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;1. Es lasu skaļi vai kustinu savas lūpas, lai dzirdētu vārdus savā galvā.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x2" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;2. Kad es runāju ar kādu, man ir grūti saprast tos, kuri nerunā ar mani vai man neatbild.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x3" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;3. Es nerakstu daudz piezīmju, jo es atceros, ko man saka. Piezīmju rakstīšana bieži novērš manu uzmanību no runātāja.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x4" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;4. Kad es lasu literāru darbu, es pievēršu lielu uzmanību fragmentiem, kuros notiek sarunas, dialogi.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x5" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;5. Es runāju ar sevi, kad risinu problēmas vai rakstu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x6" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;6. Es varu saprast, ko man saka pat tad, kad neesmu koncentrējies uz runātāju. <br/>
&nbsp;&nbsp;&nbsp;
<select name="x7" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;7. Es daudz labāk atceros lietas, ja tās nemitīgi atkārtoju.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x8" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;8. Viena no lietām, ko man patīk darīt pasākumā ar labu sarunbiedru, ir runāt padziļināti par man svarīgu tēmu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x9" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;9. Es labprātāk saņemtu informāciju klausoties radio, nekā lasot avīzi.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x10" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;10. Ja man ir jāpaskaidro kāda procedūra vai darbības tehnika, es labāk par to pastāstītu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x11" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;11. Savā brīvajā laikā es dodu priekšroku mūzikas klausīšanai.<br/>
&nbsp;&nbsp;&nbsp;
<select name="x12" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;12. Ja mans priekšnieks vēlas man ko paziņot, tad man visērtāk, ja viņš piezvana man pa telefonu.<br/>
&nbsp;&nbsp;&nbsp;
<h1>Kinestētiskais mācīšanās stils</h1>
&nbsp;&nbsp;&nbsp;
<select name="y1" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;1. Es neesmu labs lasītājs vai klausītājs. Es labāk uzreiz sāku strādāt pie uzdotā uzdevuma vai projekta. <br/>
&nbsp;&nbsp;&nbsp;
<select name="y2" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;2. Kad es runāju ar kādu, man ir grūti saprast tos, kuri neizrāda nekādu emocionālu vai fizisku atbalstu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y3" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;3. Es pierakstu piezīmes, skricelēju un/vai prātā veidoju domu kartes, bet es reti tajās ieskatos.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y4" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;4. Kad es lasu literāru darbu, es pievēršu lielu uzmanību fragmentiem, kuros tiek atklātas jūtas, garastāvoklis, darbības, drāmas..<br/>
&nbsp;&nbsp;&nbsp;
<select name="y5" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;5. Kad es lasu, es kustinu lūpas.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y6" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;6. Es bieži sajaucu vietu vai lietu nosaukumus, un žestikulēju ar rokām, kad nevaru atcerēties pareizo vārdu.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y7" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;7. Uz mana darba galda valda nekārtība.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y8" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;8. Kad es esmu pasākumā, man patīk pilnībā nodoties aktivitātēm, piemēram, dejošanai, spēļu spēlēšanai.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y9" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;9. Man patīk būt kustībā. Es jūtos kā ieslodzījumā, ja sēžu sanāksmē vai pie darba galda.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y10" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;10. Ja man ir jāpaskaidro kāda procedūra vai darbības tehnika, es dodu priekšroku to nodemonstrēt.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y11" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;11. Savā brīvajā laikā es dodu priekšroku fiziskajām aktivitātēm.<br/>
&nbsp;&nbsp;&nbsp;
<select name="y12" value="1">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>&nbsp;&nbsp;12. Ja mans priekšnieks vēlas man ko paziņot, tad man visērtāk, ja viņš to paziņo man personīgi.<br/>

<br/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Iesniegt testu" /></form>

</body>
</html>