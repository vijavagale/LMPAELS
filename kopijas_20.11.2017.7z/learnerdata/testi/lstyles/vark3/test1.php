﻿<meta charset='utf-8 '>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Kursu</a>
<h1>&nbsp;&nbsp;&nbsp;&nbsp;Mācīšanās stila noteikšana (VARK3)</h1>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atkarībā no Jūsu sniegtajām atbildēm tiks noteikts Jums piemērotākais mācību stils, kuru sistēma izmantos Jūsu adaptīvā kursa izveidei!</p>


<?php 
require_once("../../../../../config.php") ;
$instanceid=$_SESSION['instance'];

$testname = "vark3";
//echo "userid=".$USER->id;
$is_answer=1; 

//$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testtype),'id','artefacttype,id');
$table = 'v_user_artefact_all';
$select="userid='$USER->id' and source='$testname'";
$source_ir = $DB->get_records_select($table,$select);
//$source_ir = $DB->get_records_menu('v_user_artefact_all', array('userid'=>$USER->id,'id','source'=>$testname));
if (!empty($source_ir) and !isset($_POST['submit']))
{
echo "</br><b>Jūs šo testu jau esat veicis agrāk, tāpēc ja nevēlaties vēlreiz pildīt, tad izejiet no testa, citādi dati tiks pārrakstīti! </b>";
echo "<a href='javascript:window.history.go(-1);'><br/>Atpakaļ uz Kursu</a>";
//die();
}			
	


if(isset($_POST['submit']))
{
$atb=new atbildes();

for ($i=0; $i<16 && $is_answer!=0; $i++)
  { 
  $ia=0;
  for ($a=1; $a<5 ; $a++)
  {
	$ind="q{$i}{$a}";     	
	if(isset($_POST[$ind]))
   {    
  
   $atb->get_answers_from_test($_POST[$ind]);
   $ia=1;  
   } 
    }  
	if ($ia!=1)$is_answer=0;  
  }
 
  if ($is_answer==0){ echo "<i>Nav ievadītas atbildes uz vienu vai vairākiem jautājumiem!</i><br/><br/><a href='javascript:history.back(1);'>Atpakaļ</a>"; die();}
  else{
    

//echo "<pre>";
//print_r($source_ir);
//echo "</pre>";
$v=$atb->get_Visual();
$a=$atb->get_Aural();
$r=$atb->get_ReadWrite();
$k=$atb->get_Kinesthetic();



	
//echo "Ieraksta 2. tabula";

//panemt visus ierakstus
//=-==============
/*
$sql="SELECT
			ra.id,
			ra.roleid,
			ra.contextid
			FROM
				 mdl_role_assignments ra
			WHERE
			ra.userid = '$userid'
			 ORDER BY ra.contextid";
			
$results = $DB->get_records_sql($sql, null, IGNORE_MISSING);
		$z=0;
		foreach ($results as $id => $record) {
							//echo "<br>id= ".$record->id;
							//echo "<br>contextid= ".$record->contextid;
							$userrol=$record->roleid;
							if ($record->contextid==$cci) { $z=1; break;}
							}	

							
							//peec id pedejo ierakstu panemt
SELECT id, category_id, post_title
FROM posts
WHERE id IN (
    SELECT MAX(id)
    FROM posts
    GROUP BY category_id
);

*/
//=========================
//-----		ieraksta tabulaa					user_artefact_all-----------
//definee klasi
$testtype='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testtype),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testtype;
					$artefacttypeid=$DB->insert_record('v_user_artefact_type', $record);}
					else $artefacttypeid=$res[$testtype];

//desana ierakstu
/*
o delete_records($table, $field1=, $value1=, $field2=, $value2=, $field3=, $value3=) 
           Delete the records from a table where all the given fields match the given values.
         o delete_records_select($table, $select=) 
           Delete one or more records from a table
*/
if (!empty($source_ir)) {
$DB->delete_records_select($table, $select); 	}
					
					
//jauna ieraksta pievienosana
$record = new stdClass();
$record->artefacttypeid= $artefacttypeid;
$record->userid= $USER->id;
$record->ctime= time();
$record->source= $testname;
$record->description= 'mācīšanās stils';
//dabūt artefactid
$lastid=$DB->insert_record('v_user_artefact_all', $record);

//------------		ieraksta tabulaa			user_learningstyle-----
$recordlsv = new stdClass();
$recordlsv->artefactallid= $lastid;
$recordlsv->lstylename= 'v';
$recordlsv->value= $v;
$DB->insert_record('v_user_learningstyle', $recordlsv);

$recordlsa = new stdClass();
$recordlsa->artefactallid= $lastid;
$recordlsa->lstylename= 'a';
$recordlsa->value=$a; 
$DB->insert_record('v_user_learningstyle', $recordlsa);

$recordlsrw = new stdClass();
$recordlsrw->artefactallid= $lastid;
$recordlsrw->lstylename= 'r';
$recordlsrw->value= $r;
$DB->insert_record('v_user_learningstyle', $recordlsrw);

$recordlsk = new stdClass();
$recordlsk->artefactallid= $lastid;
$recordlsk->lstylename= 'k';
$recordlsk->value= $k;
$DB->insert_record('v_user_learningstyle', $recordlsk);

echo "</br> </br>Dati ierakstīti datu bāzē!";
//} else echo "</br>Jūs šo testu jau esat veicis agrāk, tāpēc ieraksts datu bāzē netika veikts!";	
	

	
        echo "<br/><br/>Jūsu rezultāts ir: <br/>".$atb->get_result();  
        echo "<br/><br/>Kategorija, kurai ir visvairāk punktu atbilst jūsu piemērotākajam mācīšanās stilam. <br/>Ja neviena no kategorijām nav dominējoša, tad jums ir multimodāls
	         mācīšanās stils un jūs spējat uztvert un apstrādāt informāciju dažādos veidos.<br/>";
		echo "<br/><b>Vizuālais</b> - Jūs labāk uztverat vizuālu informāciju, piemēram, attēlus, diagrammas. Jums interesē krāsas, dizains, izkārtojums.";
        echo "<br/><b>Dzirdes</b> - Jums patīk, ka jums izskaidro. Uzrakstīti vārdi jums nav tik svarīgi kā dzirdētie. Jums patīk piedalīties diskusijās.";
		echo "<br/><b>Lasīšanas/Rakstīšana</b> - Jūs dodat priekšroku rakstītai informācijai. Jums liekas, ka rakstītai informācijai ir lielāka nozīme un jums šādu informāciju ir vieglāk iegaumēt. Iespējams jums patīk daudz lasīt.";
		echo "<br/><b>Darbošanās</b> - Lai saprastu, jums ir jāpamēģina. Jūs dodat priekšroku eksperimentiem un teorētiskās informācijas pielietošanai praktiskos uzdevumos.";

echo "</br></br>";		
//echo "<a href='javascript:window.history.go(-2);'>Atpakaļ uz Kursu</a>"; 

die(); 
	   

	   }



} 
 ?>
<form action=""  method="post" id="14tests">
<table border="0" cellpadding="6" width="80%">
<tr>
<td></td>
<td >
<a> <br>Katram jautājumam atzīmējiet vismaz vienu atbildi (bet var būt arī vairākas atbildes), kas atbilst jums!<a><br/><br/>
<b>1. Man patīk interneta vietnes, kurās ir</b><br /><br/>
	<input type="checkbox" name="q01" value="K">Lietas, uz kurām var klikšķināt.</input><br />
	<input type="checkbox" name="q02" value="A">Mūzika, čats, diskusijas.</input><br />
	<input type="checkbox" name="q03" value="R">Interesanta informācija un raksti.</input><br />
	<input type="checkbox" name="q04" value="V">Interesants dizains un vizuālie efekti. </input><br /><br/>
<b>2. Jūs īsti nezināt, kā jāraksta vārds 'dependent' vai'dependant'. Es:</b><br /><br/>
	<input type="checkbox" name="q11" value="V">Iedomātos, kā abi vārdi izskatās un izvēlētos.</input><br />
	<input type="checkbox" name="q12" value="A">Izrunātu abus vārdus skaļi vai iedomātos, kā tie skan.</input><br />
	<input type="checkbox" name="q13" value="R">Meklētu vārdnīcā.</input><br />
	<input type="checkbox" name="q14" value="K">Uzrakstītu abus vārdus uz papīra un izvēlētos vienu.</input><br /><br/>
<b>3. Jūs plānojat pārsteiguma ballīti draugam. Es:</b><br /><br/>
	<input type="checkbox" name="q21" value="K">Ielūgtu draugus un vienkārši ļautu ballītei notikt.</input><br />
	<input type="checkbox" name="q22" value="V">Iztēlotos, kā balītei jānotiek.</input><br />
	<input type="checkbox" name="q23" value="R">Izveidotu sarakstu ar darāmajām lietām un pērkamajām precēm ballītei.</input><br />
	<input type="checkbox" name="q24" value="A">Runātu par to ar citiem pa telefonu vai sarakstītos.</input><br /><br/>
<b>4. Jūs taisāties sarīkot kaut ko īpašu savai ģimenei. Es: </b><br /><br/>
	<input type="checkbox" name="q31" value="K">Izveidotu kaut ko iepriekš veidotu.</input><br />
	<input type="checkbox" name="q32" value="A">Parunātu par to ar draugiem.</input><br />
	<input type="checkbox" name="q33" value="V">Pameklētu idejas un plānus grāmatās un žurnālos.</input><br />
	<input type="checkbox" name="q34" value="R">Atrastu rakstītas instrukcijas, lai to izveidotu.</input><br /><br/>
<b>5. Jūs esat izvēlēts kā brīvdienu programmas līderis. Tas ir interesanti Jūsu draugiem. Es:</b><br /><br/>
	<input type="checkbox" name="q41" value="A">Aprakstītu aktivitātes, kuras darīšu programmā.</input><br />
	<input type="checkbox" name="q42" value="V">Parādītu viņiem fotogrāfijas un karti ar programmas norises vietām.</input><br />
	<input type="checkbox" name="q43" value="K">Sāktu mēģināt aktivitātes, kuras pildīšu programmā.</input><br />
	<input type="checkbox" name="q44" value="R">Parādītu viņiem programmas aktivitāšu sarakstu.</input><br /><br/>
<b>6. Jūs taisāties pirkt jaunu fotokameru vai mobilo telefonu. Kas(izņemot cenu) visvairāk ietekmētu jūsu izvēli?</b><br /><br/>
	<input type="checkbox" name="q51" value="K">Preces izmēģināšana.</input><br />
	<input type="checkbox" name="q52" value="R">Preces specifikāciju izlasīšana.</input><br />
	<input type="checkbox" name="q53" value="V">Preces jaunākais dizains un tā labais izskats.</input><br />
	<input type="checkbox" name="q54" value="A">Pārdevēja viedoklis par preci.</input><br /><br/>
<b>7. Atcerieties, kad mācījāties spēlēt kādu datorspēli vai galda spēli. Vislabāk sanāca mācīties:</b><br /><br/>
	<input type="checkbox" name="q61" value="K">Skatoties, kā to dara citi.</input><br />
	<input type="checkbox" name="q62" value="A">Klausoties kāda skaidrojumu un uzdotot jautājumus.</input><br />
	<input type="checkbox" name="q63" value="V">No instrukciju diagrammām.</input><br />
	<input type="checkbox" name="q64" value="R">Lasot instrukcijas.</input><br /><br/>
<b>8. Pēc lugas izlasīšanas, jums jāizveido projekts. Kam jūs dotu priekšroku?</b><br /><br/>
	<input type="checkbox" name="q71" value="R">Uzrakstītu par lugu.</input><br />
	<input type="checkbox" name="q72" value="K">Notēlotu kādu lugas ainu.</input><br />
	<input type="checkbox" name="q73" value="V">Uzzīmētu vai uzsckicētu kaut ko, kas notika lugā.</input><br />
	<input type="checkbox" name="q74" value="A">Izlasītu kādu fragmentu no lugas.</input><br /><br/>
<b>9. Jūs taisāties sagatavot darbam jūsu vecāku jauno datoru. Es:</b><br /><br/>
	<input type="checkbox" name="q81" value="R">Izlasītu datora komplektā iekļauto instrukciju.</input><br />
	<input type="checkbox" name="q82" value="A">Piezvanītu vai uzrakstītu draugam, jautājot, kā to izdarīt.</input><br />
	<input type="checkbox" name="q83" value="K">Atvērtu kasti un sāktu likt tā detaļas kopā.</input><br />
	<input type="checkbox" name="q84" value="V">Skatītos grafisko instrukciju, kas parāda kā to izdarīt.</input><br /><br/>
<b>10. Jums vajag kādam parādīt virzienus, kā nokļūt līdz mājai, kas atrodas netālu. Es </b><br /><br/>
	<input type="checkbox" name="q91" value="K">Aizietu ar viņiem.</input><br />
	<input type="checkbox" name="q92" value="V">Uzzīmētu karti uz papīra.</input><br />
	<input type="checkbox" name="q93" value="R">Uzrakstītu virzienu sarakstu.</input><br />
	<input type="checkbox" name="q94" value="A">Pateiktu virzienus.</input><br /><br/>
<b>11. Jums ir problēmas ar celi. Jūs dotu priekšroku, ja ārsts:</b><br /><br/>
	<input type="checkbox" name="q101" value="V">Parādītu attēlu par to, kas nebija kārtībā.</input><br />
	<input type="checkbox" name="q102" value="R">Iedotu Jums rakstu vai brošūru, kas izskaidrotu ceļu savainojumus.</input><br />
	<input type="checkbox" name="q103" value="A">Aprakstītu, kas nebija kārtībā.</input><br />
	<input type="checkbox" name="q104" value="K">Demonstrētu problēmu, izmantojot ceļa modeli.</input><br /><br/>
<b>12. Kinoteātrī var noskatīties jaunu filmu. Kas visvairāk ietekmētu Jūsu izvēli, iet vai neiet? </b><br /><br/>
	<input type="checkbox" name="q111" value="A">Jūs dzirdat draugus sarunājamies par to.</input><br />
	<input type="checkbox" name="q112" value="R">Jūs lasāt, ko citi par to saka tiešsaistē var žurnālā.</input><br />
	<input type="checkbox" name="q113" value="V">Jūs noskatāties filmas reklāmu.</input><br />
	<input type="checkbox" name="q114" value="K">Jūs uzzinātu, vai tā ir līdzīga citām redzētajām.</input><br /><br/>
<b>13. Jums labāk patīk, ja skolotājs:</b><br /><br/>
	<input type="checkbox" name="q121" value="K">Veic demonstrējumus, parāda modeļus vai rīko praktiskās nodarbības.</input><br />
	<input type="checkbox" name="q122" value="A">Organizē klases diskusijas, tiešsaistes diskusijas, tērzētavu.</input><br />
	<input type="checkbox" name="q123" value="R">Izmanto burtnīcas un izdales materiālus.</input><br />
	<input type="checkbox" name="q124" value="V">Izmanto shēmas, pārskata diagrammas, marķētas diagrammas un kartes.</input><br /><br/>
<b>14. Jūs mācāties uzņemt fotogrāfijas ar jūsu jauno kameru vai mobilo telefonu. Es gribētu, lai man būtu</b><br /><br/>
	<input type="checkbox" name="q131" value="K">Labu un sliktu fotogrāfiju piemēri un kā tos uzlabot.</input><br />
	<input type="checkbox" name="q132" value="R">Skaidri uzrakstītas instrukcijas ar sarakstiem un aizzīmju punktiem.</input><br />
	<input type="checkbox" name="q133" value="A">Iespēja uzdot jautājumus un runāt par kameras iespējām.</input><br />
	<input type="checkbox" name="q134" value="V">Grafiska instrukcija, kas parāda kā lietot kameru.</input><br /><br/>
<b>15. Jūs vēlaties kādas atsauksmes par notikumu, sacensībām vai testu. Es vēlētos atsauksmes:</b><br /><br/>
	<input type="checkbox" name="q141" value="K">Kas izmantotu piemērus no manis darītā.</input><br />
	<input type="checkbox" name="q142" value="A">No personas, kas ar mani par to ir runājusi.</input><br />
	<input type="checkbox" name="q143" value="R">Kurās ir manu rezultātu analīze vai apraksts.</input><br />
	<input type="checkbox" name="q144" value="V">Kas iekļauj sevī grafikus, kas parāda manus sasniegumus.</input><br /><br/>
<b>16. Jums ir jāprezentē idejas savai klasei. Es:</b><br /><br/>
	<input type="checkbox" name="q151" value="V">Izveidotu diagrammas vai grafikus, kas paskaidro manas idejas.</input><br />
	<input type="checkbox" name="q152" value="A">Uzrakstītu plānu un vairākkārt mēģinātu atkārtot savu runu.</input><br />
	<input type="checkbox" name="q153" value="R">Uzrakstītu savu runu un mācītos to lasot vairākas reizes.</input><br />
	<input type="checkbox" name="q154" value="K">Meklētu piemērus un stāstus, lai padarītu prezentāciju reālāku un praktiskāku.</input><br />



</td>

</tr>

</table>



<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b><input type="submit" name="submit" value="Iesniegt testu"></b><br>
</form>

<?PHP 

class atbildes
{  
  public $Visual=0;
   public $Aural=0;
  public $ReadWrite=0;
  public $Kinesthetic =0;
 // private $name;
  private $result;
  //private $vertejums; 
  private $answers=array();  
public $atb;
/*public function Set_Name($n)
{
 $this->name=$n;
} */ 
public function get_Visual()
{ return $this->Visual;}
public function get_Aural()
{ return $this->Aural;}
public function get_ReadWrite()
{ return $this->ReadWrite;}
public function get_Kinesthetic()
{ return $this->Kinesthetic;}
public function get_result()
{
$this->result="<br/>Vizuālais= ".$this->Visual.", <br/>Dzirdes= ".$this->Aural.", <br/>Lasīšana/Rakstīšana= ".$this->ReadWrite.", <br/>Darbošanās= ".$this->Kinesthetic;
 return $this->result;
} 
/* 
public function Set_Vertejums($n)
{
 $this->vertejums=$n; 
		
} */
  public function get_answers_from_test($a)
  {    
       array_push($this->answers,$a);
	    if ($a=='V') $this->Visual++; else
		if ($a=='A') $this->Aural++; else
		if ($a=='R') $this->ReadWrite++; else
		if ($a=='K') $this->Kinesthetic ++; 	
$atb = "$this->Visual / $this->Aural";
  }

};

 
?>


