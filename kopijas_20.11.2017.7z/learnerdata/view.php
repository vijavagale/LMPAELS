<?php
 
require_once('../../config.php');
require_once($CFG->libdir .'/setuplib.php');  
//require_once('learnerdata_form.php');
 global $DB, $OUTPUT, $PAGE;

require_once('../../config.php');
$cmid = required_param('id', PARAM_INT);
$cm = get_coursemodule_from_id('mymodulename', $cmid, 0, false, MUST_EXIST);
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
/* 
// Check for all required variables.
$courseid = required_param('courseid', PARAM_INT);
 
 
if (!$course = $DB->get_record('course', array('id' => $courseid))) {
    print_error('invalidcourse', 'block_learnerdata', $courseid);
}
 
require_login($course);
 
$simplehtml = new learnerdata_form();
 
$learnerdata->display();*/
?>