<a href='javascript:window.history.go(-3);'>Atpakaļ uz Moodle</a>
<?php
global $CFG;
global $COURSE;
require_once("../../../../config.php") ;
require_login();

echo "<H3>Kursa grupas</H3>";
$value= 'Kurss 2';
$course = $DB->get_records_menu('course',array('fullname'=>$value),'id','fullname,id'); 
$courseid=$course[$value];
$pazime=array();
$skaits=$_POST['skaits'];
$pazime[0]=$_POST['pazime1'];
$pazime[1]=$_POST['pazime2'];
$pazime[2]=$_POST['pazime3'];
$pazime[0][0]=$_POST['p1vertiba1'];	 
$pazime[0][1]=$_POST['p1vertiba2'];	
$pazime[1][0]=$_POST['p2vertiba1'];	 
$pazime[1][1]=$_POST['p2vertiba2'];
$pazime[1][2]=$_POST['p2vertiba3'];	
$pazime[2][0]=$_POST['p3vertiba1'];	 
$pazime[2][1]=$_POST['p3vertiba2'];
$pazime[2][2]=$_POST['p3vertiba3'];
$pazime[2][3]=$_POST['p3vertiba4'];
$pazime[2][4]=$_POST['p3vertiba5'];
//echo "tests= ".$_POST['p3vertiba5'];
//echo "tests= ".$pazime[2][4]; 



//HTML tabulas veidošana
echo "<table border='1' cellpadding='2' cellspacing='2' width='20%' style='font-size:12px'>
<tr>
<th>Grupas numurs</th>
<th>PK</th>
<th>DL</th>
<th>LS</th>
</tr>";

$n=1;
$i=0;$j1=$j2=0;
for ($j1=0;$j1<2&&$n<=30;$j1++)
for ($j2=0;$j2<3;$j2++)
for ($j3=0;$j3<5;$j3++)
	{
	echo "<tr>
			<td>".$n."</td>
			<td>".$pazime[$i][$j1]."</td>";
	echo "<td>".$pazime[$i+1][$j2]."</td>";
	if ($i+2==2 && $j3==4) $vv='va'; else $vv=$pazime[$i+2][$j3];
	echo "<td>".$vv."</td>";
	echo "</tr>";
//ieraksts tabulā

//DB tabulas "clg" aizpildisana 
$course_ir = $DB->get_record('v_clg', array('courseid'=>$courseid));
if ($course_ir==false)
				{
						$record = new stdClass();
						$record->courseid=$courseid;
						$record->group_number=$n;
						$record->pk=$pazime[$i][$j1];
						$record->dl=$pazime[$i+1][$j2];
						$record->ls=$vv;
						$table='v_clg';
						$lastid=$DB->insert_record($table, $record);
				}

	
$n++;
}


echo "</table";
?>