
<?php 
    class form{
	
        private $lauku_skaits;

		public function __construct($skaits){
            $this->lauku_skaits=$skaits;//visu paziimju skaits		
		}

		public function set_lauku_skaits($skaits){
            $this->lauku_skaits=$skaits;//cik paziimju lauku buuus
		}
		public function get_lauku_skaits(){
		    return $this->lauku_skaits;
		}
		public function __toString(){
	        $return_form="";
			
			if($this->get_lauku_skaits()>0)
			{//<form action="action_page.php">
			    $return_form.="<form method=post id=\"forma\" action=\"apstrade.php\">"; //veido formu
				
				for($i = 0;$i<$this->get_lauku_skaits();$i++)
				{
				$return_form .=($i+1).".<input type=text name=pazime$i value=\"\">
				<input id=\"button$i\" onclick=\"addField('field$i')\" type=button value=\"Add\">
				<input id=\"button$i\" onclick=\"removeField('field$i')\" type=button value=\"Remove\">
				<div id=\"field$i\"></div><br />";
				
				}
				//$return_form.="<input type=button value=\"veidot\" onclick=\"readData()\">";
					//mana submit poga
				$return_form.="<input type=submit value=\"go\" >";
			
				// <input type=submit value="Veidot" />
				$return_form.="</form>
				<br/><div id=\"izvads\"></div>";
			}
			else //$return_form="Lūdzu ievadiet cik pazīmes tiks norādītas!";
			$return_form="";
			return $return_form;
		}
    }

?>
<script>

    function addField(idField) {
      
	    var container=document.getElementById(idField);
		//var counter= 0;
		//var itxt="INPUT";
				
        var inputText=document.createElement("input");		
        inputText.type="text";
		//inputText.name="name";
        container.appendChild(inputText);
		container.appendChild(document.createElement("br"));		
    }
	
    function removeField(idField){
		var container=document.getElementById(idField);
		if(container.childNodes.length>0)
		for(var i=0;i<2;i++)
		container.lastChild.remove();
	}
	function readData(){
		var form=document.getElementById("forma");
		
		var pazimes = new Array();
		for(var i=0; i < form.length;i++){
			if(form[i].type=="text"){
				if(form[i].name!=""){
					pazimes[pazimes.length]=(new Array());
					pazimes[pazimes.length-1][0]=form[i].value;//katrs [0] ir pazimes value
				}else{
					pazimes[pazimes.length-1].push(form[i].value);
				}//else
			}//2nd if
		}//base if
		var correct = true;
		for(var i=0;i<pazimes.length;i++)
		{
		for(var j=0;j<pazimes[i].length;j++)
		if(pazimes[i][j]=="")
		correct=false;
		}
		if(correct)
		createGroups(pazimes);
	}
	function createGroups(pazimes){
	var div = document.getElementById('izvads');
	if(div.childNodes.length>0)
	div.lastChild.remove();
		 var table = document.createElement('table');
		 table.border=1;
		 table.align="center";
		 //izveido tabulas kolonnu nosaukumus
		//row.insertCell().innerHTML="Grupas";
		var count=1;
		for(var i=0;i<pazimes.length;i++){
			count=count*(pazimes[i].length-1);
		}
		
		var maxRows=Array();
		for(var i =0;i<pazimes.length;i++){
			maxRows[i]=(pazimes[i].length-1);
		}
		
		var tk=Array();//pārmet values nevis pointerus
		for(var i =0;i<pazimes.length;i++){
			tk[i]=1;
		}
		
		
			while(tk[0]!=(maxRows[0]+1)){
			
				var row = table.insertRow(table.length);
				
				for(var i=pazimes.length-1;i>=0;i--){
					row.insertCell().innerHTML=pazimes[i][tk[i]];
				}//ievieto rowus
				row.insertCell().innerHTML=count;
				count--;
				var c=tk.length-1;
				var test=false;
				while(test==false){
					if(tk[c]==maxRows[c]){
					if(c!=0){
						tk[c]=1;
						c--;}
							else{
							tk[c]++;
							test=true;
							}
					}else{
					tk[c]++;
					test=true;
					}
				}
			}
		
		//beidzas
		var row = table.insertRow();
		 for(var i=pazimes.length-1;i>=0;i--){
			var rowcol = row.insertCell();
			rowcol.innerHTML = "<b>"+pazimes[i][0]+"</b>";
		}//ievieto names
			row.insertCell().innerHTML="<b>Nr.</b>";
        
        div.appendChild(table);
	}
</script>