<?php
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_login();
echo "<H3>Kursa apmācāmo grupu veidošana</H3>";

if ($USER->id==2)
{
echo "Lūdzu ievadiet grupu veidošanai izmantoto pazīmju skaitu, pazīmju nosaukumus un to vērtības:<br/><br/>";
echo '<meta charset="UTF-8">
<form method=post action=apstrade.php >
<input type=integer name=skaits value="" > <br/><br/>
<input type=text name=pazime1 > <br/>
&nbsp&nbsp&nbsp<input type=text name=p1vertiba1 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p1vertiba2 ><br/><br/>
<input type=text name=pazime2 > <br/>
&nbsp&nbsp&nbsp<input type=text name=p2vertiba1 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p2vertiba2 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p2vertiba3 ><br/><br/>
<input type=text name=pazime3 > <br/>
&nbsp&nbsp&nbsp<input type=text name=p3vertiba1 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p3vertiba2 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p3vertiba3 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p3vertiba4 ><br/>
&nbsp&nbsp&nbsp<input type=text name=p3vertiba5 ><br/><br/>
<input type=submit value="Veidot grupas" />
</form>';

/*require_once("class.form.php");
if(empty($_POST['skaits']))
$obj=new form(0);
else
{

$obj=new form($_POST['skaits']);}
echo $obj;*/
//============================================================================
//datu vilkšana
 /*function readTblValues()
      {
        var TableData = ‘’;
  
        $(’#tbTableValues’).val(’‘);  // clear textbox
        $(’#sampleTbl tr’).each(function(row, tr){
          TableData = TableData 
              + $(tr).find(‘td:eq(0)’).text() + ’ ’  // Task No.
              + $(tr).find(‘td:eq(1)’).text() + ’ ’  // Date
              + $(tr).find(‘td:eq(2)’).text() + ’ ’  // Description
              + $(tr).find(‘td:eq(3)’).text() + ’ ’  // Task
              + ‘\n’;
        });
        $(’#tbTableValues’).val(TableData);
      }

      function storeAndShowTableValues()
      {
        var TableData;
        TableData = storeTblValues();
        $(’#tbTableValuesArray’).val(‘TableData = \n’ + print_r(TableData));
      }
      function storeTblValues()
      {
        var TableData = new Array();
  
        $(’#sampleTbl tr’).each(function(row, tr){
          TableData[row]={
              “taskNo” : $(tr).find(‘td:eq(0)’).text()
              , “date” :$(tr).find(‘td:eq(1)’).text()
              , “description” : $(tr).find(‘td:eq(2)’).text()
              , “task” : $(tr).find(‘td:eq(3)’).text()
          }
        }); 
        TableData.shift();  // first row will be empty - so remove
        return TableData;
      }
        
      function convertArrayToJSON()
      {
        var TableData;
        TableData = $.toJSON(storeTblValues());
        $(’#tbConvertToJSON’).val(‘JSON array: \n\n’ + TableData.replace(/},/g, “},\n”));
         

      }
      function sendTblDataToServer()
      {
        var TableData;
        TableData = $.toJSON(storeTblValues());
        $(’#tbSendTblDataToServer’).val(‘JSON array to send to server: \n\n’ + TableData.replace(/},/g, “},\n”));
          
        $.ajax({
          type: “POST”,
          url: “http://www.fourfront.us/resources/processJSONArray.php”,
          data: “pTableData=” + TableData,

          success: function(msg){
              // return value stored in msg variable 
              $(’#tbServerResponse’).val(‘Server Response:\\\\\\\\n\\\\\\\\n’ + msg);
          }
        });
      }
        
      function print_r(arr,level) {
        var dumped_text = “”;
        if(!level) level = 0;

        //The padding given at the beginning of the line.
        var level_padding = “”;
        for(var j=0;j<level+1;j++) level_padding += ”  “;

        if(typeof(arr) == ‘object’) { //Array/Hashes/Objects 
for(var item in arr) {
var value = arr[item];

if(typeof(value) == 'object') { //If it is an array,
dumped_text += level_padding + "'" + item + "' \n";
dumped_text += print_r(value,level+1);
} else {
                dumped_text += level_padding + “’” + item + ”’ => \”” + value + “\”\n”;
              }
          }
        } else { //Stings/Chars/Numbers etc.
          dumped_text = “===>”+arr+”<===(”+typeof(arr)+”)”;
        }
        return dumped_text;
      }
  [removed]

*/
}//if
else "Jums nav pieejama šī darbība";
?>