﻿<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];


//$PAGE->url->__toString() interesanti

echo "<H3>Studentiem grupu piešķiršana</H3>";

if (user_rights()==1)
	{	//siim lomaam ir tiesiibas veikt klasificeesanu (pati lielaka iekava
			echo "<br>Jums ir tiesības veikt šo darbību!";
			//parbaude vai kursam ir grupas
	$write=0; 
	$kursa_grupas = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
	$grupu_skaits=count($kursa_grupas);
	echo "<br>grupu skaits= ".$grupu_skaits;
				if ($kursa_grupas==true)
					{$write=1;echo "<br>kursam ir grupas";} 
					else {$write=0;		echo "<br>kursam nav grupu";}
				
				if ($write==1)
					{	//2.lielakā iekava	
					//ta ka ir grupas, tad notiks studentu ieklasificēsana grupās
					$aclg=array();
					$ald=array();
					$result=array();
					$stud=array();
			//veido aclg nem datus no clg tabulas
//echo "<br/>";
//echo "<pre>";
//print_r($kursa_grupas);
//echo "</pre>";
						$pk = $DB->get_record('v_adaptation_features', array('feature'=>'pk'));// izvelk pazīmes id
						$dl = $DB->get_record('v_adaptation_features', array('feature'=>'dl'));// izvelk pazīmes id
						$ls = $DB->get_record('v_adaptation_features', array('feature'=>'ls'));// izvelk pazīmes id
						//echo "<br>pkid= ".$pk->id;
						//echo "<br>pkid= ".$dl->id;
						//echo "<br>pkid= ".$ls->id;
$k=1;				
for ($i=1;$i<=$grupu_skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br>kursa_grupas->group_number= ".$kursa_grupas[$i]->group_number;//ir
			//pec grupas numura jaapanem
						//mas
						$visas_pazimes = $DB->get_records('v_clg_description', array('clgid'=>$kursa_grupas[$i]->group_number));// izvelk šis grupas pazīmes
						//echo "<pre>";
						//print_r($visas_pazimes);
						//echo "</pre>";
						$pazimju_skaits=count($visas_pazimes);//ir
						//echo "<br>pazimju skaits= ".$pazimju_skaits;
						for($j=1;$j<=$pazimju_skaits;$j++)
						{
						//echo "<br><br>pazimes id= ".$visas_pazimes[$k]->adaptation_features_valueid;
						
						$v2 = $DB->get_record('v_adaptation_features_values', array('id'=>$visas_pazimes[$k]->adaptation_features_valueid)); //izvelk pazīmes, veertības id
						//echo "<br>featureid= ".$v2->featureid;
						//echo "<br>feature value= ".$v2->value;
						
						if ($v2->featureid==$pk->id) $aclg[$i-1][0]=$v2->value;
						if ($v2->featureid==$dl->id) $aclg[$i-1][1]=$v2->value;
						if ($v2->featureid==$ls->id) $aclg[$i-1][2]=$v2->value;
		
						$k++;}//for pa j
			
}//for lielais	

//parbaudei izvads
echo "<br>aclg izvads<br>";
for ($i=0;$i<30;$i++){
			echo "N ".($i+1)." ".$aclg[$i][0]." ".$aclg[$i][1].' '. $aclg[$i][2].'<br/>';
}
	
			//veido ald nem datus no studenta tabulaam
//visi kursam piesaistiitie studenti ????
//piemers

//-------------------------------------
/*$sql="SELECT DISTINCT
			u.id
		FROM
			 mdl_role r,
			 mdl_role_assignments ra,
			 mdl_context con,
			 mdl_user u,
    		 mdl_course c
			 
			WHERE
			r.shortname = 'student' and
			ra.roleid = r.id and
			con.contextlevel = 50 AND
			con.instanceid = $courseid AND
			ra.contextid = con.id and
			u.id = ra.userid 
			 ORDER BY u.id";*/
//c.id = $courseid


$coursestudents=array();			 
//tas bija no lielā 
//$coursestudents = $DB->get_records_sql($sql, null, IGNORE_MISSING);
$course = $DB->get_record('course', array('id'=>$courseid), '*', MUST_EXIST);
$context = context_course::instance($course->id, MUST_EXIST);
//echo "<pre>";
//print_r($context);
//echo "</pre>";

$coursestudents = get_role_users(5, $context);
//---------------------

//echo "<pre>";
//print_r($coursestudents);
//echo "</pre>";

			//masiiva ald aizpildiisana, dati par apmācāmo
//nem studentu un tad visas vajadziigaas ipasiibas
echo "<br/>";
//sadi dabuuju studentu id
$skaits=0; //studentu skaits
echo "<H4>Kursa studenti:</H4>";
	foreach ($coursestudents as $id => $student) {
					//echo "id= ".$student->id."<br/>";
					$stud[$skaits]=$student->id;
					
					echo "n= ".$skaits." "." id= ".$stud[$skaits]."<br/>";
					$skaits++;}//cikla aizversana
					
		//jau pasa masiiva ald aizpildiisana
			$p=0;//varbuut nevajag
$vai_dati=array();
	for ($i=0;$i<$skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br><br>Darbiiba studentam ".$stud[$i];
$rez1 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$stud[$i]),'userid','userid,preknow'); 
$rez2 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$stud[$i]),'userid','userid,dlevel'); 
$rez3 = $DB->get_records_menu('v_user_personality_data',array('userid'=>$stud[$i],'property'=>'learningstyle'),'userid','userid,value');


//echo "<br>Triju masiivu izdruka";
//echo "<br>";
//print_r($rez1);echo "<br>";
//print_r($rez2);echo "<br>";
//print_r($rez3);echo "<br>";
			if (!empty($rez1)&& !empty($rez3))
			{$vai_dati[$i]=1;
			//echo "<br>vai_dati[i]=".$vai_dati[$i];
						
			//echo "<br>"; print_r($rez1);
			//echo "<br>pk=".($rez1[$stud[$i]]);
			//echo "<br>dl=".($rez2[$stud[$i]]);
			//echo "<br>style=".($rez3[$stud[$i]]);
			$ald[$i][0]=$stud[$i];
			$ald[$i][1]=$rez1[$stud[$i]];
			$ald[$i][2]=$rez2[$stud[$i]];
			$ald[$i][3]=$rez3[$stud[$i]];
			//echo "<br>Dati ierakstiiti masiivaa";
			} 
		else {echo "<br>".$stud[$i]." nav izieta testēšana vai nav atjaunināti dati!";
				$vai_dati[$i]=0;$p++;
				//echo " vai_dati[i]=".$vai_dati[$i];
				}
		
}//for masiivs ald aizpildīts	
//echo "<br/>";
//echo "<pre>";
//print_r($ald);
//echo "<pre>";
					
			//tad aclg un ald masiivu saliidzinasana
			if (!empty($ald))
			{
$temp=array();

//-----------------
//print_r($vai_dati);
//echo "<br>atdala<br>";
//for ($a=0;$a<$skaits;$a++) echo $vai_dati[$a]." ";


//echo "talak iet if";
	if (!empty($vai_dati)) 
	{//ir vismaz viens ko klasificēt
for($ii=0;$ii<$skaits;$ii++)			
{
	//echo "<br>vai dati= ".$vai_dati[$ii];
	if ($vai_dati[$ii]==1)
	{
	
			for($j=0;$j<30;$j++){
			$csum=0;
			//echo "<br>ald mas= ".$ald[$ii][1]." aclg mas= ".$aclg[$j][0];
				if ($ald[$ii][1]==$aclg[$j][0]) $csum++;	
				if ($ald[$ii][2]==$aclg[$j][1]) $csum++;
				if ($ald[$ii][3]==$aclg[$j][2]) $csum++;
			//echo "<br>csum= ".$csum." ";
			$temp[$j]=$csum;
			}
$result[$ii]=max($temp); $m=array_search(max($temp), $temp);
//echo "<br>result sum= ".$result[$ii]." ";
if ($result[$ii]==3) {
		//ieraksta datus masiivaa clg_members
				//DB tabulas "clg_members" aizpildisana
	//vai taads user ir tabulaa
		$rez5 = $DB->get_records_menu('v_clg_members',array('userid'=>$ald[$ii][0]),'userid','userid,group_number');
		if (empty($rez5))	
					{echo "<br>User= ".$ald[$ii][0]."piešķirta grupa= ".($m+1)." dati ierakstīti tabulā!";
						$record = new stdClass();
						$record->userid=$ald[$ii][0];
						$record->group_number=$m+1;
						$table='v_clg_members';
						$lastid=$DB->insert_record($table, $record);
				} else echo "<br/>User ".$ald[$ii][0]." grupa= ". ($m+1)." ir jau piešķirta grupa!";
			}
	}//if 
	}//for $ii
	} else echo "Nav studentu, ko ieklasificēt grupās!";
} //if not empty
}//write==1
}//userrights==1
else echo "<br>Jums nav tiesību veikt šo darbību";

//atrod kursus un dzees	
/*
		if ($input==true)
		   //DB tabulas "clg" aizpildisana
				{
						$record = new stdClass();
						$record->courseid=$courseid;
						$record->group_number=$n;
						$record->pk=$pazime[$i][$j1];
						$record->dl=$pazime[$i+1][$j2];
						$record->ls=$vv;
						$record->ctime=time();
						$table='v_clg';
						$lastid=$DB->insert_record($table, $record);
				}
	 
*/






		

?>