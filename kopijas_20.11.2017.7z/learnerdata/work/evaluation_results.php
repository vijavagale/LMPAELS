<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;

$testname='courseevaluation';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
$artefacttypeid=$res[$testname];
//------------------------------------------------------------
		echo "<H3>Kursa novertējuma rezultāti</H3>";

		if (user_rights()==1)
		{			//siim lomaam ir tiesiibas veikt klasificeesanu
				echo "<br>Jums ir tiesības veikt šo darbību!<br/>";
//nolasiit no tabulas visus datus

//---------------------------------------
$testname='courseevaluation';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
if (empty($res)) { 
echo "<br/>Nav novērtējumu!";					
		}
else
{
$artefacttypeid=$res[$testname];
//izvelk jau eksistejosos datus
//atlasīt tikai atbilstosam kursam paredzētos
$sql="SELECT
ta.answers
	FROM
		 mdl_v_tests_answers ta
	WHERE
		ta.artefacttypeid='$artefacttypeid' and
		ta.courseid = '$courseid' 
		ORDER BY ta.id";
$rez=array();			
$rez = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($rez);
//echo "</pre>";
//ierakstīt .csv failā
$filename= 'course'.$courseid.'_novertesana.csv';

//izveidot stabiņu virsrakstus
$virsraksts='';
$virsraksts='N.p.k.';
//1.daļa
for($i=1;$i<=8;$i++)
	$virsraksts=$virsraksts.','.$i.'.jaut.';
//2.daļa
for($i=1;$i<=46;$i++)
	{$virsraksts=$virsraksts.','.$i.'.jaut.N';
	$virsraksts=$virsraksts.','.$i.'.jaut.A';}
//ta ir 1.rindiņa - virsraksti
//echo "virsraksta rinda= ".$virsraksts;
file_put_contents($filename, $virsraksts);
//if (!empty($rez))
$num=1;	
foreach ($rez as $key => $value)
{//for($i=1;$i<=2;$i++)
$atbilde='';	
	foreach ($value as $key2 => $value2)
	{//echo "<br/>Answer=".$value2;
	$atbilde=$num.','.$value2[0].','.$value2[1].$value2[2];
	$garums=strlen($value2);
	for($i=3;$i<$garums;$i++)
	$atbilde=$atbilde.','.$value2[$i];
	//echo "<br/>atbilde=".$atbilde;
	$num++;
	file_put_contents($filename, "\n".$atbilde, FILE_APPEND);
	
	}
}

//ierakstiit pa rindiņam datus
//ciklā kamēr ir rindinas tās likt failā

echo "<br/>Fails saglabāts!";
echo "<br/>Faila saturs:<br/>";
echo file_get_contents($filename); 
}

}// ir tiesības
else echo "Jums nav tiesību veikt šo darbību!";

?>