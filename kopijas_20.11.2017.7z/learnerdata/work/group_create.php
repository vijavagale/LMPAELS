<a href='javascript:window.history.go(-3);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
global $DB;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

echo "<H3>Kursa grupas</H3>";

if (user_rights()==1)
{			
		//echo "<br>Jums ir tiesības veikt šo darbību!<br/>";

//atrod kursus un dzees	
$input=true; //vajadzees rakstiit tabulaa
$course_ir = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
			if ($course_ir!=false)
				{$input=false;	
				//kursa dzesana sytaadaa
//$s=	"(courseid='$courseid')";		
//$d=$DB->delete_records_select('v_clg', $s);	
}
 //delete_records($table, $field1=, $value1=, $field2=, $value2=, $field3=, $value3=) 
           //Delete the records from a table where all the given fields match the given values.
//delete_records_select($table, $select=) 
           //Delete one or more records from a table

$pazime=array();
$skaits=$_POST['skaits'];
$pazime[0]=$_POST['pazime1'];
$pazime[1]=$_POST['pazime2'];
$pazime[2]=$_POST['pazime3'];
$pazime[0][0]=$_POST['p1vertiba1'];	 
$pazime[0][1]=$_POST['p1vertiba2'];	
$pazime[1][0]=$_POST['p2vertiba1'];	 
$pazime[1][1]=$_POST['p2vertiba2'];
$pazime[1][2]=$_POST['p2vertiba3'];	
$pazime[2][0]=$_POST['p3vertiba1'];	 
$pazime[2][1]=$_POST['p3vertiba2'];
$pazime[2][2]=$_POST['p3vertiba3'];
$pazime[2][3]=$_POST['p3vertiba4'];
$pazime[2][4]=$_POST['p3vertiba5'];
//echo "tests= ".$_POST['p3vertiba5'];
//echo "tests= ".$pazime[2][4]; 



//HTML tabulas veidošana
echo "<table border='1' cellpadding='2' cellspacing='2' width='20%' style='font-size:12px'>
<tr>
<th>Grupas numurs</th>
<th>PK</th>
<th>DL</th>
<th>LS</th>
</tr>";

$n=1;
$i=0;$j1=$j2=0;
for ($j1=0;$j1<2&&$n<=30;$j1++)
for ($j2=0;$j2<3;$j2++)
for ($j3=0;$j3<5;$j3++)
	{
	echo "<tr>
			<td>".$n."</td>
			<td>".$pazime[$i][$j1]."</td>";
	echo "<td>".$pazime[$i+1][$j2]."</td>";
	if ($i+2==2 && $j3==4) $vv='va'; else $vv=$pazime[$i+2][$j3];
	echo "<td>".$vv."</td>";
	echo "</tr>";


		if ($input==true)
		   //DB tabulas "clg" aizpildisana
				{$record1 = new stdClass();
				$record2 = new stdClass();
				$record3 = new stdClass();
				$table1='v_clg';
				$table2='v_clg_description';
				$table3='v_adaptation_features';
				$table4='v_adaptation_features_values';	
				$table5='v_adaptation_scenario';	
						$record1->courseid=$courseid;
						$record1->group_number=$n;
						//$record->pk=$pazime[$i][$j1];
						//$record->dl=$pazime[$i+1][$j2];
						//$record->ls=$vv;
						//$record->ctime=time();
						$lastid1=$DB->insert_record($table1, $record1);
						//pk
						$v = $DB->get_record($table3, array('feature'=>'pk'));// izvelk pazīmes id
						$v2 = $DB->get_record($table4, array('featureid'=>$v->id, 'value'=>$pazime[$i][$j1])); //izvelk pazīmes, veertības id
						$record2->clgid=$lastid1;
						$record2->adaptation_features_valueid=$v2->id;
						$lastid2=$DB->insert_record($table2, $record2);
						//dl
						$v = $DB->get_record($table3, array('feature'=>'dl'));
						$v2 = $DB->get_record($table4, array('featureid'=>$v->id, 'value'=>$pazime[$i+1][$j2]));
						$record2->clgid=$lastid1;
						$record2->adaptation_features_valueid=$v2->id;
						$lastid2=$DB->insert_record($table2, $record2);
						//ls
						$v = $DB->get_record($table3, array('feature'=>'ls'));
						$v2 = $DB->get_record($table4, array('featureid'=>$v->id, 'value'=>$vv));
						$record2->clgid=$lastid1;
						$record2->adaptation_features_valueid=$v2->id;
						$lastid2=$DB->insert_record($table2, $record2);
						
						//adaptacijas scenarija veidosana
						$paz1=$pazime[$i][$j1];
						$paz2=$pazime[$i+1][$j2];
						$paz3=$vv;
						if ($paz1==1) $e=0; else $e=1;
						if ($paz2==1) $a=1; else if ($paz2==2) $a=2; else $a=3;
						if ($paz3=='r') $rt='r'; else if ($paz3=='v') $rt='w'; else if ($paz3=='a') $rt='l'; else if ($paz3=='k') $rt='d'; else $rt='wl'; 
						$record3->clgid=$lastid1;
						$record3->theory_basic_content=$rt;
						$record3->theory_explanation=$e;
						$record3->practice_exercise=$a;
						$record3->assessment_task=$a;
						$record3->assessment_quiz=$a;
						$lastid3=$DB->insert_record($table5, $record3);	
				}
	 
$n++;
}
echo "</table";
} else echo "<br/Jums nav tiesību veikt šo darbību!>";
?>