<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
global $DB;
global $USER;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();

$instanceid=$_SESSION['instance'];//neizmanto
$courseid=$_SESSION['courseid'];

echo "<H3>Kursa apmācāmo grupu veidošana</H3>";

if (user_rights()==1)
{			//siim lomaam ir tiesiibas veikt klasificeesanu
	
$feature="pk";
$adfeatures_ir = $DB->get_records('v_adaptation_features',array('feature'=>$feature)); //salīdzina

				//Tabulā adap_feature un tabulā adap_features_values pazīmju un vertību ierakstīšana
$input=true; //vajadzees rakstiit tabulaa
if ($adfeatures_ir==true) {$input=false;	echo "Tabulā adaptation_feature un adaptation_features_values pazīmes un to vērtības ir jau ierakstītas!<br/>";}

//citādi pazīmes tiek ierakstītas
if ($input==true)
		   //DB tabulas "adap_features" aizpildisana
				{
				$table1='v_adaptation_features';
				$table2='v_adaptation_features_values';
				$record1 = new stdClass();
				$record2 = new stdClass();
				$feature1="pk"; $feature2="dl"; $feature3="ls";
				$f1value1="0"; $f1value2="1";
				$f2value1="1"; $f2value2="2"; $f2value3="3";
				$f3value1="v"; $f3value2="a"; $f3value3="r"; $f3value4="k"; $f3value5="va";
						//1.pazīme un tās vērtības
						$record1->feature=$feature1; 
						$lastid1=$DB->insert_record($table1, $record1);
						$record2->featureid=$lastid1; $record2->value=$f1value1;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f1value2;
						$lastid2=$DB->insert_record($table2, $record2);
						//2.pazīme un tās vērtības
						$record1->feature=$feature2; 
						$lastid1=$DB->insert_record($table1, $record1);
						$record2->featureid=$lastid1; $record2->value=$f2value1;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f2value2;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f2value3;
						$lastid2=$DB->insert_record($table2, $record2);
						//3.pazīme un tās vērtības
						$record1->feature=$feature3; 
						$lastid1=$DB->insert_record($table1, $record1);
						$record2->featureid=$lastid1; $record2->value=$f3value1;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f3value2;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f3value3;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f3value4;
						$lastid2=$DB->insert_record($table2, $record2);
						$record2->featureid=$lastid1; $record2->value=$f3value5;
						$lastid2=$DB->insert_record($table2, $record2);
						echo "Pazīmes un to vērtības tika ierakstītas";
				}
			//beigas pazīmju un vertību ierakstīšanai
			

//---------------------------------------------	
//echo "<br>Kursam izveidotās grupas:<br/><br/>";	
$course_ir = $DB->get_records('v_clg',array('courseid'=>$courseid)); 	
if ($course_ir==false)
	{	echo "Kursam nav definētas grupas!";
			
			// ja kuram nav definētas grupas, tad pazīmes un to vērtības tiek atlasītas no db tabulām
		// datu izvads no tabulas adaptation_features
		
		echo "<br/>Datu izvads no tabulas adaptation_features<br/><br/><b>apmācāmā pazīmes:</b><br/>";
			
//-----------------------------------
$sql1="SELECT id,feature FROM mdl_v_adaptation_features";
$features=array();			 
$features = $DB->get_records_sql($sql1, null, IGNORE_MISSING);
$values=array();
	
	$sk=1;
	foreach ($features as  $f) {		
					echo "<br/>".$sk.". ".$f->feature." <br/>";
					$sql2="SELECT value FROM mdl_v_adaptation_features_values where featureid=$f->id";
					$values = $DB->get_records_sql($sql2, null, IGNORE_MISSING);	
							foreach ($values as $v => $value) {
									echo "vērtība: ". $v."<br/>";}	
					$sk++;
					}//cikla aizversana

				
		//echo "<br/>Notiek grupu pazīmju veidošana";
		echo "<br>Lūdzu ievadiet grupu veidošanai izmantoto pazīmju skaitu, pazīmju nosaukumus un to vērtības:<br/><br/>";
		echo '<meta charset="UTF-8">
		<form method=post action=group_create.php >
		<input type=integer name=skaits value="3" > <br/><br/>
		<input type=text name=pazime1  value="pk"> <br/>
		&nbsp&nbsp&nbsp<input type=text name=p1vertiba1 value="0"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p1vertiba2 value="1"><br/><br/>
		<input type=text name=pazime2 value="dl"> <br/>
		&nbsp&nbsp&nbsp<input type=text name=p2vertiba1 value="1"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p2vertiba2 value="2"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p2vertiba3 value="3"><br/><br/>
		<input type=text name=pazime3 value="ls"> <br/>
		&nbsp&nbsp&nbsp<input type=text name=p3vertiba1 value="v"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p3vertiba2 value="a"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p3vertiba3 value="r"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p3vertiba4 value="k"><br/>
		&nbsp&nbsp&nbsp<input type=text name=p3vertiba5 value="va"><br/><br/>
		<input type=submit value="Veidot grupas" />
		</form>';
		} 
		
		else
				{	echo "<br>Kursam ir definētas grupas.";
					} 
						
		
} 
	else echo "<br/>Jums nav tiesību veikt šo darbību!";
?>