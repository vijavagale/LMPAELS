<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
global $DB;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;

require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

if (user_rights()==1)
{			//siim lomaam ir tiesiibas veikt klasificeesanu

$context = context_course::instance($courseid);
	global $cId;
	$cId=$context->id;
//echo "cId=".$cId;
$sql="SELECT a.userid, firstname, lastname, username
FROM mdl_user, mdl_role_assignments as a, mdl_role
WHERE contextid=".$cId." 
and mdl_user.id=a.userid 
and a.roleid=mdl_role.id ORDER BY a.userid;";
$result = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($result);
//echo "</pre>";

//$skaits=count($result);
//echo "skaits=".$skaits;
//atzīmes


echo "<h3>Indormācija par kursa dalībniekiem</h3>";
echo "<table border=1>";
		echo "<tr>";
			echo "<th>NR</th>";
			echo "<th>ID</th>";
			echo "<th>Username</th>";
			echo "<th>Vards</th>";
			echo "<th>Uzvards</th>";
			echo "<th>Kursa vērtējums</th>";
			echo "<th>Kursa novērtējums</th>";			
			
		echo "<tr>";
$i=1;	
foreach ($result as $id => $resultid) 
					
	{//echo "id= ".$courseid->group_number."<br/>";
		echo "<tr>";
			echo "<td>" . $i .".</td>";
			echo "<td>".$resultid->userid."</td>";
			echo "<td>".$resultid->username."</td>";
			echo "<td>".$resultid->firstname."</td>";
			echo "<td>".$resultid->lastname."</td>";
			//echo "userid=".$resultid->userid;
			//echo "course=".$courseid;
			$grade = $DB->get_record('v_user_learning_data',array('userid' => $resultid->userid, 'courseid' => $courseid), 'course_grade');
			if (isset($grade->course_grade)) echo "<td>".$grade->course_grade."</td>"; else echo "<td> </td>";
			$novertejums = $DB->get_record('v_tests_answers',array('userid' => $resultid->userid), 'id');
			if (isset($novertejums->id)) echo "<td>".$novertejums->id."</td>"; else echo "<td> </td>";
		echo "<tr>";
		$i++;
	}
	echo "</table>";

} else echo "<br/>Jums nav tiesību skatīties šo informāciju!";
?>