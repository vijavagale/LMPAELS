<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------
//definee klasi
//echo "kursa id= ".$courseid;
$testname='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testname;
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
		else {
			$artefacttypeid=$res[$testname];
			//echo "<br>AR= ".$artefacttypeid;
		}
//------------------------------------------------------------
		echo "<H3>Testu rezultāti</H3>";

		if (user_rights()==1)
		{			//siim lomaam ir tiesiibas veikt klasificeesanu
				echo "<br>Jums ir tiesības veikt šo darbību!<br/>";
		//veido tabulas galvu
		echo "<table border='1' cellpadding='2' cellspacing='2' width='60%' style='font-size:12px'>
				<tr>
				<th>N.p.k.</th>
				<th>RecordID</th>
				<th>UserID</th>
				<th>Lastname</th>
				<th>Firstname</th>
				<th>Time</th>
				<th>Quiz</th>
				<th>Visual</th>
				<th>Aural</th>
				<th>Read</th>
				<th>Kinesthetic</th>
				<th>Rez. stils stils</th>
				<th>PreKnow</th>
				<th>Dlevel</th>
				
				</tr>";
		
		//jaizvelk visu lietotaaju dati
				$result = $DB->get_records_menu('v_user_artefact_all',array('artefacttypeid'=>$artefacttypeid),'userid','id,userid'); 
				//echo "<br>Result masiivs <pre>";
				//print_r ($result);
				//echo "</pre>";
				$visu_skaits=sizeof($result);
				//echo "</br>";
				$n=1;//tabulas numurs
				//foreach ($result as $key => $value) {$prev_stud=$value; break;}
		foreach ($result as $key => $value) {
		//panemt vienu studentu	
								echo "<tr><td>".$n."</td>
									<td>".$key."</td>". 
									"<td>".$value."</td>";
									$user1 = $DB->get_record('user', array('id'=>$value));
								echo "<td>".$user1->lastname."</td>".
									"<td>".$user1->firstname."</td>";
									$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,source'); 
								//echo " ".$result2[$key];
									$result3 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,ctime'); 
								
								echo "<td>".date("d.m.Y H:i:s",$result3[$key])."</td>".
									"<td>".$result2[$key]."</td>";
								$result4 = $DB->get_records_menu('v_user_learningstyle',array('artefactallid'=>$key),'artefactallid','lstylename,value'); 
								//echo "<br>Result4 masiivs <pre>";
								//print_r ($result4);
								//echo "</pre>";
								//stilu vilksana
								$ststils=array();
								$m=0; //lai saprastu, ka visi stili atrasti
								foreach ($result4 as $key4 => $value4)
										{
										if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
											{
											if ($key4=="v") 
													{echo "<td>".$value4."</td>"; 
													$ststil['v']=$value4;}else
											
											if ($key4=="a")
													{echo "<td>".$value4."</td>";
													$ststil['a']=$value4;}else
												
													{echo "<td> </td>";
													$ststil['r']=0;} 
											
											if ($key4=="k")
												{echo "<td>".$value4."</td>";
												$ststil['k']=$value4;} 
											  } 
																								
										if ($result2[$key]=="vark3")
											{
											if ($key4=="v") 
													{echo "<td>".$value4."</td>"; 
													$ststil['v']=$value4;}else
											if ($key4=="a")
													{echo "<td>".$value4."</td>";
													$ststil['a']=$value4;}else
											if ($key4=="r")
													{echo "<td>".$value4."</td>";
													$ststil['r']=$value4;}else
											if ($key4=="k")
													{echo "<td>".$value4."</td>";
													$ststil['k']=$value4;}
											$m++;
											}
									}//foreach result4 				
											if ($m>0)	{		
														//jasaliek vajadzīgajā secība cita masiivā K, A, V, R
														$ststils=array();//prioritate studenta stils
														$ststils['k']=$ststil['k'];
														$ststils['a']=$ststil['a'];
														$ststils['v']=$ststil['v'];
														$ststils['r']=$ststil['r'];
														
														//------------------------------------
														//izvads
														//echo "<br>k= ".$ststils['k'];
														//echo "<br>a= ".$ststils['a'];
														//echo "<br>v= ".$ststils['v'];
														//echo "<br>r= ".$ststils['r'];
													//max pa rindinu
														$maxst=array_search(max($ststils),$ststils); //max stils
														
														//echo "<br>maxst= ".$maxst;
														if ($maxst=='k' && (
															$ststils['k']==$ststils['v'] || 
															$ststils['k']==$ststils['a'] ||
															$ststils['k']==$ststils['r'] || 
															$ststils['k']==$ststils['a'] && $ststils['k']==$ststils['v'])) 
															$stils='k';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['r']) )
															$stils='a';	
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v'] && $ststils['v']==$ststils['r']))
															$stils='va';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v']) )
															$stils='va';	
															else
														if ($maxst=='v' && (
															$ststils['v']==$ststils['r']) )
															$stils='v';
															else $stils=$maxst;
														
														
														}
													
													 
											
								if ($result2[$key]=="vark3") echo "<td>".$stils."</td>"; else 	echo "<td>"." "."</td>";
															//izvilkt personisko inf
							//jaņem atbilstosam kursam vel 
								
								$result5 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value,'courseid'=>$courseid),'userid','userid,preknow');
								$result6 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value, 'courseid'=>$courseid),'userid','userid,dlevel');
								if (!empty($result5))echo "<td>".$result5[$value]."</td>"; else echo "<td>".''."</td>";
								if (!empty($result6))echo "<td>".$result6[$value]."</td>"; else echo "<td>".''."</td>";
								echo "</tr>";				
							
								
								//aizpilda tabulu v_user_personality_data, ja lietotaaja nav			
								$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$value));
								if ($user_ir==false)
										{
												
												$ls='learningstyle';
												$record7 = new stdClass();
												$record7->userid=$value;
												$record7->property=$ls;
												$record7->value=$stils;
												$table='v_user_personality_data';
												$lastid=$DB->insert_record($table, $record7);
																				
												} //user ir false  	
						//	}//dati jau ir ierakstiiti db
	$n++;
		
} //foreach result
echo "</table>";				
}//userrights
else echo "Jums nav tiesību veikt šo darbību!";

?>