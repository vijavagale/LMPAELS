<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

//rezultaatu un visu datu rādīšana

//tabulu aizpildisana

//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------

//definee klasi
/*
$testname='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= 'coursedata';
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
		else {
			$artefacttypeid=$res[$testname];
			//echo "<br>AR= ".$artefacttypeid;
		}
*/



//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------

//definee klasi
/*
$record = new stdClass();
$record->artefacttype= 'learningstyle';
$lastid=$DB->insert_record('v_user_artefact_type', $record);
$record = new stdClass();
$record->artefacttype= 'learningstyles analyse';
$lastid=$DB->insert_record('v_user_artefact_type', $record);
echo "</br>LastId = ".$lastid;*/
//------------------------------------------------------------

		echo "<H3>Testu rezultāti</H3>";

		if (user_rights()==1)
		{			//siim lomaam ir tiesiibas veikt klasificeesanu
				echo "<br>Jums ir tiesības veikt šo darbību!<br/>";
		//veido tabulas galvu
		echo "<table border='1' cellpadding='2' cellspacing='2' width='60%' style='font-size:12px'>
				<tr>
				<th>N.p.k.</th>
				<th>RecordID</th>
				<th>UserID</th>
				<th>Lastname</th>
				<th>Firstname</th>
				<th>Time</th>
				<th>Quiz</th>
				<th>Visual</th>
				<th>Aural</th>
				<th>Read</th>
				<th>Kinesthetic</th>
				<th>PreKnow</th>
				<th>Dlevel</th>
				<th>Rez. stils stils</th>
				</tr>";
		
		//jaizvelk visu lietotaaju dati
				$result = $DB->get_records_menu('v_user_artefact_all',array('artefacttypeid'=>'1'),'userid','id,userid'); 
				echo "<br>Result masiivs <pre>";
				print_r ($result);
				echo "</pre>";
				$visu_skaits=sizeof($result);
				echo "</br>";
				$n=1;//tabulas numurs
				foreach ($result as $key => $value) {$prev_stud=$value; break;}
		foreach ($result as $key => $value) {
		//panemt vienu studentu	
		//echo "<br>000000";	
				//ja nav vienaads tad nem datus, un uz pirmo n==1
				if ($prev_stud!=$value || $n==1){
					$result_1stud = $DB->get_records_menu('v_user_artefact_all',array('artefacttypeid'=>'1','userid'=>$value),'userid','id,userid'); 
					//echo "<br>Result masiivs <pre>";
					//print_r ($result_1stud);
					//echo "</pre>";
					$skaits_1stud=sizeof($result_1stud);
					//izvads datu
						$k=0;
						foreach ($result_1stud as $key2 => $value2) {
								//par vienu studentu dati
								//pati svariigaaka vieta!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
								echo "<br>n= ".$n." value2= ".$value2;
								//tabula
								echo "<tr><td>".$n."</td>
									<td>".$key2."</td>". 
									"<td>".$value2."</td>";
									$user1 = $DB->get_record('user', array('id'=>$value2));
								echo "<td>".$user1->lastname."</td>".
									"<td>".$user1->firstname."</td>";
									$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key2),'id','id,source'); 
								//echo " ".$result2[$key];
									$result3 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key2),'id','id,ctime'); 
								//echo " ".date("d.m.Y H:i:s",$result3[$key]);	
								echo "<td>".date("d.m.Y H:i:s",$result3[$key2])."</td>".
									"<td>".$result2[$key2]."</td>";
								$result4 = $DB->get_records_menu('v_user_learningstyle',array('artefactallid'=>$key2),'artefactallid','lstylename,value'); 
								//stilu vilksana
								foreach ($result4 as $key4 => $value4)
										{
										if ($result2[$key2]=="vark1" ||$result2[$key2]=="vark2")
											{
											if ($key4=="v") 
													{echo "<td>".$value4."</td>"; 
													$ststil['v']=$value4;}else
											
											if ($key4=="a")
													{echo "<td>".$value4."</td>";
													$ststil['a']=$value4;}else
												
													{echo "<td> </td>";
													$ststil['r']=0;} 
											
											if ($key4=="k")
												{echo "<td>".$value4."</td>";
												$ststil['k']=$value4;} 
											} else
											
													{if ($key4=="v") 
															{echo "<td>".$value4."</td>"; 
															$ststil['v']=$value4;}else
													if ($key4=="a")
															{echo "<td>".$value4."</td>";
															$ststil['a']=$value4;}else
													if ($key4=="r")
															{echo "<td>".$value4."</td>";
															$ststil['r']=$value4;}else
													if ($key4=="k")
															{echo "<td>".$value4."</td>";
															$ststil['k']=$value4;}
													}
											}//foreach result4 
								
															//izvilkt personisko inf
							//jaņem atbilstosam kursam vel 

								$result5 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value2,'courseid'=>$courseid),'userid','userid,preknow');
								$result6 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value2, 'courseid'=>$courseid),'userid','userid,dlevel');
								if (!empty($result5))echo "<td>".$result5[$value2]."</td>"; else echo "<td>".''."</td>";
								if (!empty($result6))echo "<td>".$result6[$value2]."</td>"; else echo "<td>".''."</td>";
												
							//jaapstradā ja vienādi varianti
							/*Tāpēc, ja iegūtajā stilu kombinacijā ir K, tad šo kombināciju pieskaita stilam Kinesthetic, piemēram, VK, AK, RK, VAK. Stilu kombinācija VAR tika pieskaitīta pie VA, 
							kombinācija AR pieskaitīta pie A, VR pie Visual. Atlikušās kombinācijas, kurās ir sastopams stils R tika pieskaitītas pie stila Read.*/
							{
								//jasaliek vajadzīgajā secība cita masiivā K, A, V, R
								$ststils=array();//prioritate studenta stils
								$ststils['k']=$ststil['k'];
								$ststils['a']=$ststil['a'];
								$ststils['v']=$ststil['v'];
								$ststils['r']=$ststil['r'];

								//izvads
								echo "<br>k= ".$ststils['k'];
								echo "<br>a= ".$ststils['a'];
								echo "<br>v= ".$ststils['v'];
								echo "<br>r= ".$ststils['r'];
							//max pa rindinu
								$maxst=array_search(max($ststils),$ststils); //max stils
								
								echo "<br>maxst= ".$maxst;
								if ($maxst=='k' && (
									$ststils['k']==$ststils['v'] || 
									$ststils['k']==$ststils['a'] ||
									$ststils['k']==$ststils['r'] || 
									$ststils['k']==$ststils['a'] && $ststils['k']==$ststils['v'])) 
									$stils='k';
									else
								if ($maxst=='a' && (
									$ststils['a']==$ststils['r']) )
									$stils='a';	
									else
								if ($maxst=='a' && (
									$ststils['a']==$ststils['v'] && $ststils['v']==$ststils['r']))
									$stils='va';
									else
								if ($maxst=='a' && (
									$ststils['a']==$ststils['v']) )
									$stils='va';	
									else
								if ($maxst=='v' && (
									$ststils['v']==$ststils['r']) )
									$stils='v';
									else $stils=$maxst;

									echo "<td>".$stils."</td>";
									echo "</tr>";
								echo "<br>Rindaa Stils=".$stils."<br>----------------------------------------------------------------";
								//ar to izvads beidzas
								}
								$arr_lsv[$k]=$stils; $k++;
								
								$n++;

				
								} //foreach result_1stud					
						
						//1 studentam visu stilu veertiibu pz vertikaali izvads 
						
						//jāatrod īstais stils  un jaieraksta db
						$kin=0; $vis=0;	$aur=0; $red=0; $va=0;
						echo "<br/>kin= ".$kin." vis= ".$vis." aur= ".$aur." red= ".$red." va= ".$va."<br/>";	
						//vertikala masiiva dati
						$p=0;
						foreach($arr_lsv as $pp => $v)
									{//echo "<br>". "vertikala .masiiva stils = ".$v;
										if ($v=='k') $kin++;
										if ($v=='v') $vis++;
										if ($v=='a') $aur++;
										if ($v=='r') $red++;
										if ($v=='va') $va++;
										$p++;
									}
						//testa izvads par stiliem pa vertikaali
						echo "<br/>kin= ".$kin." vis= ".$vis." aur= ".$aur." red= ".$red." va= ".$va."<br/>";	
						echo "<br/>p= ".$p;					
						//izveeleeties, kurs stils
						{
						$rezst='';
						echo "<br>kin= ".$kin." p=".$p;
						//if ($p==1)
						//{
						if ($kin==$p) $rezst='k'; else
						if ($vis==$p) $rezst='v'; else
						if ($aur==$p) $rezst='a'; else
						if ($red==$p) $rezst='r'; else 
						if ($va==$p) $rezst='va'; else

						//if ($p==2)
						//{
						if ($vis==$p-1 && $aur==$p-1) $rezst='va'; else
						if ($kin==$p-1) $rezst='k'; else
						if ($vis==$p-1) $rezst='v'; else
						if ($aur==$p-1) $rezst='a'; else
						if ($red==$p-1) $rezst='r'; else
						if ($va==$p-1) $rezst='va'; else
						
						//if ($p==3)
						//{
						if ($vis==$p-2 && $aur==$p-2) $rezst='va'; else

						if ($kin==$p-2) $rezst='k';  else
						if ($aur==$p-2) $rezst='a'; else
						if ($vis==$p-2) $rezst='v'; else
						if ($red==$p-2) $rezst='r'; else
						if ($va==$p-2) $rezst='va'; else
						
						//if ($p==4)
						//{
						if ($vis==$p-3 && $aur==$p-3 && $red==$p-3) $rezst='va'; else
						if ($vis==$p-3 && $aur==$p-3 && $kin==$p-3) $rezst='k'; else
						if ($vis==$p-3 && $red==$p-3 && $kin==$p-3) $rezst='k'; else
						if ($aur==$p-3 && $red==$p-3 && $kin==$p-3) $rezst='k'; else
						if ($va==$p-3 && $aur==$p-3 && $vis==$p-3) $rezst='va'; else
						if ($va==$p-3 && $aur==$p-3 && $kin==$p-3) $rezst='a'; 
						}
						echo "<br><br>===================<br>rezst=".$rezst."<br>=====================<br>";//aprekinaja
						
						//aizpilda tabulu v_user_personality_data, ja lietotaaja nav			
						$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$value2));
						if ($user_ir==false)
								{
										
										$ls='learningstyle';
										$record7 = new stdClass();
										$record7->userid=$value2;
										$record7->property=$ls;
										$record7->value=$rezst;
										$table='v_user_personality_data';
										$lastid=$DB->insert_record($table, $record7);
																		
										} //user ir false  	
					//dati jau ir ierakstiiti db
						
						
						
						unset($arr_lsv);
						$arr_lsv=array();
						
						$prev_stud=$value;
						} //if prev
							

//}//for par 1stud dati 				

				
} //foreach result				
}//userrights



/*
//vecais-------------============================================================				

	

$n++;
}//for result


echo "</table>";

//------------------------------------------------------------------------------------------
//peedeejā lietotaja dati v_user_lersonality tikai par vienu studentu

$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$userid_prev));
				if ($user_ir==false)
				{
						
						$ls='learningstyle';
						$record7 = new stdClass();
						$record7->userid=$userid_prev;
						$record7->property=$ls;
						$record7->value=$rezst;
						$table='v_user_personality_data';
						$lastid=$DB->insert_record($table, $record7);
				} 
				
//-----------------------------------------------------------------------------------------

}//if ja admin
else 
echo "<br/>Jums nav pieejama šī darbība!";
*/
?>