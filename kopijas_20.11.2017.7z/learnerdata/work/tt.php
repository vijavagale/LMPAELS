<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
require_login();
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

//rezultaatu un visu datu rādīšana

//tabulu aizpildisana

//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------

//definee klasi
/*
$record = new stdClass();
$record->artefacttype= 'learningstyle';
$lastid=$DB->insert_record('v_user_artefact_type', $record);
$record = new stdClass();
$record->artefacttype= 'learningstyles analyse';
$lastid=$DB->insert_record('v_user_artefact_type', $record);
echo "</br>LastId = ".$lastid;*/
//------------------------------------------------------------

echo "<H3>Testu rezultāti</H3>";

if (user_rights()==1)
{			//siim lomaam ir tiesiibas veikt klasificeesanu
		echo "<br>Jums ir tiesības veikt šo darbību!<br/>";
		
		
//jaizvelk visu lietotaaju dati

//echo $DB->get_record_sql('SELECT * FROM {v_user_artefact_all} ');
$table= 'v_user_artefact_all';
$conditions = array('artefacttypeid'=>'1');
$sort = 'userid';
$fields = 'id,userid';
$result = $DB->get_records_menu($table,$conditions,$sort,$fields); 
//visi ieraksti
print_r ($result);
echo "</br>";

//tabulas virsraksti
echo "<table border='1' cellpadding='2' cellspacing='2' width='60%' style='font-size:12px'>
<tr>
<th>N.p.k.</th>
<th>RecordID</th>
<th>UserID</th>
<th>Lastname</th>
<th>Firstname</th>
<th>Time</th>
<th>Quiz</th>
<th>Visual</th>
<th>Aural</th>
<th>Read</th>
<th>Kinesthetic</th>
<th>PreKnow</th>
<th>Dlevel</th>
<th>Rez. stils stils</th>
</tr>";
$n=1;
//echo "id: $key; userid: $value";
//echo " ".$user1->firstname." ".$user1->lastname;
$ststil=array();//studenta viena rindinā stils
$ststilv=array();
$userid_prev=null;
//if (empty($userid_prev)) echo "AAA"; else echo "AAA2222";
$arr_lsv=array();

$k=1; //vai par vienu studentu vairaki ieraksti
foreach ($result as $key => $value) {
echo "<tr><td>".$n."</td>
	<td>".$key."</td>". 
	"<td>".$value."</td>";
	$user1 = $DB->get_record('user', array('id'=>$value));
echo "<td>".$user1->lastname."</td>".
	"<td>".$user1->firstname."</td>";
	$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,source'); 
//echo " ".$result2[$key];
	$result3 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,ctime'); 
//echo " ".date("d.m.Y H:i:s",$result3[$key]);	
	echo "<td>".date("d.m.Y H:i:s",$result3[$key])."</td>".
	"<td>".$result2[$key]."</td>";	
	$result4 = $DB->get_records_menu('v_user_learningstyle',array('artefactallid'=>$key),'artefactallid','lstylename,value'); 
//stilu vilksana
	foreach ($result4 as $key4 => $value4)
				{
				if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
					{
					if ($key4=="v") 
							{echo "<td>".$value4."</td>"; 
							$ststil['v']=$value4;}else
					
					if ($key4=="a")
							{echo "<td>".$value4."</td>";
							$ststil['a']=$value4;}else
						
							{echo "<td> </td>";
							$ststil['r']=0;} 
					
					if ($key4=="k")
						{echo "<td>".$value4."</td>";
						$ststil['k']=$value4;} 
					} else
					
					{if ($key4=="v") 
							{echo "<td>".$value4."</td>"; 
							$ststil['v']=$value4;}else
					if ($key4=="a")
							{echo "<td>".$value4."</td>";
							$ststil['a']=$value4;}else
					if ($key4=="r")
							{echo "<td>".$value4."</td>";
							$ststil['r']=$value4;}else
					if ($key4=="k")
							{echo "<td>".$value4."</td>";
							$ststil['k']=$value4;}
					}
					
					
				}//foreach result4 
//izvilkt personisko inf
//jaņem atbilstosam kursam vel 

	$result5 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value,'courseid'=>$courseid),'userid','userid,preknow');
	$result6 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value, 'courseid'=>$courseid),'userid','userid,dlevel');
	if (!empty($result5))echo "<td>".$result5[$value]."</td>"; else echo "<td>".''."</td>";
	if (!empty($result6))echo "<td>".$result6[$value]."</td>"; else echo "<td>".''."</td>";
					
//jaapstradā ja vienādi varianti
/*Tāpēc, ja iegūtajā stilu kombinacijā ir K, tad šo kombināciju pieskaita stilam Kinesthetic, piemēram, VK, AK, RK, VAK. Stilu kombinācija VAR tika pieskaitīta pie VA, 
kombinācija AR pieskaitīta pie A, VR pie Visual. Atlikušās kombinācijas, kurās ir sastopams stils R tika pieskaitītas pie stila Read.*/

	//jasaliek vajadzīgajā secība cita masiivā K, A, V, R
	$ststils=array();//prioritate studenta stils
	$ststils['k']=$ststil['k'];
	$ststils['a']=$ststil['a'];
	$ststils['v']=$ststil['v'];
	$ststils['r']=$ststil['r'];

	//izvads
	echo "<br>k= ".$ststils['k'];
	echo "<br>a= ".$ststils['a'];
	echo "<br>v= ".$ststils['v'];
	echo "<br>r= ".$ststils['r'];
//max pa rindinu
	$maxst=array_search(max($ststils),$ststils); //max stils
	echo "<br>maxst= ".$maxst;
	if ($maxst=='k' && (
		$ststils['k']==$ststils['v'] || 
		$ststils['k']==$ststils['a'] ||
		$ststils['k']==$ststils['r'] || 
		$ststils['k']==$ststils['a'] && $ststils['k']==$ststils['v'])) 
		$stils='k';
		else
	if ($maxst=='a' && (
		$ststils['a']==$ststils['r']) )
		$stils='a';	
		else
	if ($maxst=='a' && (
		$ststils['v']==$ststils['a'] && $ststils['v']==$ststils['r']))
		$stils='va';
		else
	if ($maxst=='a' && (
		$ststils['a']==$ststils['v']) )
		$stils='va';	
		else
	if ($maxst=='v' && (
		$ststils['v']==$ststils['r']) )
		$stils='v';
		else $stils=$maxst;

		echo "<td>".$stils."</td>";
		echo "</tr>";
echo "<br>Stils=".$stils;
					
		//stils pa vertikaali tiek ierakstiits masiivaa
		
		
		//nepatiik
		if (empty($userid_prev)) $userid_prev=$value;
		if ($userid_prev==$value)
			{//echo "par studentu vairaaki ieraksti";
			$arr_lsv[$k]=$stils;//defineets 73 rindaa lietotaja numurs
			$k++;}
				else {
					//vairak ierakstu par studentu nav
					if ($userid_prev==0)
					
					
					
					$k=1;
					//$arr_lsv[$k]=$stils;
					//testa izvads par stiliem pa vertikaali
					//izvada stilus pa vertikaali 
					echo "<br>stils pa vertikaali";
					echo "<br>arr_lsv = ";
					//for ($m=0;$m<$k;$m++)
					//echo " ".$arr_lsv[$m];
					echo "<pre>";
					print_r($arr_lsv);
					echo "</pre>";
						}		
	//jāatrod īstais stils  un jaieraksta db
	$kin=$vis=$aur=$red=$va=0;
	$p=0;
	//vertikala masiiva dati
	foreach($arr_lsv as $p => $v)
				{echo "<br>p=".$p." v= ".$v;
					if ($v=='k') $kin++;
					if ($v=='v') $vis++;
					if ($v=='a') $aur++;
					if ($v=='r') $red++;
					if ($v=='va') $va++;
					$p++;
				}
	//testa izvads par stiliem pa vertikaali
	echo "<br/>kin= ".$kin." vis= ".$vis." aur= ".$aur." red= ".$red." va= ".$va."<br/>";	
	//izveeleeties, kurs stils
	$rezst='';
	if ($kin==$p) $rezst='k'; else
	if ($vis==$p) $rezst='v'; else
	if ($aur==$p) $rezst='a'; else
	if ($red==$p) $rezst='r'; else
	
	if ($kin==$p-1) $rezst='k'; else
	if ($vis==$p-1) $rezst='v'; else
	if ($aur==$p-1) $rezst='a'; else
	if ($red==$p-1) $rezst='r'; else
	
	if ($vis==$p-2 && $aur==$p-2) $rezst='va'; else
	
	if ($kin==$p-2) $rezst='k';  else
	if ($aur==$p-2) $rezst='a'; else
	if ($vis==$p-2) $rezst='v'; else
	if ($red==$p-2) $rezst='r'; else
	
	if ($vis==$p-3 && $aur==$p-3 && $red==$p-3) $rezst='va'; else
	if ($vis==$p-3 && $aur==$p-3 && $kin==$p-3) $rezst='k'; else
	if ($vis==$p-3 && $red==$p-3 && $kin==$p-3) $rezst='k'; else
	if ($aur==$p-3 && $red==$p-3 && $kin==$p-3) $rezst='k'; else
	if ($va==$p-3 && $aur==$p-3 && $vis==$p-3) $rezst='va'; else
	if ($va==$p-3 && $aur==$p-3 && $kin==$p-3) $rezst='a'; 
	
	echo "<br>rezst=".$rezst;//aprekinaja
				
//aizpilda tabulu v_user_personality_data, ja lietotaaja nav			
		$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$userid_prev));
		if ($user_ir==false)
		{
				
				$ls='learningstyle';
				$record7 = new stdClass();
				$record7->userid=$userid_prev;
				$record7->property=$ls;
				$record7->value=$rezst;
				$table='v_user_personality_data';
				$lastid=$DB->insert_record($table, $record7);
		
				
				//testa izvads par stiliem pa vertikaali
				echo '<br/>rezst= '.$rezst;
							
							unset($arr_lsv);
							$arr_lsv=array();
							$arr_lsv[$k]=$stils;
							$k++;
							//echo "<br/>";
					
							$userid_prev=$value;//atceras ieprieksejo userid	
							$n++;
				} //user ir false  	


}//for result


echo "</table>";

//------------------------------------------------------------------------------------------
//peedeejā lietotaja dati v_user_lersonality tikai par vienu studentu
$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$userid_prev));
				if ($user_ir==false)
				{
						
						$ls='learningstyle';
						$record7 = new stdClass();
						$record7->userid=$userid_prev;
						$record7->property=$ls;
						$record7->value=$rezst;
						$table='v_user_personality_data';
						$lastid=$DB->insert_record($table, $record7);
				} 
//-----------------------------------------------------------------------------------------

}//if ja admin
else 
echo "<br/>Jums nav pieejama šī darbība!";

?>