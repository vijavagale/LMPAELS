<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php

//echo "vija<br/>";
global $CFG;
global $COURSE;
require_once("../../../config.php") ;
require_once("../my_lib.php") ;
//require_once("../block_learnerdata.php") ;
require_login();
if (user_rights())
echo "<br>Ir tiesiibas"; else echo "<br>Nav tiesiibu";
$instanceid= $_GET['instanceid'];
echo "<br/>Instances id =".$instanceid;

//courseid iegūšana
if (get_courseid($instanceid)!=0)
echo "<br>Kursa id atrada!"; else echo "<br>Kursa id neatrada";
$courseid= get_courseid($instanceid);

echo "<br>Courseid= ".$courseid;	
	//tas neiet
	/*
$sql = "SELECT 1
              FROM {role_assignments}
             WHERE userid = :userid AND roleid IN ($CFG->coursecontact)";
    print_r($DB->record_exists_sql($sql, array('userid'=>$userid)));
	
	if (!empty($CFG->defaultuserroleid)) {
        $syscontext = context_system::instance();
		print_r($syscontext);
        $accessdata['ra'][$syscontext->path][(int)$CFG->defaultuserroleid] = (int)$CFG->defaultuserroleid;
        $raparents[$CFG->defaultuserroleid][$syscontext->id] = $syscontext->id;
    }

context_course $coursecontext;
echo "ddd".$coursecontext;

foreach ($sw as $path => $roleid) {
        if ($record = $DB->get_record('context', array('path'=>$path))) {
            $context = context::instance_by_id($record->id);
            //role_switch($roleid, $context);
        }
    }*/

?>