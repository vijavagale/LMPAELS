<?php
//iepriekšejā klase
/*
 class format_onebyone_renderer extends format_section_renderer_base {

    /**
     * Constructor method, calls the parent constructor
     *
     * @param moodle_page $page
     * @param string $target one of rendering target constants
     */
    public function __construct(moodle_page $page, $target) {
        parent::__construct($page, $target);

        // Since format_topics_renderer::section_edit_controls() only displays the 'Set current section' control when editing mode is on
        // we need to be sure that the link 'Turn editing mode on' is available for a user who does not have any other managing capability.
        $page->set_other_editing_capability('moodle/course:setcurrentsection');
    }

    /**
     * Generate the starting container html for a list of sections
     * @return string HTML to output.
     */
    protected function start_section_list() {
        return html_writer::start_tag('ul', array('class' => 'topics'));
    }

    /**
     * Generate the closing container html for a list of sections
     * @return string HTML to output.
     */
    protected function end_section_list() {
        return html_writer::end_tag('ul');
    }

    /**
     * Generate the title for this section page
     * @return string the page title
     */
    protected function page_title() {
        return get_string('topicoutline');
    }

    /**
     * Generate the edit control items of a section
     *
     * @param stdClass $course The course entry from DB
     * @param stdClass $section The course_section entry from DB
     * @param bool $onsectionpage true if being printed on a section page
     * @return array of edit control items
     */
    protected function section_edit_control_items($course, $section, $onsectionpage = false) {
        global $PAGE;

        if (!$PAGE->user_is_editing()) {
            return array();
        }

        $coursecontext = context_course::instance($course->id);

        if ($onsectionpage) {
            $url = course_get_url($course, $section->section);
        } else {
            $url = course_get_url($course);
        }
        $url->param('sesskey', sesskey());

        $isstealth = $section->section > $course->numsections;
        $controls = array();
        if (!$isstealth && $section->section && has_capability('moodle/course:setcurrentsection', $coursecontext)) {
            if ($course->marker == $section->section) {  // Show the "light globe" on/off.
                $url->param('marker', 0);
                $markedthistopic = get_string('markedthistopic');
                $highlightoff = get_string('highlightoff');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marked',
                                               'name' => $highlightoff,
                                               'pixattr' => array('class' => '', 'alt' => $markedthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markedthistopic));
            } else {
                $url->param('marker', $section->section);
                $markthistopic = get_string('markthistopic');
                $highlight = get_string('highlight');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marker',
                                               'name' => $highlight,
                                               'pixattr' => array('class' => '', 'alt' => $markthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markthistopic));
            }
        }

        $parentcontrols = parent::section_edit_control_items($course, $section, $onsectionpage);

        // If the edit key exists, we are going to insert our controls after it.
        if (array_key_exists("edit", $parentcontrols)) {
            $merged = array();
            // We can't use splice because we are using associative arrays.
            // Step through the array and merge the arrays.
            foreach ($parentcontrols as $key => $action) {
                $merged[$key] = $action;
                if ($key == "edit") {
                    // If we have come to the edit key, merge these controls here.
                    $merged = array_merge($merged, $controls);
                }
            }

            return $merged;
        } else {
            return array_merge($controls, $parentcontrols);
        }
    }

//mans pievienotais kursa struktuura
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//mans
public function topic_section_subsection_create($sectionnum,$course) {
global $DB;
	
	//$cm=$DB->get_records('course_sections', array('section' => $sectionnum), 'id,course,section', MUST_EXIST))
	if (!$DB->record_exists('course_sections',array('section' => $sectionnum))) 
	{$idd=$DB->insert_record('course_sections', array(
						'course' => $course->id,
						'section' => $sectionnum,
						'sequence' => ''));		
	//echo "idd= ".$idd;
	return 0;
	}
		else return $idd;//echo "Sekcija jau eksistē";
}
	
public function topic_structure_start() {
	$url = $PAGE->url;
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'onebyone','id'=>'content'));
	$t.= html_writer::tag('a','Close All', array('href' => '#', 'id' => 'closeAll', 'title'=>'Close All'));
	$t.='|';
	$t.= html_writer::tag('a','Open All', array('href' => '#', 'id' => 'openAll', 'title'=>'Open All'));
	return $t;
}
//Dalas struktūra  0.dala Kopsavilkums Summary
public function topic_structure_summary($summary) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section0'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Tēmas apraksts';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	//šeit labot
	//neaizgaaja
	//$t.=$this->section_header($thissection, $course, $t, $displaysection);

	
	$t.=$summary;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
//dalas beigas
return $t;
}
public function topic_structure_teoretical($ar) {
//Dalas struktūra  1.dala
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section1'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Teorētiskā daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$ar;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//dalas beigas
	return $t;}
//02.dala
public function topic_structure_practical($arinput,$aroutput) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section2'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Praktiskā daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;')); //????
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$arinput;
	$t.=$aroutput;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//2.dalas beigas
	return $t;}
//3.dala
public function topic_structure_assessment($arinput,$aroutput) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section3'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Vērtēšanas daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$arinput;
	$t.=$aroutput;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//3.dalas beigas
	return $t;
}
public function topic_structure_end() {
html_writer::end_tag('div'); //onebyone
//js piesaista
echo '
	<script type="text/javascript" src="format/onebyone/javascript/jquery.min.js"></script> 
	<script type="text/javascript" src="format/onebyone/javascript/highlight.pack.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.cookie.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.collapsible.js"></script>
	<!-- <script type="text/javascript" src="format/onebyone/javascript/jquery.doc.js"></script> -->
	<script type="text/javascript">
';
echo "
    $(document).ready(function() {

       //syntax highlighter
        hljs.tabReplace = '    ';
     hljs.initHighlightingOnLoad(); 

        $.fn.slideFadeToggle = function(speed, easing, callback) {
            return this.animate({opacity: 'toggle', height: 'toggle'}, speed, easing, callback);
        };

        //collapsible management
       
        $('.page_collapsible').collapsible({
            defaultOpen: 'body_section1',
            cookieName: 'body2',
            speed: 'slow',
            animateOpen: function (elem, opts) { //replace the standard slideUp with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            animateClose: function (elem, opts) { //replace the standard slideDown with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            loadOpen: function (elem) { //replace the standard open state with custom function
                elem.next().show();
            },
            loadClose: function (elem, opts) { //replace the close state with custom function
                elem.next().hide();
            }

        });

        //assign open/close all to functions
        function openAll() {
            $('.page_collapsible').collapsible('openAll');
        }
        function closeAll() {
            $('.page_collapsible').collapsible('closeAll');
        }

        //listen for close/open all
        $('#closeAll').click(function(event) {
            event.preventDefault();
            closeAll();
		});
		
        $('#openAll').click(function(event) {
            event.preventDefault();
            openAll();
        });

    });
</script>
<!-- /JS -->
";
}

//veel mans
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// viena tēma lapā panemta no course/format
 public function print_single_section_page1($course, $sections, $mods, $modnames, $modnamesused, $displaysection) {
        global $PAGE;

        $modinfo = get_fast_modinfo($course);
        $course = course_get_format($course)->get_course();

        // Can we view the section in question?
        if (!($sectioninfo = $modinfo->get_section_info($displaysection))) {
            // This section doesn't exist
            print_error('unknowncoursesection', 'error', null, $course->fullname);
            return;
        }

        if (!$sectioninfo->uservisible) {
            if (!$course->hiddensections) {
                echo $this->start_section_list();
                echo $this->section_hidden($displaysection, $course->id);
                echo $this->end_section_list();
            }
            // Can't view this section.
            return;
        }

        // Copy activity clipboard..
        echo $this->course_activity_clipboard($course, $displaysection);
        $thissection = $modinfo->get_section_info(0);
        if ($thissection->summary or !empty($modinfo->sections[0]) or $PAGE->user_is_editing()) {
   			echo $this->start_section_list();
            echo $this->section_header($thissection, $course, true, $displaysection);
            echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
			
            echo $this->courserenderer->course_section_add_cm_control($course, 0, $displaysection);
            echo $this->section_footer();
            echo $this->end_section_list();
        }

        // Start single-section div
        echo html_writer::start_tag('div', array('class' => 'single-section'));

        // The requested section page.
        $thissection = $modinfo->get_section_info($displaysection);

        // Title with section navigation links.
        $sectionnavlinks = $this->get_nav_links($course, $modinfo->get_section_info_all(), $displaysection);
        $sectiontitle = '';
        $sectiontitle .= html_writer::start_tag('div', array('class' => 'section-navigation navigationtitle'));
        $sectiontitle .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
        $sectiontitle .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
        // Title attributes
        $classes = 'sectionname';
        if (!$thissection->visible) {
            $classes .= ' dimmed_text';
        }
		
        $sectiontitle .= $this->output->heading(get_section_name($course, $displaysection), 3, $classes);

        $sectiontitle .= html_writer::end_tag('div');
        //temas galvenai virsrakts
		echo $sectiontitle; //raada tēmas virsrakstu
//////////////////////////////////////////////////////////////////////////////
//edit poga temai, summarai inf
$o = '';
                   
        $o = $this->output->spacer();

        $controls = $this->section_edit_control_items($course, $thissection, $onsectionpage);
        $o .= $this->section_edit_control_menu($controls, $course, $thissection);
      
		
		
		//tas stradaja
		//$rightcontent = $this->section_right_content($thissection, $course, $onsectionpage);
        //$o.= html_writer::tag('div', $rightcontent, array('class' => 'right side'));
        //beigas
		
      echo $o;
////////////////////////////////////////		
	
        // Now the list of sections..
          echo $this->start_section_list();
        
		//edit poga sekcijai??? ta ir kopā ar summary
		//echo $this->section_header($thissection, $course, true, $displaysection);
 
		// Show completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// par temu summaraa informācija
		//izveidotais numurs + 01/02/03/04
		$sectionnumber = $thissection->section;
		echo $this->topic_structure_start();
			$sectionnum=$sectionnumber.'01';
			//$this->topic_section_subsection_create($sectionnum,$course);
			if ($thissection->summary) $summary=$thissection->summary;
		echo $this->topic_structure_summary($summary);
		//echo $this->section_header($thissection, $course, $t, $displaysection);
// par temu teorētiskā informācija
			//------------------------------
			$sectionnum=$sectionnumber.'02';
			$o='';
//veel variants kursa veidošanai
	
	
	//$se=$this->topic_section_subsection_create($sectionnum,$course);
/*if ($se>1) {
        $section = $DB->get_field('course_sections', 'section', array('id' => $sectionid, 'course' => $course->id), MUST_EXIST);
    }
    if ($section) {
        $urlparams['section'] = $section;
    }
*/	
	
			//$o.=$this->start_section_list();
			
            //echo $this->section_header($thissection, $course, true, $displaysection);
			
			//$o.= html_writer::start_tag('li', array('id' => 'section-'.$sectionnum->section,
           // 'class' => 'section main clearfix'.$sectionstyle, 'role'=>'region',
           // 'aria-label'=> get_section_name($course, $sectionnum)));

        // Create a span that contains the section title to be used to create the keyboard section move menu.
        //$o .= html_writer::tag('span', $this->section_title($section, $course), array('class' => 'hidden sectionname'));

        /*$leftcontent = $this->section_left_content($sectionnum, $course, $onsectionpage);
        $o.= html_writer::tag('div', $leftcontent, array('class' => 'left side'));
*/
        //$rightcontent = $this->section_right_content($sectionnum, $course, $onsectionpage);
      //  $o.= html_writer::tag('div', $rightcontent, array('class' => 'right side'));
       // $o.= html_writer::start_tag('div', array('class' => 'content'));
	

			
			
			
			echo '</br>Displaysection='.$displaysection;
			echo 'Sectionnum='.$sectionnum;
            $o.=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
			$o.=$this->courserenderer->course_section_add_cm_control($course, 0, $sectionnum);
           // $o.=$this->section_footer();
            //$o.=$this->end_section_list();
			
			//$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			//$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
				//$o.= html_writer::end_tag('div'); 	
				
				echo $this->topic_structure_teoretical($o);
				
// par temu praktiskā informācija
			//----------------------------------
			$sectionnum=$sectionnumber.'03';
			//$this->topic_section_subsection_create($sectionnum,$course);
			//course_create_sections_if_missing($course, $sectionnum);
			$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
			
			//echo $o;
		
		echo $this->topic_structure_practical($arinput,$aroutput);
			//-------------------------------------------------
			$sectionnum=$sectionnumber.'04';
			//$this->topic_section_subsection_create($sectionnum,$course);
			//course_create_sections_if_missing($course, $sectionnum);
			$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
			//echo $o;
		// par temu vertesanas informācija	
		echo $this->topic_structure_assessment($arinput,$aroutput);
			$this->topic_structure_end();
		
//$class_methods = get_class_methods('format_onebyone_renderer');
//echo "<br/>";
//foreach ($class_methods as $method_name) {
 //   echo "$method_name<br/>";
//}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //so rindinu ieliku savaa dalā tā ir par visiem tēmā saliktajiem resursiem 
		echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
        //raada pievienot resursus tekstu
		echo $this->courserenderer->course_section_add_cm_control($course, $displaysection, $displaysection);
        
		echo $this->section_footer();
        echo $this->end_section_list();

        // Display section bottom navigation.
        $sectionbottomnav = '';
        $sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
        $sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
        $sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
        //pareja uz jebkuru temu
		$sectionbottomnav .= html_writer::tag('div', $this->section_nav_selection($course, $sections, $displaysection),
            array('class' => 'mdl-align'));
        $sectionbottomnav .= html_writer::end_tag('div');
        echo $sectionbottomnav;

        // Close single-section div.
		
        echo html_writer::end_tag('div');
    }
	
//no flexsection
public function display_section($course, $section, $sr, $level = 0) {
        global $PAGE;
        $course = course_get_format($course)->get_course();
        $section = course_get_format($course)->get_section($section);
        $context = context_course::instance($course->id);
        $contentvisible = true;
        if (!$section->uservisible || !course_get_format($course)->is_section_real_available($section)) {
            if ($section->visible && !$section->available && $section->availableinfo) {
                // Still display section but without content.
                $contentvisible = false;
            } else {
                return '';
            }
        }
        $sectionnum = $section->section;
        $movingsection = course_get_format($course)->is_moving_section();
        if ($level === 0) {
            $cancelmovingcontrols = course_get_format($course)->get_edit_controls_cancelmoving();
            foreach ($cancelmovingcontrols as $control) {
                echo $this->render($control);
            }
            echo html_writer::start_tag('ul', array('class' => 'flexsections flexsections-level-0'));
            if ($section->section) {
                $this->display_insert_section_here($course, $section->parent, $section->section, $sr);
            }
        }
        echo html_writer::start_tag('li',
                array('class' => "section main".
                    ($movingsection === $sectionnum ? ' ismoving' : '').
                    (course_get_format($course)->is_section_current($section) ? ' current' : '').
                    (($section->visible && $contentvisible) ? '' : ' hidden'),
                    'id' => 'section-'.$sectionnum));

        // display controls except for expanded/collapsed
        $controls = course_get_format($course)->get_section_edit_controls($section, $sr);
        $collapsedcontrol = null;
        $controlsstr = '';
        foreach ($controls as $idxcontrol => $control) {
            if ($control->class === 'expanded' || $control->class === 'collapsed') {
                $collapsedcontrol = $control;
            } else {
                $controlsstr .= $this->render($control);
            }
        }
        if (!empty($controlsstr)) {
            echo html_writer::tag('div', $controlsstr, array('class' => 'controls'));
        }

        // display section content
        echo html_writer::start_tag('div', array('class' => 'content'));
        // display section name and expanded/collapsed control
        if ($sectionnum && ($title = $this->section_title($sectionnum, $course, ($level == 0) || !$contentvisible))) {
            if ($collapsedcontrol) {
                $title = $this->render($collapsedcontrol). $title;
            }
            echo html_writer::tag('h3', $title, array('class' => 'sectionname'));
        }

        echo $this->section_availability_message($section,
            has_capability('moodle/course:viewhiddensections', $context));

        // display section description (if needed)
        if ($contentvisible && ($summary = $this->format_summary_text($section))) {
            echo html_writer::tag('div', $summary, array('class' => 'summary'));
        } else {
            echo html_writer::tag('div', '', array('class' => 'summary nosummary'));
        }
        // display section contents (activities and subsections)
        if ($contentvisible && ($section->collapsed == FORMAT_FLEXSECTIONS_EXPANDED || !$level)) {
            // display resources and activities
            echo $this->courserenderer->course_section_cm_list($course, $section, $sr);
            if ($PAGE->user_is_editing()) {
                // a little hack to allow use drag&drop for moving activities if the section is empty
                if (empty(get_fast_modinfo($course)->sections[$sectionnum])) {
                    echo "<ul class=\"section img-text\">\n</ul>\n";
                }
                echo $this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sr);
            }
            // display subsections
            $children = course_get_format($course)->get_subsections($sectionnum);
            if (!empty($children) || $movingsection) {
                echo html_writer::start_tag('ul', array('class' => 'flexsections flexsections-level-'.($level+1)));
                foreach ($children as $num) {
                    $this->display_insert_section_here($course, $section, $num, $sr);
                    $this->display_section($course, $num, $sr, $level+1);
                }
                $this->display_insert_section_here($course, $section, null, $sr);
                echo html_writer::end_tag('ul'); // .flexsections
            }
            if ($addsectioncontrol = course_get_format($course)->get_add_section_control($sectionnum)) {
                echo $this->render($addsectioncontrol);
            }
        }
        echo html_writer::end_tag('div'); // .content
        echo html_writer::end_tag('li'); // .section
        if ($level === 0) {
            if ($section->section) {
                $this->display_insert_section_here($course, $section->parent, null, $sr);
            }
            echo html_writer::end_tag('ul'); // .flexsections
        }
    }	
	}


?>