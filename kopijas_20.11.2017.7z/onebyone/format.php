<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Topics course format.  Display the whole course as "topics" made of modules.
 *
 * @package format_topics
 * @copyright 2006 The Open University
 * @author N.D.Freear@open.ac.uk, and others.
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

//require_once($CFG->dirroot.'/config.php') ; 
require_once($CFG->libdir.'/filelib.php');
require_once($CFG->libdir.'/completionlib.php');
//require_once($CFG->dirroot. '/lib/moodlelib.php');

require_once($CFG->dirroot.'/blocks/tmm/block_tmm.php');
echo '<div>
<link href="format/onebyone/styles.css" rel="stylesheet" />
<link href="format/onebyone/css/demo.css" rel="stylesheet" /> 
</div>
';

//global $PAGE;
//require_once($CFG->dirroot.'/course/format/renderer.php');
//require_once($CFG->dirroot. '/lib/moodlelib.php');
//priekš db
//require_once($CFG->dirroot.'/config.php') ; 

global $CFG;


/*
dazi piemeri
$strgroups  = get_string('groups');
    $strgroupmy = get_string('groupmy');
    $editing    = $PAGE->user_is_editing();
	if ($forum = forum_get_course_forum($course->id, 'social')) {

        $cm = get_coursemodule_from_instance('forum', $forum->id);
        $modcontext = context_module::instance($cm->id);
*/

//echo "<br/>format faila augša: ";
//echo "DU tests";
//echo "<a href='".$CFG->wwwroot."/du-tests/web/>'Du Tests </a><br />";
//echo '<a href="/moodle/du-tests/web/">DU Tests </a><br />';
//require_login($course);
//require_capability('moodle/course:update', context_course::instance($course->id));
//require_sesskey();



////////////////////////////////////////////////////////////////
//kas buus


// Horrible backwards compatible parameter aliasing..
if ($onebyone = optional_param('onebyone', 0, PARAM_INT)) {
    $url = $PAGE->url;
    $url->param('section', $onebyone);
    debugging('Outdated topic param passed to course/view.php', DEBUG_DEVELOPER);
    redirect($url);
}
//izvads tests
//echo "<br>onebyone= ".$onebyone;
//echo "<br/>url= "; print_r($url);
//echo "<br/>url2= ".$url->param('section', $onebyone);;
// End backwards-compatible aliasing..

$context = context_course::instance($course->id);

if (($marker >=0) && has_capability('moodle/course:setcurrentsection', $context) && confirm_sesskey()) {
    $course->marker = $marker;
    course_set_marker($course->id, $marker);
	
}

// make sure all sections are created
$course = course_get_format($course)->get_course();
course_create_sections_if_missing($course, range(0, $course->numsections));
//varbūt šeit veidot sekcijas   ??????

$renderer = $PAGE->get_renderer('format_onebyone');
	
$tmminstanceid=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
//$block= $DB->get_records_menu('context',array('instanceid'=>$tmminstanceid),'instanceid','instanceid,id'); 

		if ($tmminstanceid==0) echo "<br>Kursam ir jāpievieno tēmu vadības bloks"; 
			else 
			{$blockinstance= new block_tmm();

if ($blockinstance->user_rights()!=1)  
				{ if (!empty($displaysection)) { $renderer->print_single_section_page_obo($course, null, null, null, null, $displaysection);}
					else 	{$renderer->print_single_section_page_obo($course, null, null, null, null, 1);} //studentam rada 1 sekciju
				} 
else 
			//pasniedzejs
	if (!empty($displaysection)) { $renderer->print_single_section_page_obo($course, null, null, null, null, $displaysection);} 
	else
			 {$renderer->print_multiple_section_page($course, null, null, null, null);}
			
}
// Include course format js module

$PAGE->requires->js('/course/format/onebyone/format.js');
//$PAGE->requires->js_init_call('M.course.format.init_onebyone');
//echo "<br/>format faila apakša: ";
