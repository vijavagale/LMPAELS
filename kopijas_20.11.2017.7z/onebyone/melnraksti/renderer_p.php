<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for outputting the topics course format.
 *
 * @package format_topics
 * @copyright 2012 Dan Poltawski
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @since Moodle 2.3
 */


defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot.'/course/format/renderer.php');

echo "<br/>renderer faila augša: ";
/**
 * Basic renderer for topics format.
 *
 * @copyright 2012 Dan Poltawski
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
//class format_onebyone_renderer extends format_section_renderer_base {
//class format_onebyone_renderer impliments format_section_renderer_base, core_course_renderer {
 class format_onebyone_renderer extends format_section_renderer_base {
 /**
     * Constructor method, calls the parent constructor
     *
     * @param moodle_page $page
     * @param string $target one of rendering target constants
     */
    public function __construct(moodle_page $page, $target) {
        parent::__construct($page, $target);

        // Since format_topics_renderer::section_edit_controls() only displays the 'Set current section' control when editing mode is on
        // we need to be sure that the link 'Turn editing mode on' is available for a user who does not have any other managing capability.
        $page->set_other_editing_capability('moodle/course:setcurrentsection');
		
    }

    /**
     * Generate the starting container html for a list of sections
     * @return string HTML to output.
     */
    protected function start_section_list() {
       
		return html_writer::start_tag('ul', array('class' => 'topics'));
    }

	
    /**
     * Generate the closing container html for a list of sections
     * @return string HTML to output.
     */
    protected function end_section_list() {
        return html_writer::end_tag('ul');
    }

    /**
     * Generate the title for this section page
     * @return string the page title
     */
    protected function page_title() {
	
	        return get_string('topicoutline');
    }

    /**
     * Generate the edit controls of a section
     *
     * @param stdClass $course The course entry from DB
     * @param stdClass $section The course_section entry from DB
     * @param bool $onsectionpage true if being printed on a section page
     * @return array of links with edit controls
     */
        protected function section_edit_control_items($course, $section, $onsectionpage = false) {
        global $PAGE;

        if (!$PAGE->user_is_editing()) {
            return array();
        }

        $coursecontext = context_course::instance($course->id);

        if ($onsectionpage) {
            $url = course_get_url($course, $section->section);
        } else {
            $url = course_get_url($course);
        }
        $url->param('sesskey', sesskey());

        $isstealth = $section->section > $course->numsections;
        $controls = array();
        if (!$isstealth && $section->section && has_capability('moodle/course:setcurrentsection', $coursecontext)) {
            if ($course->marker == $section->section) {  // Show the "light globe" on/off.
                $url->param('marker', 0);
                $markedthistopic = get_string('markedthistopic');
                $highlightoff = get_string('highlightoff');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marked',
                                               'name' => $highlightoff,
                                               'pixattr' => array('class' => '', 'alt' => $markedthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markedthistopic));
            } else {
                $url->param('marker', $section->section);
                $markthistopic = get_string('markthistopic');
                $highlight = get_string('highlight');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marker',
                                               'name' => $highlight,
                                               'pixattr' => array('class' => '', 'alt' => $markthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markthistopic));
            }
        }

        $parentcontrols = parent::section_edit_control_items($course, $section, $onsectionpage);

        // If the edit key exists, we are going to insert our controls after it.
        if (array_key_exists("edit", $parentcontrols)) {
            $merged = array();
            // We can't use splice because we are using associative arrays.
            // Step through the array and merge the arrays.
            foreach ($parentcontrols as $key => $action) {
                $merged[$key] = $action;
                if ($key == "edit") {
                    // If we have come to the edit key, merge these controls here.
                    $merged = array_merge($merged, $controls);
                }
            }

            return $merged;
        } else {
            return array_merge($controls, $parentcontrols);
        }
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//mans
	
public function topic_structure_start() {
	$url = $PAGE->url;
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'onebyone','id'=>'content'));
	$t.= html_writer::tag('a','Close All', array('href' => '#', 'id' => 'closeAll', 'title'=>'Close All'));
	$t.='|';
	$t.= html_writer::tag('a','Open All', array('href' => '#', 'id' => 'openAll', 'title'=>'Open All'));
	return $t;
}
//Dalas struktūra  0.dala Kopsavilkums Summary
public function topic_structure_summary($summary) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section0'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Tēmas apraksts';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$summary;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
//dalas beigas
return $t;
}
public function topic_structure_teoretical($arinput,$aroutput) {
//Dalas struktūra  1.dala
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section1'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Teorētiskā daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$arinput;
	$t.=$aroutput;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//dalas beigas
	return $t;}
//02.dala
public function topic_structure_practical($arinput,$aroutput) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section2'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Praktiskā daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;')); //????
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$arinput;
	$t.=$aroutput;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//2.dalas beigas
	return $t;}
//3.dala
public function topic_structure_assessment($arinput,$aroutput) {
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>'body-section3'));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.='Vērtēšanas daļa';
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	$t.=$arinput;
	$t.=$aroutput;
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
	//3.dalas beigas
	return $t;
}
public function topic_structure_end() {
html_writer::end_tag('div'); //onebyone
//js piesaista
echo '
	<script type="text/javascript" src="format/onebyone/javascript/jquery.min.js"></script> 
	<script type="text/javascript" src="format/onebyone/javascript/highlight.pack.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.cookie.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.collapsible.js"></script>
	<!-- <script type="text/javascript" src="format/onebyone/javascript/jquery.doc.js"></script> -->
	<script type="text/javascript">
';
echo "
    $(document).ready(function() {

       //syntax highlighter
        hljs.tabReplace = '    ';
     hljs.initHighlightingOnLoad(); 

        $.fn.slideFadeToggle = function(speed, easing, callback) {
            return this.animate({opacity: 'toggle', height: 'toggle'}, speed, easing, callback);
        };

        //collapsible management
       
        $('.page_collapsible').collapsible({
            defaultOpen: 'body_section1',
            cookieName: 'body2',
            speed: 'slow',
            animateOpen: function (elem, opts) { //replace the standard slideUp with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            animateClose: function (elem, opts) { //replace the standard slideDown with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            loadOpen: function (elem) { //replace the standard open state with custom function
                elem.next().show();
            },
            loadClose: function (elem, opts) { //replace the close state with custom function
                elem.next().hide();
            }

        });

        //assign open/close all to functions
        function openAll() {
            $('.page_collapsible').collapsible('openAll');
        }
        function closeAll() {
            $('.page_collapsible').collapsible('closeAll');
        }

        //listen for close/open all
        $('#closeAll').click(function(event) {
            event.preventDefault();
            closeAll();
		});
		
        $('#openAll').click(function(event) {
            event.preventDefault();
            openAll();
        });

    });
</script>
<!-- /JS -->
";
} //fjas topic structure aizveersana

//no course renderer.php panemta funkcija
//japārraksta šo funkciju

/*public function course_section_add_cm_control1($course, $section, $sectionreturn = null, $displayoptions = array()) {
        global $CFG;

        $vertical = !empty($displayoptions['inblock']);

        // check to see if user can add menus and there are modules to add
        if (!has_capability('moodle/course:manageactivities', context_course::instance($course->id))
                || !$this->page->user_is_editing()
                || !($modnames = get_module_types_names()) || empty($modnames)) {
            return '';
        }

        // Retrieve all modules with associated metadata
        $modules = get_module_metadata($course, $modnames, $sectionreturn);
        $urlparams = array('section' => $section);

        // We'll sort resources and activities into two lists
        $activities = array(MOD_CLASS_ACTIVITY => array(), MOD_CLASS_RESOURCE => array());

        foreach ($modules as $module) {
            if (isset($module->types)) {
                // This module has a subtype
                // NOTE: this is legacy stuff, module subtypes are very strongly discouraged!!
                $subtypes = array();
                foreach ($module->types as $subtype) {
                    $link = $subtype->link->out(true, $urlparams);
                    $subtypes[$link] = $subtype->title;
                }

                // Sort module subtypes into the list
                $activityclass = MOD_CLASS_ACTIVITY;
                if ($module->archetype == MOD_CLASS_RESOURCE) {
                    $activityclass = MOD_CLASS_RESOURCE;
                }
                if (!empty($module->title)) {
                    // This grouping has a name
                    $activities[$activityclass][] = array($module->title => $subtypes);
                } else {
                    // This grouping does not have a name
                    $activities[$activityclass] = array_merge($activities[$activityclass], $subtypes);
                }
            } else {
                // This module has no subtypes
                $activityclass = MOD_CLASS_ACTIVITY;
                if ($module->archetype == MOD_ARCHETYPE_RESOURCE) {
                    $activityclass = MOD_CLASS_RESOURCE;
                } else if ($module->archetype === MOD_ARCHETYPE_SYSTEM) {
                    // System modules cannot be added by user, do not add to dropdown
                    continue;
                }
                $link = $module->link->out(true, $urlparams);
                $activities[$activityclass][$link] = $module->title;
            }
        }

        $straddactivity = get_string('addactivity');
        $straddresource = get_string('addresource');
        $sectionname = get_section_name($course, $section);
        $strresourcelabel = get_string('addresourcetosection', null, $sectionname);
        $stractivitylabel = get_string('addactivitytosection', null, $sectionname);

        $output = html_writer::start_tag('div', array('class' => 'section_add_menus', 'id' => 'add_menus-section-' . $section));

        if (!$vertical) {
            $output .= html_writer::start_tag('div', array('class' => 'horizontal'));
        }

        if (!empty($activities[MOD_CLASS_RESOURCE])) {
            $select = new url_select($activities[MOD_CLASS_RESOURCE], '', array(''=>$straddresource), "ressection$section");
            $select->set_help_icon('resources');
            $select->set_label($strresourcelabel, array('class' => 'accesshide'));
            $output .= $this->output->render($select);
        }

        if (!empty($activities[MOD_CLASS_ACTIVITY])) {
            $select = new url_select($activities[MOD_CLASS_ACTIVITY], '', array(''=>$straddactivity), "section$section");
            $select->set_help_icon('activities');
            $select->set_label($stractivitylabel, array('class' => 'accesshide'));
            $output .= $this->output->render($select);
        }

        if (!$vertical) {
            $output .= html_writer::end_tag('div');
        }

        $output .= html_writer::end_tag('div');

        if (course_ajax_enabled($course) && $course->id == $this->page->course->id) {
            // modchooser can be added only for the current course set on the page!
            $straddeither = get_string('addresourceoractivity');
            // The module chooser link
            $modchooser = html_writer::start_tag('div', array('class' => 'mdl-right'));
            $modchooser.= html_writer::start_tag('div', array('class' => 'section-modchooser'));
            $icon = $this->output->pix_icon('t/add', '');
            $span = html_writer::tag('span', $straddeither, array('class' => 'section-modchooser-text'));
            $modchooser .= html_writer::tag('span', $icon . $span, array('class' => 'section-modchooser-link'));
            $modchooser.= html_writer::end_tag('div');
            $modchooser.= html_writer::end_tag('div');

            // Wrap the normal output in a noscript div
            $usemodchooser = get_user_preferences('usemodchooser', $CFG->modchooserdefault);
            if ($usemodchooser) {
                $output = html_writer::tag('div', $output, array('class' => 'hiddenifjs addresourcedropdown'));
                $modchooser = html_writer::tag('div', $modchooser, array('class' => 'visibleifjs addresourcemodchooser'));
            } else {
                // If the module chooser is disabled, we need to ensure that the dropdowns are shown even if javascript is disabled
                $output = html_writer::tag('div', $output, array('class' => 'show addresourcedropdown'));
                $modchooser = html_writer::tag('div', $modchooser, array('class' => 'hide addresourcemodchooser'));
            }
            $output = $this->course_modchooser($modules, $course) . $modchooser . $output;
        }

        return $output;
    }

*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// viena tēma lapā panemta no course/format
 public function print_single_section_page1($course, $sections, $mods, $modnames, $modnamesused, $displaysection) {
        global $PAGE;

        $modinfo = get_fast_modinfo($course);
        $course = course_get_format($course)->get_course();

        // Can we view the section in question?
        if (!($sectioninfo = $modinfo->get_section_info($displaysection))) {
            // This section doesn't exist
            print_error('unknowncoursesection', 'error', null, $course->fullname);
            return;
        }

        if (!$sectioninfo->uservisible) {
            if (!$course->hiddensections) {
                echo $this->start_section_list();
                echo $this->section_hidden($displaysection, $course->id);
                echo $this->end_section_list();
            }
            // Can't view this section.
            return;
        }

        // Copy activity clipboard..
        echo $this->course_activity_clipboard($course, $displaysection);
        $thissection = $modinfo->get_section_info(0);
        if ($thissection->summary or !empty($modinfo->sections[0]) or $PAGE->user_is_editing()) {
   			echo $this->start_section_list();
            echo $this->section_header($thissection, $course, true, $displaysection);
            echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
			
            echo $this->courserenderer->course_section_add_cm_control($course, 0, $displaysection);
            echo $this->section_footer();
            echo $this->end_section_list();
        }

        // Start single-section div
        echo html_writer::start_tag('div', array('class' => 'single-section'));

        // The requested section page.
        $thissection = $modinfo->get_section_info($displaysection);

        // Title with section navigation links.
        $sectionnavlinks = $this->get_nav_links($course, $modinfo->get_section_info_all(), $displaysection);
        $sectiontitle = '';
        $sectiontitle .= html_writer::start_tag('div', array('class' => 'section-navigation navigationtitle'));
        $sectiontitle .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
        $sectiontitle .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
        // Title attributes
        $classes = 'sectionname';
        if (!$thissection->visible) {
            $classes .= ' dimmed_text';
        }
		
        $sectiontitle .= $this->output->heading(get_section_name($course, $displaysection), 3, $classes);

        $sectiontitle .= html_writer::end_tag('div');
        echo $sectiontitle;

        // Now the list of sections..
        echo $this->start_section_list();
		//temas summary informācija
        //echo $this->section_header($thissection, $course, true, $displaysection);	
		//echo "thissection= ".$thissection->summary;//šī sekcija
		//echo "<br/>displaysection= ".$displaysection->summary;//nezinu kas tas ir
        // Show completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//īstais sekcijas numurs
		$sectionnumber = $thissection->section;
		echo $this->topic_structure_start();
		//izveidotais numurs + 01/02/03/04
			$sectionnum=$sectionnumber.'01';
			if ($thissection->summary) $summary=$thissection->summary;
		echo $this->topic_structure_summary($summary);
			$sectionnum=$sectionnumber.'02';
			$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
		echo $this->topic_structure_teoretical($arinput,$aroutput);
			$sectionnum=$sectionnumber.'03';
			$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
		echo $this->topic_structure_practical($arinput,$aroutput);
			$sectionnum=$sectionnumber.'04';
			$$arinput=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $sectionnumber);
			$aroutput=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
		echo $this->topic_structure_assessment($arinput,$aroutput);
			$this->topic_structure_end();
		
//$class_methods = get_class_methods('format_onebyone_renderer');
//echo "<br/>";
//foreach ($class_methods as $method_name) {
 //   echo "$method_name<br/>";
//}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //so rindinu ieliku savaa dalā tā ir par visiem tēmā saliktajiem resursiem 
		//echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
        //echo $this->courserenderer->course_section_add_cm_control($course, $displaysection, $displaysection);
        
		echo $this->section_footer();
        echo $this->end_section_list();

        // Display section bottom navigation.
        $sectionbottomnav = '';
        $sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
        $sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
        $sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
        //pareja uz jebkuru temu
		$sectionbottomnav .= html_writer::tag('div', $this->section_nav_selection($course, $sections, $displaysection),
            array('class' => 'mdl-align'));
        $sectionbottomnav .= html_writer::end_tag('div');
        echo $sectionbottomnav;

        // Close single-section div.
		
        echo html_writer::end_tag('div');
    }
	
	
	public function print_multiple_section_page1($course, $sections, $mods, $modnames, $modnamesused) {
        global $PAGE;

        $modinfo = get_fast_modinfo($course);
        $course = course_get_format($course)->get_course();

        $context = context_course::instance($course->id);
        // Title with completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
        echo $this->output->heading($this->page_title(), 2, 'accesshide');
	
        // Copy activity clipboard..
        echo $this->course_activity_clipboard($course, 0);

        // Now the list of sections..
        echo $this->start_section_list();

        foreach ($modinfo->get_section_info_all() as $section => $thissection) {
            if ($section == 0) {
                // 0-section is displayed a little different then the others
                if ($thissection->summary or !empty($modinfo->sections[0]) or $PAGE->user_is_editing()) {
                    echo $this->section_header($thissection, $course, false, 0);
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);				
                    echo $this->courserenderer->course_section_add_cm_control($course, 0, 0);
                    echo $this->section_footer();
                }
                continue;
            }
            if ($section > $course->numsections) {
                // activities inside this section are 'orphaned', this section will be printed as 'stealth' below
                continue;
            }
            // Show the section if the user is permitted to access it, OR if it's not available
            // but there is some available info text which explains the reason & should display.
            $showsection = $thissection->uservisible ||
                    ($thissection->visible && !$thissection->available &&
                    !empty($thissection->availableinfo));
           			
			if (!$showsection) {
                // If the hiddensections option is set to 'show hidden sections in collapsed
                // form', then display the hidden section message - UNLESS the section is
                // hidden by the availability system, which is set to hide the reason.
                if (!$course->hiddensections && $thissection->available) {
                    echo $this->section_hidden($section, $course->id);
                }

                continue;
            }
			
            if (!$PAGE->user_is_editing() && $course->coursedisplay == COURSE_DISPLAY_MULTIPAGE) {
                // Display section summary only.
                echo $this->section_summary($thissection, $course, null);
            } else {
                echo $this->section_header($thissection, $course, false, 0);
				
					 
///////////////////////////////////////////////////////////		
		
///////////////////////////////////////////////////////////

                if ($thissection->uservisible) {
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
					
                    echo $this->courserenderer->course_section_add_cm_control($course, $section, 0);
                }
                echo $this->section_footer();
            }
        }

        if ($PAGE->user_is_editing() and has_capability('moodle/course:update', $context)) {
            // Print stealth sections if present.
            foreach ($modinfo->get_section_info_all() as $section => $thissection) {
                if ($section <= $course->numsections or empty($modinfo->sections[$section])) {
                    // this is not stealth section or it is empty
                    continue;
                }
                echo $this->stealth_section_header($section);
                echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
                echo $this->stealth_section_footer();
            }

            echo $this->end_section_list();

            echo html_writer::start_tag('div', array('id' => 'changenumsections', 'class' => 'mdl-right'));

            // Increase number of sections.
            $straddsection = get_string('increasesections', 'moodle');
            $url = new moodle_url('/course/changenumsections.php',
                array('courseid' => $course->id,
                      'increase' => true,
                      'sesskey' => sesskey()));
            $icon = $this->output->pix_icon('t/switch_plus', $straddsection);
            echo html_writer::link($url, $icon.get_accesshide($straddsection), array('class' => 'increase-sections'));

            if ($course->numsections > 0) {
                // Reduce number of sections sections.
                $strremovesection = get_string('reducesections', 'moodle');
                $url = new moodle_url('/course/changenumsections.php',
                    array('courseid' => $course->id,
                          'increase' => false,
                          'sesskey' => sesskey()));
                $icon = $this->output->pix_icon('t/switch_minus', $strremovesection);
                echo html_writer::link($url, $icon.get_accesshide($strremovesection), array('class' => 'reduce-sections'));
            }

						
			
            echo html_writer::end_tag('div');
        } else {
            echo $this->end_section_list();
        }

    }
}
echo "<br/>rendere faila apakša: ";