<?PHP
$plugins = array(
    'highlight'  => array('files' => array('javascript/highlight.pack.js')),
    'collapsible' => array('files' => array('javascript/jquery.collapsible.js')),
    'cookie'      => array('files' => array('javascript/jquery.cookie.js')),
    'min'  => array('files' => array('javascript/jquery.min.js')),
	'demo-css'  => array('files' => array('css/demo.css')),
	'github-css'  => array('files' => array('css/github.css')),
);
$PAGE->requires->jquery('highlight');
$PAGE->requires->jquery_plugin('collapsible');
$PAGE->requires->jquery_plugin('cookie');
$PAGE->requires->jquery_plugin('demo-css');
$PAGE->requires->jquery_plugin('min-css');


