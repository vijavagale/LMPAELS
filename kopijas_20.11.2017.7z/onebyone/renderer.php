<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for outputting the topics course format.
 *
 * @package format_topics
 * @copyright 2012 Dan Poltawski
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @since Moodle 2.3
 */


 
 
defined('MOODLE_INTERNAL') || die();
global $CFG, $USER;
require_once($CFG->dirroot.'/course/format/renderer.php');
require_once($CFG->dirroot. '/lib/moodlelib.php');
//priekš db
require_once($CFG->dirroot.'/config.php') ; 
//prieks js
require_once($CFG->libdir . '/pagelib.php');
//require_once("../automatiski.php");
//require_once("my_lib.php") ;




//require_once(dirname(__FILE__).'/../config.php');
//require_once($CFG->dirroot.'/course/lib.php');
/**
 * Course display settings: display all sections on one page.
 */
//define('COURSE_DISPLAY_SINGLEPAGE', 0);
/**
 * Course display settings: split pages into a page per section.
 */
//define('COURSE_DISPLAY_MULTIPAGE', 1);


/**
 * Basic renderer for topics format.
 *
 * @copyright 2012 Dan Poltawski
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 
//echo "render faila augša";
//global $CFG,$DB;
//echo "Sesija =";
	//	echo "<pre>"; 
	//	print_r($SESSION); 
	//echo "</pre>";
class format_onebyone_renderer extends format_section_renderer_base {

    /**
     * Constructor method, calls the parent constructor
     *
     * @param moodle_page $page
     * @param string $target one of rendering target constants
     */
   public function __construct(moodle_page $page, $target) {
        parent::__construct($page, $target);

        // Since format_topics_renderer::section_edit_controls() only displays the 'Set current section' control when editing mode is on
        // we need to be sure that the link 'Turn editing mode on' is available for a user who does not have any other managing capability.
        $page->set_other_editing_capability('moodle/course:setcurrentsection');
    }

//---------------------------------------------------------------------------------fja
    public function section_nav_selection_obo($course, $sections, $displaysection) {
        global $CFG,$DB;
		$tmminstanceid=$_SESSION['tmminstance'];
		
		$_SESSION['displaysection']=$displaysection;
		//$block_ir = $DB->get_records_menu('context',array('instanceid'=>$tmminstanceid),'id','instanceid,id'); 
		if ($tmminstanceid==0) echo "<br>Kursam ir jāpievieno tēmu vadības bloks"; 
			else {//echo "<br>Bloks ir"; 
			//echo " Bloka id= ".$tmminstanceid;
			$blockinstance= new block_tmm();
			//$blockinstance->general();

$sekcijas = explode(",", $sections);
$skaits=sizeof($sekcijas);		
        $o = '';
		
        $sectionmenu = array();
        //$sectionmenu[course_get_url($course)->out(false)] = get_string('maincoursepage');
        $modinfo = get_fast_modinfo($course);
        $section =$sekcijas[0];
		$i = 0;
        while ($i <$skaits) {
            $thissection = $modinfo->get_section_info($sekcijas[$i]);
           // $showsection = $thissection->uservisible or !$course->hiddensections;
           // if (($showsection) && ($section != $displaysection) && ($url = course_get_url($course, $section))) {
			if ($sekcijas[$i] != $displaysection) {
                $url = course_get_url($course, $sekcijas[$i]);
				$sectionmenu[$url->out(false)] = get_section_name($course, $sekcijas[$i]);}
				$i++;
		}
            
	/*	//$section = 1;
       // while ($section <= $course->numsections) {
            $thissection = $modinfo->get_section_info($section);
            $showsection = $thissection->uservisible or !$course->hiddensections;
            //if (($showsection) && ($section != $displaysection) && ($url = course_get_url($course, $section))) {
                $url = course_get_url($course, $section);
				$sectionmenu[$url->out(false)] = get_section_name($course, $section);
            //}
            //$section++;
        //}*/

        $select = new url_select($sectionmenu, '', array('' => get_string('jumpto')));
        $select->class = 'jumpmenu';
        $select->formid = 'sectionmenu';
        $o .= $this->output->render($select);

        return $o;
  }  //ir bloks
  }//fja
	
	
//-------------------------------------------------------------------------------------	
	/**
     * Generate the starting container html for a list of sections
     * @return string HTML to output.
     */
    protected function start_section_list() {
        return html_writer::start_tag('ul', array('class' => 'topics'));
    }

    /**
     * Generate the closing container html for a list of sections
     * @return string HTML to output.
     */
    protected function end_section_list() {
        return html_writer::end_tag('ul');
    }

    /**
     * Generate the title for this section page
     * @return string the page title
     */
    protected function page_title() {
        return get_string('topicoutline');
    }

    /**
     * Generate the edit control items of a section
     *
     * @param stdClass $course The course entry from DB
     * @param stdClass $section The course_section entry from DB
     * @param bool $onsectionpage true if being printed on a section page
     * @return array of edit control items
     */
    protected function section_edit_control_items($course, $section, $onsectionpage = false) {
        global $PAGE;

        if (!$PAGE->user_is_editing()) {
            return array();
        }

        $coursecontext = context_course::instance($course->id);

        if ($onsectionpage) {
            $url = course_get_url($course, $section->section);
        } else {
            $url = course_get_url($course);
        }
        $url->param('sesskey', sesskey());

        $isstealth = $section->section > $course->numsections;
        $controls = array();
        if (!$isstealth && $section->section && has_capability('moodle/course:setcurrentsection', $coursecontext)) {
            if ($course->marker == $section->section) {  // Show the "light globe" on/off.
                $url->param('marker', 0);
                $markedthistopic = get_string('markedthistopic');
                $highlightoff = get_string('highlightoff');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marked',
                                               'name' => $highlightoff,
                                               'pixattr' => array('class' => '', 'alt' => $markedthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markedthistopic));
            } else {
                $url->param('marker', $section->section);
                $markthistopic = get_string('markthistopic');
                $highlight = get_string('highlight');
                $controls['highlight'] = array('url' => $url, "icon" => 'i/marker',
                                               'name' => $highlight,
                                               'pixattr' => array('class' => '', 'alt' => $markthistopic),
                                               'attr' => array('class' => 'editing_highlight', 'title' => $markthistopic));
            }
        }

$parentcontrols = parent::section_edit_control_items($course, $section, $onsectionpage);

        // If the edit key exists, we are going to insert our controls after it.
        if (array_key_exists("edit", $parentcontrols)) {
            $merged = array();
            // We can't use splice because we are using associative arrays.
            // Step through the array and merge the arrays.
            foreach ($parentcontrols as $key => $action) {
                $merged[$key] = $action;
                if ($key == "edit") {
                    // If we have come to the edit key, merge these controls here.
                    $merged = array_merge($merged, $controls);
                }
            }

            return $merged;
        } else {
            return array_merge($controls, $parentcontrols);
        }
    }

//mans pievienotais kursa struktuura
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//mans nepabeigts
	
public function get_section_subsection($section,$sectionnum) {
    // public function section_title($section, $course) {
        $title = get_section_name($course, $section);
        $url = course_get_url($course, $section->section, array('navigation' => true));
        if ($url) {
            $title = html_writer::link($url, $title);
        }
        return $title;
    //}
	 /* global $PAGE;
        $course = course_get_format($course)->get_course();
        $section = course_get_format($course)->get_section($section);
	  */
	  $section = $this->get_section($section);
        echo "<pre>";
		print_r($section);
		echo "</pre>";
	
		
		/*if ((string)$section->name !== '') {
            return format_string($section->name, true,
                    array('context' => context_course::instance($this->courseid)));
        } else 
		/*pielikts klaat   if ($section->section == 0) {
            return get_string('section0name', 'format_onebyone');
        } else {
            return get_string('topic').' '.$section->section;*/
		/*{
            return $this->get_default_section_name($section);	
        }*/
    }	
	
	public function display_section($course, $section, $sr, $level = 0) {
        global $PAGE;
		
        $course = course_get_format($course)->get_course();
        $section = course_get_format($course)->get_section($section);
        $context = context_course::instance($course->id);
        $contentvisible = true;
        if (!$section->uservisible || !course_get_format($course)->is_section_real_available($section)) {
            if ($section->visible && !$section->available && $section->availableinfo) {
                // Still display section but without content.
                $contentvisible = false;
            } else {
                return '';
            }
        }
		echo "Funkcija straadaa!";
        
    }
//mana fja straadaa	
public function topic_section_subsection_create($sectionnum,$course) {
global $DB;
	
	//$cm=$DB->get_records('course_sections', array('section' => $sectionnum), 'id,course,section', MUST_EXIST))
	if (!$DB->record_exists('course_sections',array('section' => $sectionnum))) 
	{$idd=$DB->insert_record('course_sections', array(
						'course' => $course->id,
						'section' => $sectionnum,
						'sequence' => ''));		
	echo " idd= ".$idd;
	
	}
		else 
		{
		echo " Sekcija jau eksistē ";
		$section = $DB->get_field('course_sections', 'id', array('section' => $sectionnum, 'course' => $course->id), MUST_EXIST);
		echo " idd= ".$section;
		}
}
public function topic_structure_start() {
	//global $PAGE;
	//$url = $PAGE->url;
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'onebyone','id'=>'content'));
	$t.= html_writer::tag('a','Close All', array('href' => '#', 'id' => 'closeAll', 'title'=>'Close All'));
	$t.='|';
	$t.= html_writer::tag('a','Open All', array('href' => '#', 'id' => 'openAll', 'title'=>'Open All'));
	return $t;
}
public function topic_part_structure_start($n) {
	if ($n==1) $partname='descriptionpart';
	if ($n==2) $partname='theoreticalpart';
	if ($n==3) $partname='practicalpart';
	if ($n==4) $partname='assessmentpart';
	//bs sakums visiem vienāds, tad tikai mainās numurs beigās
	$bs='body-section'.$n-1;
	$t = '';
	$t.= html_writer::start_tag('div', array('class' => 'page_collapsible collapse-open','id'=>$bs));
	$t.= html_writer::start_tag('span');
	$t.= html_writer::end_tag('span');
	$t.= new lang_string($partname, 'format_onebyone');
	$t.= html_writer::end_tag('div');
	$t.= html_writer::start_tag('div', array('class' => 'container1','style'=>'display: none;'));
	$t.= html_writer::start_tag('div', array('class' => 'content'));
	return $t;
}
public function topic_part_structure_end(){
	$t = '';
	$t.= html_writer::end_tag('div'); //content
	$t.= html_writer::end_tag('div'); //container1
return $t;	
}	
public function topic_structure_end() {
html_writer::end_tag('div'); //onebyone
//js piesaista
echo '
	<script type="text/javascript" src="format/onebyone/javascript/jquery.min.js"></script> 
	<script type="text/javascript" src="format/onebyone/javascript/highlight.pack.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.cookie.js"></script>
	<script type="text/javascript" src="format/onebyone/javascript/jquery.collapsible.js"></script>
	<!-- <script type="text/javascript" src="format/onebyone/javascript/jquery.doc.js"></script> -->
	<script type="text/javascript">
';
echo "
    $(document).ready(function() {

       //syntax highlighter
        hljs.tabReplace = '    ';
     hljs.initHighlightingOnLoad(); 

        $.fn.slideFadeToggle = function(speed, easing, callback) {
            return this.animate({opacity: 'toggle', height: 'toggle'}, speed, easing, callback);
        };

        //collapsible management
       
        $('.page_collapsible').collapsible({
            defaultOpen: 'body_section1',
            cookieName: 'body2',
            speed: 'slow',
            animateOpen: function (elem, opts) { //replace the standard slideUp with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            animateClose: function (elem, opts) { //replace the standard slideDown with custom function
                elem.next().slideFadeToggle(opts.speed);
            },
            loadOpen: function (elem) { //replace the standard open state with custom function
                elem.next().show();
            },
            loadClose: function (elem, opts) { //replace the close state with custom function
                elem.next().hide();
            }

        });

        //assign open/close all to functions
        function openAll() {
            $('.page_collapsible').collapsible('openAll');
        }
        function closeAll() {
            $('.page_collapsible').collapsible('closeAll');
        }

        //listen for close/open all
        $('#closeAll').click(function(event) {
            event.preventDefault();
            closeAll();
		});
		
        $('#openAll').click(function(event) {
            event.preventDefault();
            openAll();
        });

    });
</script>
<!-- /JS -->
";
}
 protected function section_header_obo($section, $course, $onsectionpage, $sectionreturn=null) {
        global $PAGE;
     
		$o = '';
        $currenttext = '';
        $sectionstyle = '';

        if ($section->section != 0) {
            // Only in the non-general sections.
            if (!$section->visible) {
                $sectionstyle = ' hidden';
            } else if (course_get_format($course)->is_section_current($section)) {
                $sectionstyle = ' current';
            }
        }

        $o.= html_writer::start_tag('li', array('id' => 'section-'.$section->section,
       'class' => 'section main clearfix'.$sectionstyle, 'role'=>'region',
            'aria-label'=> get_section_name($course, $section)));  //ir linki uz resursiem

        // Create a span that contains the section title to be used to create the keyboard section move menu.
  $o .= html_writer::tag('span', $this->section_title($section, $course), array('class' => 'hidden sectionname'));

        $leftcontent = $this->section_left_content($section, $course, $onsectionpage);
        $o.= html_writer::tag('div', $leftcontent, array('class' => 'left side'));

        $rightcontent = $this->section_right_content($section, $course, $onsectionpage);
        $o.= html_writer::tag('div', $rightcontent, array('class' => 'right side'));
        $o.= html_writer::start_tag('div', array('class' => 'content'));

        // When not on a section page, we display the section titles except the general section if null
		 $hasnamenotsecpg = (!$onsectionpage && ($section->section != 0 || !is_null($section->name)));

        // When on a section page, we only display the general section title, if title is not the default one
        $hasnamesecpg = ($onsectionpage && ($section->section == 0 && !is_null($section->name)));
/*
      $classes = ' accesshide';
        if ($hasnamenotsecpg || $hasnamesecpg) {
            $classes = '';
        }
        $sectionname = html_writer::tag('span', $this->section_title($section, $course));
        $o.= $this->output->heading($sectionname, 3, 'sectionname' . $classes);

        $o.= html_writer::start_tag('div', array('class' => 'summary'));
       $o.= $this->format_summary_text($section);
        $o.= html_writer::end_tag('div');
*/
        $context = context_course::instance($course->id);
       $o .= $this->section_availability_message($section,
               has_capability('moodle/course:viewhiddensections', $context));
	
        return $o;
    }
//---------------------------------------------------------------
public function grupas_pieskirsana(){
	global $USER;
	global $COURSE;
	global $DB;
	$userid=$USER->id;
	$courseid=$COURSE->id;
	//echo "<br>userid=".$userid;
	//echo "<br>courseid=".$courseid;
//echo "<H3>Studentiem grupu piešķiršana</H3>";

	if ($this->vai_students($courseid)==1)
	{	//siim lomaam ir tiesiibas veikt klasificeesanu (pati lielaka iekava
			//echo "<br>Students!";
//mācīšanas stila aprekinasana
$this->ls_pieskirsana();	
	
//parbaude vai kursam ir grupas
	$write=0; 
	$kursa_grupas = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
	$grupu_skaits=count($kursa_grupas);
	//echo "<br>grupu skaits= ".$grupu_skaits;
	//vai ir stils
	//vai ir mac dati
	$peddata = $DB->get_record('v_user_pedagogical_data', array('userid'=>$userid,'courseid'=>$courseid));
    $personalitydata = $DB->get_record('v_user_personality_data', array('userid'=>$userid,'property'=>'learningstyle'));
	
				if ($kursa_grupas==true && !empty($peddata) && !empty($personalitydata))
					{$write=1;//echo "<br>kursam ir grupas";
				} 
					else {$write=0;		//echo "<br>kursam nav grupu";
						}
				
		if ($write==1)
					{	//2.lielakā iekava	
					//ta ka ir grupas, tad notiks studentam grupas pieskirsana
					$aclg=array(); //pazimju vertibas
					$ald=array();
					$result=array();
					$stud=array();
			//veido aclg nem datus no clg tabulas
//echo "<br/>";
//echo "<pre>";
//print_r($kursa_grupas);
//echo "</pre>";
						$pk = $DB->get_record('v_adaptation_features', array('feature'=>'pk'));// izvelk pazīmes id
						$dl = $DB->get_record('v_adaptation_features', array('feature'=>'dl'));// izvelk pazīmes id
						$ls = $DB->get_record('v_adaptation_features', array('feature'=>'ls'));// izvelk pazīmes id
						//echo "<br>pkid= ".$pk->id;
						//echo "<br>dkid= ".$dl->id;
						//echo "<br>lsid= ".$ls->id;

//bija nepareizi id, jo tie nesakas ar 1
//reset($obj)->id;
$n=reset($kursa_grupas)->id;
//echo "<br>n= ".$n;
$p=1;		
for ($i=$n;$i<$n+$grupu_skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br>kursa_grupas->group_number= ".$kursa_grupas[$i]->group_number;//ir
			//pec grupas numura jaapanem
						//mas
						$visas_pazimes = $DB->get_records('v_clg_description', array('clgid'=>$i));// izvelk šis grupas pazīmes
						//echo "<pre>";
						//print_r($visas_pazimes);
						//echo "</pre>";
						$pazimju_skaits=count($visas_pazimes);//ir
						//echo "<br>pazimju skaits= ".$pazimju_skaits;
						$k=reset($visas_pazimes)->id;
						for($j=1;$j<=$pazimju_skaits;$j++)
						{
						//echo "<br><br>pazimes id= ".$visas_pazimes[$k]->adaptation_features_valueid;
						
						$v2 = $DB->get_record('v_adaptation_features_values', array('id'=>$visas_pazimes[$k]->adaptation_features_valueid)); //izvelk pazīmes, veertības id
						//echo "<br>featureid= ".$v2->featureid;
						//echo "<br>feature value= ".$v2->value;
						
						if ($v2->featureid==$pk->id) $aclg[$p-1][0]=$v2->value;
						if ($v2->featureid==$dl->id) $aclg[$p-1][1]=$v2->value;
						if ($v2->featureid==$ls->id) $aclg[$p-1][2]=$v2->value;
						
						$k++;}//for pa j
			$p++;
}//for lielais	aizgaja pa i

//parbaudei izvads, visu grupu pazimes
//echo "<br>aclg izvads<br>";
////echo "<pre>";
//print_r($aclg);
//echo "</pre>";
					
		//jau pasa masiiva ald aizpildiisana
			$p=0;//varbuut nevajag
$skaits=1;
$vai_dati=array();
	
//šim kursam
$pk = $DB->get_field('v_user_pedagogical_data', 'preknow', array('userid' => $userid, 'courseid' => $courseid), MUST_EXIST);
$dl = $DB->get_field('v_user_pedagogical_data', 'dlevel', array('userid' => $userid, 'courseid' => $courseid), MUST_EXIST);
$ls = $DB->get_field('v_user_personality_data', 'value', array('userid' => $userid, 'property' => 'learningstyle'), MUST_EXIST);

//echo "<br>Triju masiivu izdruka";
//echo "<br>";
//print_r($pk);echo "<br>";
//print_r($dl);echo "<br>";
//print_r($ls);echo "<br>";
$temp=array();		
			if ($pk!=NULL && $ls!=NULL && $dl!=NULL)
			{
			for ($j=0;$j<$grupu_skaits;$j++){
			$csum=0;
				if ($pk==$aclg[$j][0]) $csum++;	
				if ($dl==$aclg[$j][1]) $csum++;
				if ($ls==$aclg[$j][2]) $csum++;
			//echo "<br>csum= ".$csum." ";
			$temp[$j]=$csum;
			}
//echo "<pre>";
//print_r($temp);
//echo "<pre>";	
$result=array();		
$result=max($temp); 
//echo "<br>max($temp)".max($temp);
$m=array_search(max($temp), $temp);
//echo "<br>m".$m;
//echo "<br>result sum= ".$result[$ii]." ";
if ($result==3) {
		//ieraksta datus masiivaa clg_members
				//DB tabulas "clg_members" aizpildisana
	//vai taads user ir tabulaa
		//$rez50 = $DB->get_records_menu('v_clg_members',array('userid'=>$userid),'userid','userid,courseid');
		$sql="SELECT 
			cl.courseid, cl.group_number
		FROM
			 mdl_v_clg_members cl
		WHERE
			 cl.userid = $userid and
			 cl.courseid= $courseid";
 
$rez50 = $DB->get_records_sql($sql, null, IGNORE_MISSING);
foreach ($rez50 as $id => $courseid) {
					//echo "id= ".$courseid->group_number."<br/>";
			}//$stud[$skaits]=$student->id;

		//if (!empty($rez50)) 
		//$rez5 = $DB->get_field('v_clg_members', 'group_number', array('userid' => $userid, 'courseid' => $courseid), MUST_EXIST);
//-----------------------------	
	/*$sql="SELECT 
			cl.group_number
		FROM
			 mdl_v_clg_members cl
		WHERE
			 cl.userid = $userid AND
			 cl.courseid = $courseid";
 
$rez5 = $DB->get_records_sql($sql, null, IGNORE_MISSING);
echo "AAA";
print_r($rez5);
$results as $id => $record
var_dump((string) 1);
*/
//---------------------
//---------------------	
		//ja nav vienāds ar iegūto, tad nodzes ieprieksejo ierakstu
		if (empty($courseid->group_number))	
					{//echo "<br>User= ".$userid."piešķirta grupa= ".($m+1)." dati ierakstīti tabulā!";
						$record = new stdClass();
						$record->userid=$userid;
						$record->courseid=$courseid;
						$record->group_number=($m+1);
						$table='v_clg_members';
						$lastid=$DB->insert_record($table, $record);
						//echo "Nulllll";
				} else 
				{	
				if ($courseid->group_number!=($m+1))
										{//dzest ieprieksejo ierakstu
										$select="userid='$USER->id' and courseid='$COURSE->id'";
										$DB->delete_records_select('v_clg_members', $select); 	
										$record = new stdClass();
										$record->userid=$USER->id;
										$record->courseid=$COURSE->id;
										$record->group_number=($m+1);
										$table='v_clg_members';
										$lastid=$DB->insert_record($table, $record);
										//echo "!=====";
										}
				}
					
			
			}//result3
	
} //if visi tris ir
}//write==1
}//userrights==1
	
}
//---------------------------------------------------------------
public function ls_pieskirsana(){
global $DB;
global $USER;
$userid=$USER->id;
$courseid=$_SESSION['courseid'];

//echo "userid= ".$userid;
//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------
//definee klasi
//echo "kursa id= ".$courseid;
$testname='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
//echo "<pre>";
//print_r($res);
//echo "</pre>";
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testname;
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
		else {
			$artefacttypeid=$res[$testname];
			//echo "<br>AR= ".$artefacttypeid;
		}
//------------------------------------------------------------
				//jaizvelk  lietotaaja ls dati
				$result = $DB->get_records_menu('v_user_artefact_all',array('artefacttypeid'=>$artefacttypeid, 'userid'=>$userid),'userid','id,userid'); 
				//echo "<br>Result masiivs <pre>";
				//print_r ($result);
				//echo "</pre>";
				//$visu_skaits=sizeof($result);
				//echo "</br>";
				//$n=1;//tabulas numurs
				//foreach ($result as $key => $value) {$prev_stud=$value; break;}
		if (!empty($result))
		{//meklējam katram testam ls vertibas
		foreach ($result as $key => $value) {
		//panemt viena stila vertibas	
								
							//$user1 = $DB->get_record('user', array('id'=>$value));
							//testa nosaukums
							$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,source'); 
							//$result3 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,ctime'); 
							//testa ls vertibas
							$result4 = $DB->get_records_menu('v_user_learningstyle',array('artefactallid'=>$key),'artefactallid','lstylename,value'); 
								//echo "<pre>";
								//print_r ($result2);
								//echo "</pre>";
								//echo "<pre>";
								//print_r ($result4);
								//echo "</pre>";
								//stilu vilksana
								$ststils=array();
								$m=0; //lai saprastu, ka visi stili atrasti
								foreach ($result4 as $key4 => $value4)
										{
										if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
											{
											if ($key4=="v") 
													{$ststil['v']=$value4;}else
											
											if ($key4=="a")
													{$ststil['a']=$value4;}else
												{$ststil['r']=0;} 
											if ($key4=="k")
												{$ststil['k']=$value4;} 
											  } 
																								
										if ($result2[$key]=="vark3")
											{
											if ($key4=="v") 
													{
													$ststil['v']=$value4;}else
											if ($key4=="a")
													{
													$ststil['a']=$value4;}else
											if ($key4=="r")
													{
													$ststil['r']=$value4;}else
											if ($key4=="k")
													{
													$ststil['k']=$value4;}
											$m++;
											}
									}//foreach result4 				
											if ($m>0)	{		
														//jasaliek vajadzīgajā secība cita masiivā K, A, V, R
														$ststils=array();//prioritate studenta stils
														$ststils['k']=$ststil['k'];
														$ststils['a']=$ststil['a'];
														$ststils['v']=$ststil['v'];
														$ststils['r']=$ststil['r'];
														
														//------------------------------------
														//izvads
														//echo "<br>k= ".$ststils['k'];
														//echo "<br>a= ".$ststils['a'];
														//echo "<br>v= ".$ststils['v'];
														//echo "<br>r= ".$ststils['r'];
													//max pa rindinu
														$maxst=array_search(max($ststils),$ststils); //max stils
														
														//echo "<br>maxst= ".$maxst;
														if ($maxst=='k' && (
															$ststils['k']==$ststils['v'] || 
															$ststils['k']==$ststils['a'] ||
															$ststils['k']==$ststils['r'] || 
															$ststils['k']==$ststils['a'] && $ststils['k']==$ststils['v'])) 
															$stils='k';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['r']) )
															$stils='a';	
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v'] && $ststils['v']==$ststils['r']))
															$stils='va';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v']) )
															$stils='va';	
															else
														if ($maxst=='v' && (
															$ststils['v']==$ststils['r']) )
															$stils='v';
															else $stils=$maxst;
														
														
														}
													
													 
											
								//if ($result2[$key]=="vark3") echo "<td>".$stils."</td>"; else 	echo "<td>"." "."</td>";
															//izvilkt personisko inf
							//jaņem atbilstosam kursam vel 
								
								$result5 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value,'courseid'=>$courseid),'userid','userid,preknow');
								$result6 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value, 'courseid'=>$courseid),'userid','userid,dlevel');
								//if (!empty($result5))echo "<td>".$result5[$value]."</td>"; else echo "<td>".''."</td>";
								//if (!empty($result6))echo "<td>".$result6[$value]."</td>"; else echo "<td>".''."</td>";
								//echo "</tr>";				
							
								
								//aizpilda tabulu v_user_personality_data, ja lietotaaja nav			
								$user_ir = $DB->get_records_menu('v_user_personality_data', array('userid'=>$userid,'property'=>'learningstyle'),'userid','userid,value');
								
								
								//$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,source'); 
					
										//if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
								
								
								
							//	echo "A=".$user_ir[$userid];
							
								if ($user_ir==true and $user_ir[$userid]!=$stils)
										{//dzest ieprieksejo ierakstu
										$table = 'v_user_personality_data';
										$select="userid='$USER->id' and property='learningstyle'";
										$DB->delete_records_select($table, $select); 
										$ls='learningstyle';
												$record7 = new stdClass();
												$record7->userid=$value;
												$record7->property=$ls;
												$record7->value=$stils;
												$table='v_user_personality_data';
												$lastid=$DB->insert_record($table, $record7);
										}	
								
										if (empty($user_ir)){
												
												$ls='learningstyle';
												$record7 = new stdClass();
												$record7->userid=$value;
												$record7->property=$ls;
												$record7->value=$stils;
												$table='v_user_personality_data';
												$lastid=$DB->insert_record($table, $record7);
												//if ($stils=="k") echo "<br><b>Jums tika piešķirts mācīšanās stils kinestētiskais!</b>";
												//if ($stils=="v") echo "<br><b>Jums tika piešķirts mācīšanās stils vizuālais!</b>";
												//if ($stils=="r") echo "<br><b>Jums tika piešķirts mācīšanās stils lasīšanas!</b>";
												//if ($stils=="a") echo "<br><b>Jums tika piešķirts mācīšanās stils audiālais!</b>";
												//if ($stils=="va") echo "<br><b>Jums tika piešķirts mācīšanās stils vizuālais un audialais!</b>";												
											} //false  	
						
	//echo "<br>userid=".$value;
	//echo "<br>ls=".$ls;

} //foreach result

		}//if not empty
		else {
			//ja students
			//if ($this->vai_students($courseid)==1) echo "<br>Jūs neesat pildījis testēšanu!";
			
		}

//else echo "Jums nav tiesību veikt šo darbību!";
}


public function resursi_aktivitaates_vienai_sekcijai($course, $thissection ,$sectionnum, $mods, $modnames, $modnamesused) {
     		global $PAGE;
        $modinfo = get_fast_modinfo($course);
        $course = course_get_format($course)->get_course();
        $context = context_course::instance($course->id);
        // Title with completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
        echo $this->output->heading($this->page_title(), 2, 'accesshide');

        // Now the list of sections..
        echo $this->start_section_list();
//echo "<pre>";
//print_r($modinfo->get_section_info_all());
//echo "<pre>";

        foreach ($modinfo->get_section_info_all() as $section => $thissection) {
            if ($section==$sectionnum)
{			
            $showsection = $thissection->uservisible ||
                    ($thissection->visible && !$thissection->available && !empty($thissection->availableinfo));
            if (!$showsection) {
                // If the hiddensections option is set to 'show hidden sections in collapsed
                // form', then display the hidden section message - UNLESS the section is
                // hidden by the availability system, which is set to hide the reason.
                if (!$course->hiddensections && $thissection->available) {
                    echo $this->section_hidden($section, $course->id);//nav pieejama
                }

                continue;
            }
		//rezīms, kad nav ieslēgts labošanas rezīms
            if (!$PAGE->user_is_editing() ) {
      				echo $this->section_header_obo($thissection, $course, false, 0);
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);

                    echo $this->courserenderer->course_section_add_cm_control($course, 0, 0);
                    echo $this->section_footer();
					} else {
			//ieslēgts labosanas rezīms
                echo $this->section_header_obo($thissection, $course, false, 0);
                if ($thissection->uservisible) {
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
                    //echo $this->courserenderer->course_section_add_cm_control($course, $section, 0);
					//echo $this->courserenderer->course_section_cm_list($course, $sectionnum, 0);//resursus rāda
                    
					echo $this->courserenderer->course_section_add_cm_control($course, $section, 0);//tekstu rāda, kastītes kur izvelas resursus rāda
                }
                echo $this->section_footer();
            }
    } //if beidzas 	
		}//beidzas cikls

        if ($PAGE->user_is_editing() and has_capability('moodle/course:update', $context)) {
						echo $this->end_section_list();
		}
} //fja

//#########################################################################		
public function sekcijas_saturs($courseid, $section){
	global $USER, $DB;
	$userid=$USER->id;
// studenta ls un dl
$rezls = $DB->get_records_menu('v_user_personality_data',array('userid'=>$userid,'property'=>'learningstyle'),'userid','userid,value');
$rezdl= $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$userid,'courseid'=>$courseid),'userid','userid,dlevel');
$rezpk= $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$userid,'courseid'=>$courseid),'userid','userid,preknow');
//echo "<pre>";
//print_r($rez2);
//echo "</pre>";
if (!empty($rezls && $rezdl)){
	$ls=$rezls[$userid];
	$dl=$rezdl[$userid];
	$pk=$rezpk[$userid];
	if ($ls=='va') $ls='w';
	//echo "<br>ls= ".$ls." dl=".$dl;
	//echo "sekcijas numurs=". $section;
	$i=1;
	do {
		$sectionnum=$section.'0'.$i;
		$rez = $DB->get_records_menu('course_sections',array('section'=>$sectionnum, 'course'=>$courseid),'id','section,sequence'); 
		//echo "<pre>";
		//print_r($rez);
		//echo "</pre>";
		//echo "<br>sekcija ".$sectionnum." elementi= ".$rez[$sectionnum];
		//$s=$rez[$sectionnum];
		//$skaits=substr_count($rez[$sectionnum],',')+1;
		$elementi = explode(",", $rez[$sectionnum]);
		$skaits=sizeof($elementi);
		//echo "<br>elementu skaits ".$skaits;
		if (!empty($rez[$sectionnum]))
		{//echo "<br>elementi ir ";
		for($k=0;$k<$skaits;$k++){
			//echo "<br>elements= ".$elementi[$k];//ja der, jāņem ciklā
			$rez2 = $DB->get_records_menu('course_modules',array('id'=>$elementi[$k], 'course'=>$courseid),'id','id,instance'); 
			$rez3 = $DB->get_records_menu('course_modules',array('id'=>$elementi[$k], 'course'=>$courseid),'id','id,module');
			$instance=$rez2[$elementi[$k]];
			$module=$rez3[$elementi[$k]];
			
			//echo "<br> instance ".$instance;
			//echo " veids ".$module;
			//echo " dl=".$dl;
			
			$resurss='';
			if ($module==17) $resurss = $DB->get_records_menu('resource',array('id'=>$instance),'id','id,name');
			if ($module==16) $resurss = $DB->get_records_menu('quiz',array('id'=>$instance),'id','id,name');
			if ($module==1) $resurss = $DB->get_records_menu('assign',array('id'=>$instance),'id','id,name');
			if ($module==15) $resurss = $DB->get_records_menu('page',array('id'=>$instance),'id','id,name');
			if ($module==20) $resurss = $DB->get_records_menu('url',array('id'=>$instance),'id','id,name');
 			if (!empty($resurss)){
							//echo " name ".$resurss[$instance];
							$name=$resurss[$instance];
							$burts=substr($name,0,1);
							//echo " burts ".$burts;
				
															
							//if ((($i==2 && $module==17)||($i==3 && $module==2) || ($i==4 && $module==16)) && ($burts!=$dl))
						
							if ( ($module==1 && $burts==$dl)  ||
								 ($module==16 && $burts==$dl) || 
								 ($module==15 && $burts==$pk) ||
								 ($module==17 && $burts==$ls) || 
								 ($module==20 && $burts==$ls) ||			  
								 ($module==1 && $burts=='*')  || 
								 ($module==15 && $burts=='*') || 
								 ($module==16 && $burts=='*') ||
								 ($module==17 &&  $burts=='*') ||
								 ($module==20 && $burts=='*') 
								 )
							$v=1; else $v=0;
							//echo "<br> v ".$v;
							
							//echo "<pre>";
							//print_r($elementi[$k]);
							//echo "</pre>";
							
								set_coursemodule_visible($elementi[$k], $v);
								$DB->set_field('course_modules', 'visibleold', 1, array('id' => $elementi[$k]));	
							}//if not empty resurss
			
		}//for
		}//if skaits
		$i++;
}while ($i<=4);//do, ja būs trīs daļas varbūt problemas
}//if ja studenta paziimes ir
}//fja

public function vai_students($courseid){
 global $DB, $CFG, $USER;

  $userid=$USER->id;
			//pēc userid panem lomu, kas ir registreeti kursaa
$course_context_id = $DB->get_records_menu('context',array('instanceid'=>$courseid,'contextlevel'=>CONTEXT_COURSE),'id','instanceid,id'); 

$cci=$course_context_id[$courseid];

//----------------------------------------1. studenta lomas id meklesana
$rez1=array();
$s1='student';		
$rez1 = $DB->get_records_menu('role',array('shortname'=>$s1),'id','shortname,id'); 
		$studentrole=$rez1[$s1];
//echo "<br/>student lomaid= ".$studentrole;		
			// no tabulas role_assignments
$sql="SELECT
			ra.id,
			ra.roleid,
			ra.contextid
			FROM
				 mdl_role_assignments ra
			WHERE
			ra.userid = '$userid'
			 ORDER BY ra.contextid";
			
$results = $DB->get_records_sql($sql, null, IGNORE_MISSING);
		$z=0;
		foreach ($results as $id => $record) {
							//echo "<br>id= ".$record->id;
							//echo "<br>contextid= ".$record->contextid;
							$userrol=$record->roleid;
							if ($record->contextid==$cci) { $z=1; break;}
							}	
//echo "<br>userrole=".$userrol;
		
//-----------------------------ja loma ir students, tad viss parējais
if ($userrol==$studentrole) return 1; else return 0;
}
public function print_multiple_section_page_obo($course, $s, $mods, $modnames, $modnamesused) {
        global $PAGE;
		 
				//echo "<pre>";
//print_r($s);
//echo "</pre>";
		//$tsection=$topsection.'01';
        $modinfo = get_fast_modinfo($course);
        $course = course_get_format($course)->get_course();

        $context = context_course::instance($course->id);
        // Title with completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
        echo $this->output->heading($this->page_title(), 2, 'accesshide');

        // Copy activity clipboard..
        echo $this->course_activity_clipboard($course, 0);

        // Now the list of sections..
        echo $this->start_section_list();
//echo "<pre>";
//print_r($modinfo->get_section_info_all());
//echo "<pre>";

        foreach ($modinfo->get_section_info_all() as $section => $thissection) {
            if ($section>=101 && $section<=104)
{			echo "<br/>Section= ".$section;
			echo "<br/>ThisSection= ";
			echo($thissection->section);
			if ($section == 0) {
                // 0-section is displayed a little different then the others
                if ($thissection->summary or !empty($modinfo->sections[0]) or $PAGE->user_is_editing()) {
                    echo $this->section_header($thissection, $course, false, 0);
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
                    echo $this->courserenderer->course_section_add_cm_control($course, 0, 0);
                    echo $this->section_footer();
                }
                continue;
            }
            /*if ($section > $course->numsections) {
                // activities inside this section are 'orphaned', this section will be printed as 'stealth' below
                continue;
            }*/
            // Show the section if the user is permitted to access it, OR if it's not available
            // but there is some available info text which explains the reason & should display.
         
		 $showsection = $thissection->uservisible ||
                    ($thissection->visible && !$thissection->available && !empty($thissection->availableinfo));
            if (!$showsection) {
                // If the hiddensections option is set to 'show hidden sections in collapsed
                // form', then display the hidden section message - UNLESS the section is
                // hidden by the availability system, which is set to hide the reason.
                if (!$course->hiddensections && $thissection->available) {
                    echo $this->section_hidden($section, $course->id);//nav pieejama
                }

                continue;
            }
			
            if (!$PAGE->user_is_editing() ) {
                // Display section summary only.
                //echo $this->section_summary($thissection, $course, null);
            } else {
                echo $this->section_header_obo($thissection, $course, false, 0);
                if ($thissection->uservisible) {
                    echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
                    echo $this->courserenderer->course_section_add_cm_control($course, $section, 0);
                }
                echo $this->section_footer();
            }
    } //if beidzas    
		}//beidzas cikls

        if ($PAGE->user_is_editing() and has_capability('moodle/course:update', $context)) {
            // Print stealth sections if present.
            foreach ($modinfo->get_section_info_all() as $section => $thissection) {
                if ($section>=101 && $section<=104)
				{
				if ($section <= $course->numsections or empty($modinfo->sections[$section])) {
                    // this is not stealth section or it is empty
                    continue;
                }
                echo $this->stealth_section_header($section);
                echo $this->courserenderer->course_section_cm_list($course, $thissection, 0);
                echo $this->stealth_section_footer();
           }
		}//cikls
            echo $this->end_section_list();

            echo html_writer::start_tag('div', array('id' => 'changenumsections', 'class' => 'mdl-right'));

            // Increase number of sections.
            $straddsection = get_string('increasesections', 'moodle');
            $url = new moodle_url('/course/changenumsections.php',
                array('courseid' => $course->id,
                      'increase' => true,
                      'sesskey' => sesskey()));
            $icon = $this->output->pix_icon('t/switch_plus', $straddsection);
            echo html_writer::link($url, $icon.get_accesshide($straddsection), array('class' => 'increase-sections'));

            if ($course->numsections > 0) {
                // Reduce number of sections sections.
                $strremovesection = get_string('reducesections', 'moodle');
                $url = new moodle_url('/course/changenumsections.php',
                    array('courseid' => $course->id,
                          'increase' => false,
                          'sesskey' => sesskey()));
                $icon = $this->output->pix_icon('t/switch_minus', $strremovesection);
                echo html_writer::link($url, $icon.get_accesshide($strremovesection), array('class' => 'reduce-sections'));
            }

            echo html_writer::end_tag('div');
        } else {
            echo $this->end_section_list();
        }

    }
//========================================================================================================================
public function print_single_section_page_obo($course, $sections, $mods, $modnames, $modnamesused, $displaysection) {
        global $CFG, $OUTPUT;
		global $USER, $DB;
		global $SESSION, $PAGE;
	
		//if (!$PAGE->user_allowed_editing())
	//$displaysection = 1; else
		$_SESSION['displaysection']=$displaysection;
	
$tmminstanceid=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
//$block_ir = $DB->get_records_menu('context',array('instanceid'=>$tmminstanceid),'id','instanceid,id'); 
		if ($tmminstanceid==0) echo "<br>Kursam ir jāpievieno tēmu vadības bloks"; 
			else {//echo "<br>Bloks ir"; echo " Bloka id= ".$tmminstanceid;
												
			$blockinstance= new block_tmm();
			$ld=0;
			$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
			
			
			if ($blockinstance->user_rights()==0)
				{
			if (empty($lerndata)){
			$ld=1;
			echo "<h5>E-kursa lietošanas pamācība (tiek rādīta tikai vienreiz)</h5>";
			echo "Pirms sākt kursa apguvi, lūdzu izpildiet testus <b>blokā \"Learning Data\"</b> kreisajā pusē. <br/><b>Obligātie testi ir \"Course Data\" un \"VARK3\"</b>.
			<br><br>Sākot apmācību, varat izvēlēties tēmu secību, t.i., kā sistēmai piedāvāt nākamo apgūstāmo tēmu:
			<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Skolotāja tēmu secībā</b> tēmas tiek parādītas pēc kārtas.
			<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Studenta tēmu secība</b> tiek veidota, balstoties uz saitēm starp tēmām.
			<br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Optimālā tēmu secība</b> tika izveidota, balstoties uz iepriekšējo apmācāmo rezultātiem.
			<br><br>Nākamā tēma tiek piedāvāta tikai tad, <b>ja testā iegūta atzīme ir vismaz 4 un esat pārgājuši uz pēdējo apgūto tēmu</b>. 
			<br>Pa apgūtām tēmām var brīvi pārvietoties!
			<br>Pēc visu tēmu apguves, pārejot uz pēdējo apgūto tēmu, parādīsies kursā iegūtā atzīme. Tad kurss skaitās apgūts!
			<br>Pēc kursa apguves, lūdzu aizpildiet <b>e-kursa novērtēšanas anketu \"Course Evaluation\"</b>!
			";
			}
			else 
			{$ped_tema=$blockinstance->pedeja_apguta_tema();
				echo "<font face='verdana' color='#cc002d'><b>Lai turpinātu, "; 
			//echo "pārejiet uz pēdējo apgūto/izvēlēto tēmu (saite)!</a></b>"; 
			echo "<a href=".$CFG->wwwroot."/course/view.php?id=".$course->id."&section=".$ped_tema.">pārejiet uz pēdējo apgūto/izvēlēto tēmu</a> (saite)!</b>";
			}
			echo "<br>Ja testā ir iegūta atzīme 4 vai vairāk un esat pārgājis uz pēdējo apgūto tēmu, tad parādīsies atzīme par testu un varēs izvēlēties nākamā apgūstamo tēmu!</font>";
		//echo "<br>Pāreja uz pedējo apgūto temu";
				//echo "<br/><a href=".$CFG->wwwroot."/course/view.php?id=52&section=8>Pāriet uz Pēdējo apgūto tēmu:</a>"; 
				//".$blockinstance->pedeja_apguta_tema()."kursa id= ";//.course->id;
				//<a href="'.$CFG->wwwroot.'/course/view.php?id=52&section=8">Create OTS</a>'
				//$urltogo= $CFG->wwwroot.'course/view.php?id=52&section=1';
				//$CFG->loginredir = $CFG->wwwroot.'course/view.php?id=52'.'&'.'section=5';
				//$PAGE->set_url($CFG->wwwroot.'course/view.php?id=52&section=1');
				//$PAGE->set_url("$CFG->wwwroot.'/course/view.php?id=52'.'&amp;'.'section=8'");
				//$PAGE->set_url("$CFG->httpswwwroot/login/index.php");
				 //$urltogo = $CFG->wwwroot.'/course/view.php?id=52&section=8';//.'&amp;'.'section=8';
				//unset($SESSION->wantsurl);
				//redirect($urltogo);
				

				
				
				
				
				
				if ($blockinstance->tsecibas_variants_pedejais()==2 && $blockinstance->vai_si_tema_ierakstiita($displaysection)==0)
					{$blockinstance->write_topic_sequence($displaysection);	
					}
				//echo "<br>displaysection=".$displaysection;	
				//ja atrodos vajadziibaa teemā
				if ($displaysection==$blockinstance->last_recorded_topic())
				{//taa ir ista vieta
				$m=0;
				
				if ($blockinstance->was_quizattempt($displaysection)==1 && $blockinstance->show_topic_list($displaysection)==0)
					{//dzest meginajumu
					$blockinstance->dzest_meginajumu($displaysection);
					echo "<br><b>Tests nav iziets! Pamācieties un mēģiniet vēlreiz!</b>";
					}
				
				if ($blockinstance->was_quizattempt($displaysection)==1 && $blockinstance->show_topic_list($displaysection)==1)
							{//showtopic ieraksta atziimi
							$blockinstance->write_topic_grade($displaysection);
							$m=1;
							//$nak_temas=$blockinstance->next_topic();
							
							if ($blockinstance->ierakstito_temu_skaits()!=$blockinstance->course_allsections_number())
													$blockinstance->write_topic_sequence($displaysection); 
													else {
																		//write kursa gala atziimi
																		$blockinstance->kursa_atzimes_saglabasana();
																		//temu seciiba jaieraksta cita tabula
																		$blockinstance->datu_ierakstisana_cts();
																		
																		}
							
							}//show topic list
				
				if ($blockinstance->tsecibas_variants_pedejais()==1 or $blockinstance->tsecibas_variants_pedejais()==3)
							{$sections=$blockinstance->ierakstito_temu_seciba();}
				if ($blockinstance->tsecibas_variants_pedejais()==2 && $m==1) 
							{$sections=$blockinstance->temas_apgutas_plus_saites();}//variants 2
				if ($blockinstance->tsecibas_variants_pedejais()==2 && $m==0) 
							{$sections=$blockinstance->ierakstito_temu_seciba();}//variants 2
				}	
				else 
								$sections=$blockinstance->ierakstito_temu_seciba();
						
				//ja veel jaapguust teemas 
				//echo "Izvēlieties tēmu:";
				//if ()
						if ($ld==0){
						$sectionbottomnav = '';
						$sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
						//$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
						//$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
						//pareja uz jebkuru temu
						//$sectionbottomnav .="Izvēlieties tēmu:";
						
						$sectionbottomnav .= html_writer::tag('div', "Choose topic:",array('class' => 'mdl-align'));
						$sectionbottomnav .= html_writer::tag('div',$this->section_nav_selection_obo($course, $sections, $displaysection),
							array('class' => 'mdl-align'));
						$sectionbottomnav .= html_writer::end_tag('div');
						echo $sectionbottomnav;
						}
							
			//----------------------------------------------
			echo "<h5>Dati par apmācības procesu:</h5>";
			echo "Kurss sastāv no ".$blockinstance->course_allsections_number()." tēmām. ";
			echo " No tām apgūtas ir ".$blockinstance->ierakstito_atzimju_skaits()." tēmas.<br><b> Tēmas: ".$blockinstance->ierakstito_temu_seciba()."<br>Atzīmes: ".$blockinstance->ierakstito_atzimju_seciba()."</b>";
			//echo "<h5>Learning process data:</h5>";
			//echo "Course consists of ".$blockinstance->course_allsections_number()." topics. ";
			//echo $blockinstance->ierakstito_atzimju_skaits()." topics are completed.<br><b> Topics: ".$blockinstance->ierakstito_temu_seciba()."<br>Grades: ".$blockinstance->ierakstito_atzimju_seciba()."</b>";
			if ($blockinstance->ierakstito_atzimju_skaits()==$blockinstance->course_allsections_number())
			echo "<br><b>Kursa galīgais vērtējums = ".round($blockinstance->kursa_kopeja_atzimi(),2).'</b>';
			
			
		}//tiesiibas students	
		else {
			$modinfo = get_fast_modinfo($course);
			 $sectionnavlinks = $this->get_nav_links($course, $modinfo->get_section_info_all(), $displaysection);
			$sectionbottomnav = '';
						$sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
						$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
						$sectionbottomnav .="<br>";
						$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
						//pareja uz jebkuru temu
						$sectionbottomnav .= html_writer::tag('div', $this->section_nav_selection_obo($course, $sections, $displaysection),
							array('class' => 'mdl-align'));
						$sectionbottomnav .= html_writer::end_tag('div');
						echo $sectionbottomnav;
		}//teacher
		$blockinstance->general();			
}//ja bija bloks
		//-------------------------------------------------
	
		//kursa options update notiek automatiski

		
	     $modinfo = get_fast_modinfo($course);
		/*echo "<pre>";
		print_r($modinfo);//taja ir visas sekcijas
		echo "</pre>";*/
		
        $course = course_get_format($course)->get_course();
		/*echo "<pre>";
		print_r($course);//kursa parametri
		echo "</pre>";*/
//ka tikt pie practpart no kursa parametriem		
//$courseid = required_param('courseid', PARAM_INT);
//$increase = optional_param('increase', true, PARAM_BOOL);
//$course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);

//par course_get_format funkcijas apkopojums
		//course_get_format($course)->is_section_real_available($section)
		//$course = course_get_format($course)->get_course();
        //$section = course_get_format($course)->get_section($section);
		//course_get_format($course)->get_format();
		
$courseformatoptions = course_get_format($course)->get_format_options();
//echo "<br/>Practpart= ".$courseformatoptions['practpart'];
//echo "<br/>Course Display= ".$courseformatoptions['coursedisplay'];
$practicalpart=$courseformatoptions['practpart'];
/*$PAGE->set_url('/course/changenumsections.php', array('courseid' => $courseid));

// Authorisation checks.
require_login($course);
require_capability('moodle/course:update', context_course::instance($course->id));
require_sesskey();

if (isset($courseformatoptions['numsections'])) {
    if ($increase) {
        // Add an additional section.
        $courseformatoptions['numsections']++;
    } else {
        // Remove a section.
        $courseformatoptions['numsections']--;
    }*/
//------------------------------------------------------
//==========================================  24.02.2017

$this->grupas_pieskirsana();
//ja students
if ($this->vai_students($course->id)==1){
$this->sekcijas_saturs($courseid,$displaysection);	
}
				
//=============================================================	
		
        // Can we view the section in question?
        if (!($sectioninfo = $modinfo->get_section_info($displaysection))) {
            // This section doesn't exist
            print_error('unknowncoursesection', 'error', null, $course->fullname);
            return;
        }

        if (!$sectioninfo->uservisible) {
            if (!$course->hiddensections) {
                echo $this->start_section_list();
                echo $this->section_hidden($displaysection, $course->id);
                echo $this->end_section_list();
            }
            // Can't view this section.
            return;
        }

        // Copy activity clipboard..
        echo $this->course_activity_clipboard($course,$displaysection);
        $thissection = $modinfo->get_section_info(0);
        if ($thissection->summary or !empty($modinfo->sections[0]) or $PAGE->user_is_editing()) {
   			echo $this->start_section_list();
            echo $this->section_header($thissection, $course, true, $displaysection);
            echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
			
            echo $this->courserenderer->course_section_add_cm_control($course, 0, $displaysection);
            echo $this->section_footer();
            echo $this->end_section_list();
        }

//------------------------------------
//izvads apakšsekciju
//18.12.2015
$course = course_get_format($course)->get_course();
//ta griežas pie lib funkcijas
       //$tet = course_get_format($course)->get_section_all_subsection($displaysection);
//$sections = $course_modinfo->get_section_info_all(); // array of course_module ids for each section
//$current_course_module_ids = $sections[$current_section->section];
		//echo "<pre>";
		//print_r($current_course_module_ids);
	//echo "</pre>";
//1. visas sekcijas paraada
$course_modinfo = get_fast_modinfo($course); 
$sections = $course_modinfo->get_section_info_all();
//echo "<pre>";
//		print_r($sections);
//	echo "</pre>";
//2.veids
//exit(print_object($course_modinfo->get_sections()));
//3.veids
//exit(print_object($course_modinfo->get_section_info_all()));
//4.veids
//$sections = $course_modinfo->get_section_info_all(); // array of course_module ids for each section
//$current_course_module_ids = $sections[$current_section->section];
//-------------------------------------		
		

        // Start single-section div
        echo html_writer::start_tag('div', array('class' => 'single-section'));

        // The requested section page.
        $thissection = $modinfo->get_section_info($displaysection);

        // Title with section navigation links.
        $sectionnavlinks = $this->get_nav_links($course, $modinfo->get_section_info_all(), $displaysection);
        $sectiontitle = '';
        //$sectiontitle .= html_writer::start_tag('div', array('class' => 'section-navigation navigationtitle'));
        //$sectiontitle .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
       // $sectiontitle .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
        // Title attributes
        $classes = 'sectionname';
        if (!$thissection->visible) {
            $classes .= ' dimmed_text';
        }
		$sectionname = html_writer::tag('span', get_section_name($course, $displaysection));
        $sectiontitle .= $this->output->heading($sectionname, 3, $classes);
        //tas bija un stardaja$sectiontitle .= $this->output->heading(get_section_name($course, $displaysection), 3, $classes);
        $sectiontitle .= html_writer::end_tag('div');
        //temas galvenai virsrakts
		echo $sectiontitle; //raada tēmas virsrakstu
//////////////////////////////////////////////////////////////////////////////
//edit poga temai, summarai inf
		$o = '';
        $o = $this->output->spacer();//nezinu kam tas varbūt section action menu?
		
        $controls = $this->section_edit_control_items($course, $thissection, $displaysection);
        $o .= $this->section_edit_control_menu($controls, $course, $thissection);
		//$o .= $this->section_right_content($thissection, $course, $displaysection);
		
      echo $o;

        // Now the list of sections..
          echo $this->start_section_list();
        
		//edit poga sekcijai ta ir kopā ar summary
		//echo $this->section_header($thissection, $course, true, $displaysection);
 
		// Show completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////
// teemai veido 4 sekcijas izveidotais numurs + 01/02/03/04
		//25.12.2015
	//$this->print_multiple_section_page_obo($course, $thissection, null, null, null);

//$course, $sections, $mods, $modnames, $modnamesused

//echo "AAAAAAAAAAA";
//tas straaadaaja
/* kaa paraugs echo $this->start_section_list();

        echo $this->section_header($thissection, $course, true, $displaysection);
        // Show completion help icon.
        $completioninfo = new completion_info($course);
        echo $completioninfo->display_help_icon();

        echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
        echo $this->courserenderer->course_section_add_cm_control($course, $displaysection, $displaysection);
        echo $this->section_footer();
        echo $this->end_section_list();

*/
	echo $this->topic_structure_start();
		$i=1;
	do {
		$o='';
		$sectionnumber = $thissection->section;
		$sectionnum=$sectionnumber.'0'.$i;
		course_create_sections_if_missing($course, $sectionnum);
		echo $this->topic_part_structure_start($i);
		//saturs
		//echo "Sectionnum= ".$sectionnum;
		if ($i==1)
			{if ($thissection->summary) {$summary=$thissection->summary;} else $summary='';
			$o.=$summary;}
		else 
			{
			/*$o.=$this->start_section_list();
			$o.=$this->section_header_obo($sectionnum, $course, true, $displaysection);
			$o.=$this->courserenderer->course_section_cm_list($course, $sectionnum, $displaysection);
			$o.=$this->courserenderer->course_section_add_cm_control($course, $sectionnum, $displaysection);
			//$o.=$this->section_footer();
        $o.=$this->end_section_list();*/
	
		$this->resursi_aktivitaates_vienai_sekcijai($course, $thissection,$sectionnum, null, null, null);
		//faili neiet	
			
			}
		echo $o;
		echo $this->topic_part_structure_end();
		if ($i==2 && $practicalpart==0) $i=$i+1;
		$i=$i+1;	
		} while ($i<=4);
			
		echo $this->topic_structure_end();
	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //so rindinu ieliku savaa dalā tā ir par visiem tēmā saliktajiem resursiem 
		//echo $this->courserenderer->course_section_cm_list($course, $thissection, $displaysection);
        //raada pievienot resursus tekstu
		//echo $this->courserenderer->course_section_add_cm_control($course, $displaysection, $displaysection);
        
		//echo $this->section_footer();
		//tajā bija 
		/*
		$o = html_writer::end_tag('div');
        $o.= html_writer::end_tag('li');
		
        echo $this->end_section_list();
		
		//mans izvads testa
		echo "<br>Testa izvads";
		echo "<pre>";
		print_r($course);
		echo "</pre>";
		echo "<pre>";
		print_r($sections);
		echo "</pre>";
		echo "<pre>";
		print_r($displaysection);
		echo "</pre>";*/
	
		//varbuut te nevajag
	/*
		global $DB;
		$tmminstanceid=$_SESSION['tmminstance'];
		$block_ir = $DB->get_records_menu('context',array('instanceid'=>$tmminstanceid),'id','instanceid,id'); 
		if (empty($block_ir)) echo "<br>Kursam ir jāpievieno tēmu vadības bloks"; 
			else 
			{//echo "<br>Bloks ir"; 
			//echo " Bloka id= ".$tmminstanceid;
			$blockinstance= new block_tmm();
			if ($blockinstance->user_rights()==1)
				{//izvads bez izmainamm
							// Display section bottom navigation.
					$sectionbottomnav = '';
					$sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
					$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
					$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
					//pareja uz jebkuru temu
					$sectionbottomnav .= html_writer::tag('div', $this->section_nav_selection($course, $sections, $displaysection),
						array('class' => 'mdl-align'));
					$sectionbottomnav .= html_writer::end_tag('div');
					echo $sectionbottomnav;
					// Close single-section div.
					echo html_writer::end_tag('div');
				}//ja admin
				else{
				//students
				//ja displaysection ir atsķirīgs no ierakstittajaam to ieraksta
				//vai ieraksttiit temu seciibu
				
				//ja atrodos vajadziibaa teemā
				if ($displaysection==$blockinstance->last_recorded_topic())
				{//taa ir ista vieta
				$m=0;
				
				if ($blockinstance->was_quizattempt($displaysection)==1 && $blockinstance->show_topic_list($displaysection)==1)
							{
							$m=1;
							}//show topic list
				if ($blockinstance->tsecibas_variants_pedejais()==1 or $blockinstance->tsecibas_variants_pedejais()==3)
							{$sections=$blockinstance->ierakstito_temu_seciba();}
				if ($blockinstance->tsecibas_variants_pedejais()==2 && $m==1) 
							{$sections=$blockinstance->temas_apgutas_plus_saites();}//variants 2
				if ($blockinstance->tsecibas_variants_pedejais()==2 && $m==0) 
							{$sections=$blockinstance->ierakstito_temu_seciba();}//variants 2
				}	//taa ir ista vieta
				else 
								$sections=$blockinstance->ierakstito_temu_seciba();
				//------------------------------------
						// Display section bottom navigation.
						//{
						$sectionbottomnav = '';
						$sectionbottomnav .= html_writer::start_tag('div', array('class' => 'section-navigation mdl-bottom'));
						//$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['previous'], array('class' => 'mdl-left'));
						//$sectionbottomnav .= html_writer::tag('span', $sectionnavlinks['next'], array('class' => 'mdl-right'));
						//pareja uz jebkuru temu
						$sectionbottomnav .= html_writer::tag('div', $this->section_nav_selection_obo($course, $sections, $displaysection),
							array('class' => 'mdl-align'));
						$sectionbottomnav .= html_writer::end_tag('div');
						echo $sectionbottomnav;
						
						// Close single-section div.
						
						echo html_writer::end_tag('div');
						
				}//ja students
				}//bloks
	
*/
	}//fja
	  /**
     * Renders HTML for the menus to add activities and resources to the current course
     *
     * Note, if theme overwrites this function and it does not use modchooser,
     * see also {@link core_course_renderer::add_modchoosertoggle()}
     *
     * @param stdClass $course
     * @param int $section relative section number (field course_sections.section)
     * @param int $sectionreturn The section to link back to
     * @param array $displayoptions additional display options, for example blocks add
     *     option 'inblock' => true, suggesting to display controls vertically
     * @return string
     */
//-----------------------------------------
//29.01.2017
/*
public   function course_section_add_cm_control_v($course, $section, $sectionreturn = null, $displayoptions = array()) {
        global $CFG;

        $vertical = !empty($displayoptions['inblock']);

        // check to see if user can add menus and there are modules to add
        if (!has_capability('moodle/course:manageactivities', context_course::instance($course->id))
                || !$this->page->user_is_editing()
                || !($modnames = get_module_types_names()) || empty($modnames)) {
            return '';
        }

        // Retrieve all modules with associated metadata
        $modules = get_module_metadata($course, $modnames, $sectionreturn);
        $urlparams = array('section' => $section);

        // We'll sort resources and activities into two lists
        $activities = array(MOD_CLASS_ACTIVITY => array(), MOD_CLASS_RESOURCE => array());

        foreach ($modules as $module) {
            $activityclass = MOD_CLASS_ACTIVITY;
            if ($module->archetype == MOD_ARCHETYPE_RESOURCE) {
                $activityclass = MOD_CLASS_RESOURCE;
            } else if ($module->archetype === MOD_ARCHETYPE_SYSTEM) {
                // System modules cannot be added by user, do not add to dropdown.
                continue;
            }
            $link = $module->link->out(true, $urlparams);
            $activities[$activityclass][$link] = $module->title;
        }

        $straddactivity = get_string('addactivity');
        $straddresource = get_string('addresource');
        $sectionname = get_section_name($course, $section);
        $strresourcelabel = get_string('addresourcetosection', null, $sectionname);
        $stractivitylabel = get_string('addactivitytosection', null, $sectionname);

        $output = html_writer::start_tag('div', array('class' => 'section_add_menus', 'id' => 'add_menus-section-' . $section));

        if (!$vertical) {
            $output .= html_writer::start_tag('div', array('class' => 'horizontal'));
        }

        if (!empty($activities[MOD_CLASS_RESOURCE])) {
            $select = new url_select($activities[MOD_CLASS_RESOURCE], '', array(''=>$straddresource), "ressection$section");
            $select->set_help_icon('resources');
            $select->set_label($strresourcelabel, array('class' => 'accesshide'));
            $output .= $this->output->render($select);
        }

        if (!empty($activities[MOD_CLASS_ACTIVITY])) {
            $select = new url_select($activities[MOD_CLASS_ACTIVITY], '', array(''=>$straddactivity), "section$section");
            $select->set_help_icon('activities');
            $select->set_label($stractivitylabel, array('class' => 'accesshide'));
            $output .= $this->output->render($select);
        }

        if (!$vertical) {
            $output .= html_writer::end_tag('div');
        }

        $output .= html_writer::end_tag('div');

        if (course_ajax_enabled($course) && $course->id == $this->page->course->id) {
            // modchooser can be added only for the current course set on the page!
            $straddeither = get_string('addresourceoractivity');
            // The module chooser link
            $modchooser = html_writer::start_tag('div', array('class' => 'mdl-right'));
            $modchooser.= html_writer::start_tag('div', array('class' => 'section-modchooser'));
            $icon = $this->output->pix_icon('t/add', '');
            $span = html_writer::tag('span', $straddeither, array('class' => 'section-modchooser-text'));
            $modchooser .= html_writer::tag('span', $icon . $span, array('class' => 'section-modchooser-link'));
            $modchooser.= html_writer::end_tag('div');
            $modchooser.= html_writer::end_tag('div');

            // Wrap the normal output in a noscript div
            $usemodchooser = get_user_preferences('usemodchooser', $CFG->modchooserdefault);
            if ($usemodchooser) {
                $output = html_writer::tag('div', $output, array('class' => 'hiddenifjs addresourcedropdown'));
                $modchooser = html_writer::tag('div', $modchooser, array('class' => 'visibleifjs addresourcemodchooser'));
            } else {
                // If the module chooser is disabled, we need to ensure that the dropdowns are shown even if javascript is disabled
                $output = html_writer::tag('div', $output, array('class' => 'show addresourcedropdown'));
                $modchooser = html_writer::tag('div', $modchooser, array('class' => 'hide addresourcemodchooser'));
            }
            $output = $this->courserenderer->course_modchooser($modules, $course) . $modchooser . $output;
        }

        return $output;
    }	 
// fja, kas panemta no course/renderer.php
//tā ir resursu rādīsanai , vajadzēs palabot!!!!!!
/**
     * Renders HTML to display a list of course modules in a course section
     * Also displays "move here" controls in Javascript-disabled mode
     *
     * This function calls {@link core_course_renderer::course_section_cm()}
     *
     * @param stdClass $course course object
     * @param int|stdClass|section_info $section relative section number or section object
     * @param int $sectionreturn section number to return to
     * @param int $displayoptions
     * @return void
     */
    public function course_section_cm_list($course, $section, $sectionreturn = null, $displayoptions = array()) {
        global $USER;

        $output = '';
        $modinfo = get_fast_modinfo($course);
        if (is_object($section)) {
            $section = $modinfo->get_section_info($section->section);
        } else {
            $section = $modinfo->get_section_info($section);
        }
        $completioninfo = new completion_info($course);

        // check if we are currently in the process of moving a module with JavaScript disabled
        $ismoving = $this->page->user_is_editing() && ismoving($course->id);
        if ($ismoving) {
            $movingpix = new pix_icon('movehere', get_string('movehere'), 'moodle', array('class' => 'movetarget'));
            $strmovefull = strip_tags(get_string("movefull", "", "'$USER->activitycopyname'"));
        }

        // Get the list of modules visible to user (excluding the module being moved if there is one)
        $moduleshtml = array();
        if (!empty($modinfo->sections[$section->section])) {
            foreach ($modinfo->sections[$section->section] as $modnumber) {
                $mod = $modinfo->cms[$modnumber];

                if ($ismoving and $mod->id == $USER->activitycopy) {
                    // do not display moving mod
                    continue;
                }

                if ($modulehtml = $this->course_section_cm_list_item($course,
                        $completioninfo, $mod, $sectionreturn, $displayoptions)) {
                    $moduleshtml[$modnumber] = $modulehtml;
                }
            }
        }

        $sectionoutput = '';
        if (!empty($moduleshtml) || $ismoving) {
            foreach ($moduleshtml as $modnumber => $modulehtml) {
                if ($ismoving) {
                    $movingurl = new moodle_url('/course/mod.php', array('moveto' => $modnumber, 'sesskey' => sesskey()));
                    $sectionoutput .= html_writer::tag('li',
                            html_writer::link($movingurl, $this->output->render($movingpix), array('title' => $strmovefull)),
                            array('class' => 'movehere'));
                }

                $sectionoutput .= $modulehtml;
            }

            if ($ismoving) {
                $movingurl = new moodle_url('/course/mod.php', array('movetosection' => $section->id, 'sesskey' => sesskey()));
                $sectionoutput .= html_writer::tag('li',
                        html_writer::link($movingurl, $this->output->render($movingpix), array('title' => $strmovefull)),
                        array('class' => 'movehere'));
            }
        }

        // Always output the section module list.
        $output .= html_writer::tag('ul', $sectionoutput, array('class' => 'section img-text'));

        return $output;
    }
	
	
//fja, visiem studentiem stilu rekina, augsaa tikai vienam
/*
public function ls_pieskirsana(){
global $DB;
global $USER;
$userid=$USER->id;
$courseid=$_SESSION['courseid'];

//echo "userid= ".$userid;
//-------------------- ieraksti db tabulaa 	v_user_artefact_type-------------
//definee klasi
//echo "kursa id= ".$courseid;
$testname='learningstyle';
$res = $DB->get_records_menu('v_user_artefact_type',array('artefacttype'=>$testname),'id','artefacttype,id'); 
//echo "<pre>";
//print_r($res);
//echo "</pre>";
if (empty($res)) { //ja nav tad pievienojam
					$record = new stdClass();
					$record->artefacttype= $testname;
					$lastid=$DB->insert_record('v_user_artefact_type', $record);
					$artefacttypeid=$lastid;}
		else {
			$artefacttypeid=$res[$testname];
			//echo "<br>AR= ".$artefacttypeid;
		}
//------------------------------------------------------------
				//jaizvelk visu lietotaaju dati
				$result = $DB->get_records_menu('v_user_artefact_all',array('artefacttypeid'=>$artefacttypeid, 'userid'=>$userid),'userid','id,userid'); 
				echo "<br>Result masiivs <pre>";
				print_r ($result);
				echo "</pre>";
				//$visu_skaits=sizeof($result);
				//echo "</br>";
				//$n=1;//tabulas numurs
				//foreach ($result as $key => $value) {$prev_stud=$value; break;}
		if (!empty($result))
		{
		foreach ($result as $key => $value) {
		//panemt vienu studentu	
								
							$user1 = $DB->get_record('user', array('id'=>$value));
							$result2 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,source'); 
							$result3 = $DB->get_records_menu('v_user_artefact_all',array('id'=>$key),'id','id,ctime'); 
							$result4 = $DB->get_records_menu('v_user_learningstyle',array('artefactallid'=>$key),'artefactallid','lstylename,value'); 
								//stilu vilksana
								$ststils=array();
								$m=0; //lai saprastu, ka visi stili atrasti
								foreach ($result4 as $key4 => $value4)
										{
										if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
											{
											if ($key4=="v") 
													{$ststil['v']=$value4;}else
											
											if ($key4=="a")
													{$ststil['a']=$value4;}else
												{$ststil['r']=0;} 
											if ($key4=="k")
												{$ststil['k']=$value4;} 
											  } 
																								
										if ($result2[$key]=="vark3")
											{
											if ($key4=="v") 
													{
													$ststil['v']=$value4;}else
											if ($key4=="a")
													{
													$ststil['a']=$value4;}else
											if ($key4=="r")
													{
													$ststil['r']=$value4;}else
											if ($key4=="k")
													{
													$ststil['k']=$value4;}
											$m++;
											}
									}//foreach result4 				
											if ($m>0)	{		
														//jasaliek vajadzīgajā secība cita masiivā K, A, V, R
														$ststils=array();//prioritate studenta stils
														$ststils['k']=$ststil['k'];
														$ststils['a']=$ststil['a'];
														$ststils['v']=$ststil['v'];
														$ststils['r']=$ststil['r'];
														
														//------------------------------------
														//izvads
														//echo "<br>k= ".$ststils['k'];
														//echo "<br>a= ".$ststils['a'];
														//echo "<br>v= ".$ststils['v'];
														//echo "<br>r= ".$ststils['r'];
													//max pa rindinu
														$maxst=array_search(max($ststils),$ststils); //max stils
														
														//echo "<br>maxst= ".$maxst;
														if ($maxst=='k' && (
															$ststils['k']==$ststils['v'] || 
															$ststils['k']==$ststils['a'] ||
															$ststils['k']==$ststils['r'] || 
															$ststils['k']==$ststils['a'] && $ststils['k']==$ststils['v'])) 
															$stils='k';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['r']) )
															$stils='a';	
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v'] && $ststils['v']==$ststils['r']))
															$stils='va';
															else
														if ($maxst=='a' && (
															$ststils['a']==$ststils['v']) )
															$stils='va';	
															else
														if ($maxst=='v' && (
															$ststils['v']==$ststils['r']) )
															$stils='v';
															else $stils=$maxst;
														
														
														}
													
													 
											
								//if ($result2[$key]=="vark3") echo "<td>".$stils."</td>"; else 	echo "<td>"." "."</td>";
															//izvilkt personisko inf
							//jaņem atbilstosam kursam vel 
								
								$result5 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value,'courseid'=>$courseid),'userid','userid,preknow');
								$result6 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$value, 'courseid'=>$courseid),'userid','userid,dlevel');
								//if (!empty($result5))echo "<td>".$result5[$value]."</td>"; else echo "<td>".''."</td>";
								//if (!empty($result6))echo "<td>".$result6[$value]."</td>"; else echo "<td>".''."</td>";
								//echo "</tr>";				
							
								
								//aizpilda tabulu v_user_personality_data, ja lietotaaja nav			
								$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$value));
								$user_ir = $DB->get_record('v_user_personality_data', array('userid'=>$value));
								if ($user_ir==true)
										{//dzest ieprieksejo ierakstu
										$table = 'v_user_personality_data';
										$select="userid='$USER->id' and property='learningstyle'";
										$DB->delete_records_select($table, $select); 	}	
								
										//{
												
												$ls='learningstyle';
												$record7 = new stdClass();
												$record7->userid=$value;
												$record7->property=$ls;
												$record7->value=$stils;
												$table='v_user_personality_data';
												$lastid=$DB->insert_record($table, $record7);
												if ($stils=="k") echo "<br><b>Jums tika piešķirts mācīšanās stils kinestētiskais!</b>";
												if ($stils=="v") echo "<br><b>Jums tika piešķirts mācīšanās stils vizuālais!</b>";
												if ($stils=="r") echo "<br><b>Jums tika piešķirts mācīšanās stils lasīšanas!</b>";
												if ($stils=="a") echo "<br><b>Jums tika piešķirts mācīšanās stils audiālais!</b>";
												if ($stils=="va") echo "<br><b>Jums tika piešķirts mācīšanās stils vizuālais un audialais!</b>";												
												//} //user ir false  	
						
	//echo "<br>userid=".$value;
	//echo "<br>ls=".$ls;

} //foreach result

		}//if not empty
		else {
			//ja students
			if ($this->vai_students($courseid)==1) echo "<br>Nav pildījis testēšanu!";
			
		}

//else echo "Jums nav tiesību veikt šo darbību!";
}


*/	
//grupu pieskirsana visiem studentiem
/*
public function grupas_pieskirsana(){
	global $USER;
	global $COURSE;
	global $DB;
	$userid=$USER->id;
	$courseid=$COURSE->id;
	echo "<br>userid=".$userid;
	//echo "<br>courseid=".$courseid;
//echo "<H3>Studentiem grupu piešķiršana</H3>";

	if ($this->vai_students($courseid)==1)
	{	//siim lomaam ir tiesiibas veikt klasificeesanu (pati lielaka iekava
			echo "<br>Students!";
			//parbaude vai kursam ir grupas
	
//mācīšanas stila aprekinasana
$this->ls_pieskirsana();	
	
	$write=0; 
	$kursa_grupas = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
	$grupu_skaits=count($kursa_grupas);
	//echo "<br>grupu skaits= ".$grupu_skaits;
				if ($kursa_grupas==true)
					{$write=1;//echo "<br>kursam ir grupas";
				} 
					else {$write=0;		//echo "<br>kursam nav grupu";
						}
				
		if ($write==1)
					{	//2.lielakā iekava	
					//ta ka ir grupas, tad notiks studentam grupas pieskirsana
					$aclg=array();
					$ald=array();
					$result=array();
					$stud=array();
			//veido aclg nem datus no clg tabulas
//echo "<br/>";
//echo "<pre>";
//print_r($kursa_grupas);
//echo "</pre>";
						$pk = $DB->get_record('v_adaptation_features', array('feature'=>'pk'));// izvelk pazīmes id
						$dl = $DB->get_record('v_adaptation_features', array('feature'=>'dl'));// izvelk pazīmes id
						$ls = $DB->get_record('v_adaptation_features', array('feature'=>'ls'));// izvelk pazīmes id
						//echo "<br>pkid= ".$pk->id;
						//echo "<br>dkid= ".$dl->id;
						//echo "<br>lsid= ".$ls->id;

//bija nepareizi id, jo tie nesakas ar 1
//reset($obj)->id;
$n=reset($kursa_grupas)->id;
//echo "<br>n= ".$n;
$p=1;		
for ($i=$n;$i<$n+$grupu_skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br>kursa_grupas->group_number= ".$kursa_grupas[$i]->group_number;//ir
			//pec grupas numura jaapanem
						//mas
						$visas_pazimes = $DB->get_records('v_clg_description', array('clgid'=>$i));// izvelk šis grupas pazīmes
						//echo "<pre>";
						//print_r($visas_pazimes);
						//echo "</pre>";
						$pazimju_skaits=count($visas_pazimes);//ir
						//echo "<br>pazimju skaits= ".$pazimju_skaits;
						$k=reset($visas_pazimes)->id;
						for($j=1;$j<=$pazimju_skaits;$j++)
						{
						//echo "<br><br>pazimes id= ".$visas_pazimes[$k]->adaptation_features_valueid;
						
						$v2 = $DB->get_record('v_adaptation_features_values', array('id'=>$visas_pazimes[$k]->adaptation_features_valueid)); //izvelk pazīmes, veertības id
						//echo "<br>featureid= ".$v2->featureid;
						//echo "<br>feature value= ".$v2->value;
						
						if ($v2->featureid==$pk->id) $aclg[$p-1][0]=$v2->value;
						if ($v2->featureid==$dl->id) $aclg[$p-1][1]=$v2->value;
						if ($v2->featureid==$ls->id) $aclg[$p-1][2]=$v2->value;
						
						$k++;}//for pa j
			$p++;
}//for lielais	aizgaja

//parbaudei izvads
//echo "<br>aclg izvads<br>";
//echo "<pre>";
//print_r($aclg);
//echo "</pre>";
//for ($kk=0;$kk<$grupu_skaits;$kk++){
		//echo "N ".($kk)." ".$aclg[$kk][0]." ".$aclg[$kk][1].' '. $aclg[$kk][2].'<br/>';}
	
			//veido ald nem datus no studenta tabulaam
//visi kursam piesaistiitie studenti ????
//piemers

//-----------------------------------
$sql="SELECT DISTINCT
			u.id
			
			
			FROM
			 mdl_user u,
			 mdl_role_assignments ra,
			 mdl_context con,
			 mdl_course c,
			 mdl_role r
			WHERE
			 u.id = ra.userid AND
			 ra.contextid = con.id AND
			 con.contextlevel = 50 AND
			 con.instanceid = c.id AND
			 ra.roleid = r.id AND
			 r.shortname = 'student'
			 ORDER BY u.id";

//nepareizs vaicaajums
$coursestudents=array();			 
$coursestudents = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//---------------------

//echo "<pre>";
//print_r($coursestudents);
//echo "</pre>";

			//masiiva ald aizpildiisana, dati par apmācāmo
//nem studentu un tad visas vajadziigaas ipasiibas
//echo "<br/>";
//sadi dabuuju studentu id
$skaits=0; //studentu skaits
//echo "<H4>Kursa studenti:</H4>";
	/*foreach ($coursestudents as $id => $student) {
					echo "id= ".$student->id."<br/>";
					$stud[$skaits]=$student->id;
					
					echo "n= ".$skaits." "." id= ".$stud[$skaits]."<br/>";
					$skaits++;}//cikla aizversana*/
					
		//jau pasa masiiva ald aizpildiisana
		/*
			$p=0;//varbuut nevajag
$skaits=1;
$vai_dati=array();
	for ($i=0;$i<$skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br><br>Darbiiba studentam ".$stud[$i];
//kursu un šim kursam
$rez1 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$userid),'userid','userid,preknow'); 
$rez2 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$userid),'userid','userid,dlevel'); 
$rez3 = $DB->get_records_menu('v_user_personality_data',array('userid'=>$userid,'property'=>'learningstyle'),'userid','userid,value');


//echo "<br>Triju masiivu izdruka";
//echo "<br>";
print_r($rez1);echo "<br>";
print_r($rez2);echo "<br>";
print_r($rez3);echo "<br>";
			if (!empty($rez1)&& !empty($rez3))
			{$vai_dati[$i]=1;
			//echo "<br>vai_dati[i]=".$vai_dati[$i];
						
			//echo "<br>"; print_r($rez1);
			//echo "<br>pk=".($rez1[$stud[$i]]);
			//echo "<br>dl=".($rez2[$stud[$i]]);
			//echo "<br>style=".($rez3[$stud[$i]]);
			$ald[$i][0]=$stud[$i];
			$ald[$i][1]=$rez1[$stud[$i]];
			$ald[$i][2]=$rez2[$stud[$i]];
			$ald[$i][3]=$rez3[$stud[$i]];
			//echo "<br>Dati ierakstiiti masiivaa";
			} 
		else {//echo "<br>".$stud[$i]." nav izieta testēšana vai nav atjaunināti dati!";
				$vai_dati[$i]=0;$p++;
				//echo " vai_dati[i]=".$vai_dati[$i];
				}
		
}//for masiivs ald aizpildīts	
//echo "<br/>";
//echo "<pre>";
//print_r($ald);
//echo "<pre>";
					
			//tad aclg un ald masiivu saliidzinasana
			if (!empty($ald))
			{
$temp=array();

//-----------------
//print_r($vai_dati);
//echo "<br>atdala<br>";
//for ($a=0;$a<$skaits;$a++) echo $vai_dati[$a]." ";


//echo "talak iet if";
	if (!empty($vai_dati)) 
	{//ir vismaz viens ko klasificēt
for($ii=0;$ii<$skaits;$ii++)			
{
	//echo "<br>vai dati= ".$vai_dati[$ii];
	if ($vai_dati[$ii]==1)
	{
			for ($j=0;$j<$grupu_skaits;$j++){
			
			$csum=0;
			//echo "<br>ii= ".$ii." j= ".$j;
			//echo "<br>ald mas= ".$ald[$ii][1]." aclg mas= ".$aclg[$j][0];
				if ($ald[$ii][1]==$aclg[$j][0]) $csum++;	
				if ($ald[$ii][2]==$aclg[$j][1]) $csum++;
				if ($ald[$ii][3]==$aclg[$j][2]) $csum++;
			//echo "<br>csum= ".$csum." ";
			$temp[$j]=$csum;
			}
//echo "<pre>";
//print_r($temp);
//echo "<pre>";			
$result[$ii]=max($temp); 
//echo "<br>max($temp)".max($temp);
$m=array_search(max($temp), $temp);
//echo "<br>m".$m;
//echo "<br>result sum= ".$result[$ii]." ";
if ($result[$ii]==3) {
		//ieraksta datus masiivaa clg_members
				//DB tabulas "clg_members" aizpildisana
	//vai taads user ir tabulaa
		$rez5 = $DB->get_records_menu('v_clg_members',array('userid'=>$ald[$ii][0]),'userid','userid,group_number');
		//ja nav tukss tad nodzes ieprieksejo ierakstu
		if (!empty($rez5))
										{//dzest ieprieksejo ierakstu
										$select="userid='$ald[$ii][0]' and courseid='$courseid'";
										$DB->delete_records_select('v_clg_members', $select); 	}
		//if (empty($rez5))	
					{//echo "<br>User= ".$ald[$ii][0]."piešķirta grupa= ".($m+1)." dati ierakstīti tabulā!";
						echo "<br>ald[ii][0]=".$ald[$ii][0];
						echo "<br>courseid=".$courseid;
						echo "<br>AAAAAA";
						echo "<br>grupa=".($m+1);
						$record = new stdClass();
						$record->userid=$ald[$ii][0];
						$record->courseid=$courseid;
						$record->group_number=($m+1);
						$table='v_clg_members';
						$lastid=$DB->insert_record($table, $record);
				} //else 
					//echo "<br/>User ".$ald[$ii][0]." grupa= ". ($m+1)." ir jau piešķirta grupa!";
			
			}
	}//if 
	}//for $ii
	} //else echo "Nav studentu, ko ieklasificēt grupās!";
} //if not empty
}//write==1
}//userrights==1
//else echo "<br>Jums nav tiesību veikt šo darbību";

//atrod kursus un dzees	
/*
		if ($input==true)
		   //DB tabulas "clg" aizpildisana
				{
						$record = new stdClass();
						$record->courseid=$courseid;
						$record->group_number=$n;
						$record->pk=$pazime[$i][$j1];
						$record->dl=$pazime[$i+1][$j2];
						$record->ls=$vv;
						$record->ctime=time();
						$table='v_clg';
						$lastid=$DB->insert_record($table, $record);
				}
	 
*/

	
	
	
	
	
//}


	} //klases beigas
