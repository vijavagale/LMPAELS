<?php
//defined('MOODLE_INTERNAL') || die();
//require_once($CFG->dirroot. '/course/format/lib.php');
//echo "teksts: ".new lang_string('aa', 'format_onebyone');
		//echo "teksts: ".get_string('format/onebyone/lang/en/format_onebyone', 'aa');
		global $CFG;
		require_once($CFG->dirroot. 'moodlelib.php');
		require_once('localhost/moodle/lib/moodlelib.php');
		$tr= new lang_string($this->identifier, $this->component, $this->a, $lang);
echo "tr= ".$tr;
?>