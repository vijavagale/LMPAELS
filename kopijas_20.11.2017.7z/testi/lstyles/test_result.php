<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<?php
require_once("../../config.php") ; 
//require_login();

echo "<H3>Testu rezultāti</H3>";



if ($USER->id==3)
{
//jaizvelk visu lietotaaju dati

//echo $DB->get_record_sql('SELECT * FROM {user_artefact_all} ');
$table= 'user_artefact_all';
$conditions = array('artefacttypeid'=>'1');
$sort = 'userid';
$fields = 'id,userid';
$result = $DB->get_records_menu($table,$conditions,$sort,$fields); 

//print_r ($result);
//echo "</br>";

//tabulas virsraksti
echo "<table border='1' cellpadding='2' cellspacing='2' width='60%' style='font-size:12px'>
<tr>
<th>N.p.k.</th>
<th>RecordID</th>
<th>UserID</th>
<th>Lastname</th>
<th>Firstname</th>
<th>Time</th>
<th>Quiz</th>
<th>Visual</th>
<th>Aural</th>
<th>Read</th>
<th>Kinesthetic</th>
<th>PreKnow</th>
<th>Dlevel</th>
</tr>";
$n=1;
//echo "id: $key; userid: $value";
//echo " ".$user1->firstname." ".$user1->lastname;
foreach ($result as $key => $value) {
echo "<tr><td>".$n."</td><td>".$key."</td>". "<td>".$value."</td>";
	$user1 = $DB->get_record('user', array('id'=>$value));
echo "<td>".$user1->lastname."</td>"."<td>".$user1->firstname."</td>";
$result2 = $DB->get_records_menu('user_artefact_all',array('id'=>$key),'id','id,source'); 
//echo " ".$result2[$key];
$result3 = $DB->get_records_menu('user_artefact_all',array('id'=>$key),'id','id,ctime'); 
//echo " ".date("d.m.Y H:i:s",$result3[$key]);	
echo "<td>".date("d.m.Y H:i:s",$result3[$key])."</td>".
"<td>".$result2[$key]."</td>";	
$result4 = $DB->get_records_menu('user_learningstyle',array('artefactallid'=>$key),'artefactallid','lstylename,value'); 
//stilu vilksana
foreach ($result4 as $key4 => $value4)
{
if ($result2[$key]=="vark1" ||$result2[$key]=="vark2")
	{
	if ($key4=="visual") echo "<td>".$value4."</td>"; else
	if ($key4=="aural")echo "<td>".$value4."</td>";else
	echo "<td> </td>"; 
	if ($key4=="kinesthetic")echo "<td>".$value4."</td>"; 
	
	} else 
	{if ($key4=="visual") echo "<td>".$value4."</td>"; else
	if ($key4=="aural")echo "<td>".$value4."</td>";else
	if ($key4=="read")echo "<td>".$value4."</td>";
	if ($key4=="kinesthetic")echo "<td>".$value4."</td>"; 
	}
}
//izvilkt personisko inf
$result5 = $DB->get_records_menu('user_personal_information',array('userid'=>$value),'userid','userid,preknow');
$result6 = $DB->get_records_menu('user_personal_information',array('userid'=>$value),'userid','userid,dlevel');
echo "<td>".$result5[$value]."</td>".
"<td>".$result6[$value]."</td>";
echo "</tr>";		
$n++;	
	
	
	
	


	





/*
while($row = mysql_fetch_array($result))
  { //$st3=$row['name'];
 
    echo $row['id']." ".$row['artefacttypeid']." ".$row['userid']." ".$row['source'].'</br>';
   }
*/

}//for
echo "</table>";
}
else 
echo "Dati apstrādes procesā!";
//print "<p>$USER->username</p>"; //this gets the username (login)
//print "<p>$USER->firstname $USER->lastname</p>"; //This gets the first and last.
//$userid = $USER->id;




?>