﻿<meta charset='utf-8 '>
<html lang="en">
<head>
	<title>lapa</title>	
</head>
<body>
<h1>Mācīšanās stilu noteikšana (VARK1)</h1>
	<div>
		
		
        <?php
		
require_once("../../../config.php") ; //this assumes your php file is in a subdirectory of your moodle 
require_login(); //Won't do any good to 'get' a username 'til sombody's logged in.  

  $testname = "vark1";   
			$viz=0;
			$taustes=0;
			$dzirdes=0;
			
$answer1=0;
$answer2=0;	
$answer3=0;
$answer4=0;
$answer5=0;
$answer6=0;
$answer7=0;
$answer8=0;
$answer9=0;
$answer10=0;
$answer11=0;
$answer12=0;
$answer13=0;
$answer14=0;
$answer15=0;
$answer16=0;
$answer17=0;
$answer18=0;
$answer19=0;	
$answer20=0;
$answer21=0;
$answer22=0;
$answer23=0;
$answer24=0;	
$answer25=0;
$answer26=0;
$dz=0;
$year1=0;

if(isset($_POST['question-1-answers'])){$answer1 = $_POST['question-1-answers'];}
if(isset($_POST['question-2-answers'])){$answer2 = $_POST['question-2-answers'];}
if(isset($_POST['question-3-answers'])){$answer3 = $_POST['question-3-answers'];}
if(isset($_POST['question-4-answers'])){$answer4 = $_POST['question-4-answers'];}
if(isset($_POST['question-5-answers'])){$answer5 = $_POST['question-5-answers'];}
if(isset($_POST['question-6-answers'])){$answer6 = $_POST['question-6-answers'];}
if(isset($_POST['question-7-answers'])){$answer7 = $_POST['question-7-answers'];}
if(isset($_POST['question-8-answers'])){$answer8 = $_POST['question-8-answers'];}
if(isset($_POST['question-9-answers'])){$answer9 = $_POST['question-9-answers'];}
if(isset($_POST['question-10-answers'])){$answer10 = $_POST['question-10-answers'];}
if(isset($_POST['question-11-answers'])){$answer11 = $_POST['question-11-answers'];}
if(isset($_POST['question-12-answers'])){$answer12 = $_POST['question-12-answers'];}
if(isset($_POST['question-13-answers'])){$answer13 = $_POST['question-13-answers'];}
if(isset($_POST['question-14-answers'])){$answer14 = $_POST['question-14-answers'];}
if(isset($_POST['question-15-answers'])){$answer15 = $_POST['question-15-answers'];}
if(isset($_POST['question-16-answers'])){$answer16 = $_POST['question-16-answers'];}
if(isset($_POST['question-17-answers'])){$answer17 = $_POST['question-17-answers'];}
if(isset($_POST['question-18-answers'])){$answer18 = $_POST['question-18-answers'];}
if(isset($_POST['question-19-answers'])){$answer19 = $_POST['question-19-answers'];}
if(isset($_POST['question-20-answers'])){$answer20 = $_POST['question-20-answers'];}
if(isset($_POST['question-21-answers'])){$answer21 = $_POST['question-21-answers'];}
if(isset($_POST['question-22-answers'])){$answer22 = $_POST['question-22-answers'];}
if(isset($_POST['question-23-answers'])){$answer23 = $_POST['question-23-answers'];}
if(isset($_POST['question-24-answers'])){$answer24 = $_POST['question-24-answers'];} 

if(isset($_POST['question-25-answers'])){$pk = $_POST['question-25-answers'];} 
if(isset($_POST['question-26-answers'])){$dl = $_POST['question-26-answers'];} 

if(isset($_POST['dz'])){$dz = $_POST['dz'];}
if(isset($_POST['day_start'])){$day1 = $_POST['day_start'];}  
if(isset($_POST['month_start'])){$month1 = $_POST['month_start'];} 
if(isset($_POST['year_start'])){$year1 = $_POST['year_start'];}
/*
$pk=-1;
$pdl=-1;
 if ($answer25 == "A") { $pk="n"; }
  if ($answer25 == "B") { $pk="y"; }
if ($answer26 == "A") { $dl="e"; } 
if ($answer26 == "B") { $dl="m"; } 
if ($answer26 == "C") { $dl="d"; } 
echo "AAA".$pk; 
echo "BBB".$dl;  */     
if ($answer1 == "A") { $dzirdes+=5; }
if ($answer1 == "B") { $dzirdes+=3; }
if ($answer1 == "C") { $dzirdes+=1; }
if ($answer5 == "A") { $dzirdes+=5; }
if ($answer5 == "B") { $dzirdes+=3; }
if ($answer5 == "C") { $dzirdes+=1; }
if ($answer8 == "A") { $dzirdes+=5; }
if ($answer8 == "B") { $dzirdes+=3; }
if ($answer8 == "C") { $dzirdes+=1; }
if ($answer11 == "A") { $dzirdes+=5; }
if ($answer11 == "B") { $dzirdes+=3; }
if ($answer11 == "C") { $dzirdes+=1; }
if ($answer13 == "A") { $dzirdes+=5; }
if ($answer13 == "B") { $dzirdes+=3; }
if ($answer13 == "C") { $dzirdes+=1; } 
if ($answer18 == "A") { $dzirdes+=5; }
if ($answer18 == "B") { $dzirdes+=3; }
if ($answer18 == "C") { $dzirdes+=1; } 
if ($answer21 == "A") { $dzirdes+=5; }
if ($answer21 == "B") { $dzirdes+=3; }
if ($answer21 == "C") { $dzirdes+=1; } 
if ($answer24 == "A") { $dzirdes+=5; }
if ($answer24 == "B") { $dzirdes+=3; }
if ($answer24 == "C") { $dzirdes+=1; } 
//  **dzirdes punkti saskaitīti**
if ($answer2 == "A") { $viz+=5; }
if ($answer2 == "B") { $viz+=3; }
if ($answer2 == "C") { $viz+=1; } 
if ($answer3 == "A") { $viz+=5; }
if ($answer3 == "B") { $viz+=3; }
if ($answer3 == "C") { $viz+=1; }   
if ($answer7 == "A") { $viz+=5; }
if ($answer7 == "B") { $viz+=3; }
if ($answer7 == "C") { $viz+=1; }
if ($answer10 == "A") { $viz+=5; }
if ($answer10 == "B") { $viz+=3; }
if ($answer10 == "C") { $viz+=1; }
if ($answer14 == "A") { $viz+=5; }
if ($answer14 == "B") { $viz+=3; }
if ($answer14 == "C") { $viz+=1; } 
if ($answer16 == "A") { $viz+=5; }
if ($answer16 == "B") { $viz+=3; }
if ($answer16 == "C") { $viz+=1; } 
if ($answer19 == "A") { $viz+=5; }
if ($answer19 == "B") { $viz+=3; }
if ($answer19 == "C") { $viz+=1; } 
if ($answer22 == "A") { $viz+=5; }
if ($answer22 == "B") { $viz+=3; }
if ($answer22 == "C") { $viz+=1; }
//  **vizuālie punkti saskaitīti**
if ($answer4 == "A") { $taustes+=5; }
if ($answer4 == "B") { $taustes+=3; }
if ($answer4 == "C") { $taustes+=1; }
if ($answer6 == "A") { $taustes+=5; }
if ($answer6 == "B") { $taustes+=3; }
if ($answer6 == "C") { $taustes+=1; }
if ($answer9 == "A") { $taustes+=5; }
if ($answer9 == "B") { $taustes+=3; }
if ($answer9 == "C") { $taustes+=1; }
if ($answer12== "A") { $taustes+=5; }
if ($answer12== "B") { $taustes+=3; }
if ($answer12== "C") { $taustes+=1; }
if ($answer15== "A") { $taustes+=5; }
if ($answer15== "B") { $taustes+=3; }
if ($answer15== "C") { $taustes+=1; }
if ($answer17== "A") { $taustes+=5; }
if ($answer17== "B") { $taustes+=3; }
if ($answer17== "C") { $taustes+=1; }
if ($answer20== "A") { $taustes+=5; }
if ($answer20== "B") { $taustes+=3; }
if ($answer20== "C") { $taustes+=1; }
if ($answer23== "A") { $taustes+=5; }
if ($answer23== "B") { $taustes+=3; }
if ($answer23== "C") { $taustes+=1; }
//  **taustes punkti saskaitīti**
    //vizuālie  - 2,3,7,10,14,16,19,22
	//taustes   - 4,6,9,12,15,17,20,23
	//dzirdes   - 1,5,8,11,13,18,21,24 
	
//pārbaudes uz lauku aizpildīsanu	
	if($dzirdes>40||$taustes>40||$viz>40||($year1<1930)||($year1>2010)||($dz=='')||($pk=="")||($dl=="")) {echo "<i>Nav ievadītas atbildes uz vienu vai vairākiem jautājumiem!</i><br/><br/><a href='javascript:history.back(1);'>Atpakaļ</a>"; die();}
	//exit("Nav pareizi atbildēts");
        

if ($month1=='Janvāris') $month2=1;
if ($month1=='Februāris') $month2=2;
if ($month1=='Marts') $month2=3;
if ($month1=='Aprīlis') $month2=4;
if ($month1=='Maijs') $month2=5;
if ($month1=='Jūnijs') $month2=6;
if ($month1=='Jūlijs') $month2=7;
if ($month1=='Augusts') $month2=8;
if ($month1=='Septembris') $month2=9;
if ($month1=='Oktobris') $month2=10;
if ($month1=='Novembris') $month2=11;
if ($month1=='Decembris') $month2=12;
//echo "<p>Dzimšanas datums: ".$day1." ".$month2." ".$year1."</p>";

if ($pk=='n') $pk1=0;
if ($pk=='y') $pk1=1;
if ($dl=='e') $dl1=1;
if ($dl=='m') $dl1=2;
if ($dl=='d') $dl1=3;
	
	//ierakstīšana db
//--------------------------------------------------------------------------------------



$user_ir = $DB->get_record('user_personal_information', array('userid'=>$USER->id));

if ($user_ir==false)
{
//echo "Ieraksta 1. tabula";
//			tabula			User_personal_information

$recordb = new stdClass();
$recordb->artefacttypeid= 1;
$recordb->userid= $USER->id;
$recordb->ctime= time();
$recordb->bday= $day1;
$recordb->bmonth= $month2;
$recordb->byear= $year1;
$recordb->gender= $dz;
$recordb->source= $testname;
$recordb->preknow= $pk1;
$recordb->dlevel= $dl1;
$DB->insert_record('user_personal_information', $recordb);
} 
//else echo "neieraksta 1.tabula";
//--------------------------------------------------------------------------------------
// tikai parbaudei izvads
/*
print "<p>$USER->username</p>"; //this gets the username (login)
print "<p>$USER->firstname $USER->lastname</p>"; //This gets the first and last.
$userid = $USER->id;
echo "<p>".$userid."</p>";
echo "<p>".$CFG->prefix."</p>";
//vajad userid, ctime

$ctime=time();
echo "</br>Time = ".$ctime;
$v="learningstyle";
*/


//-------------------- ieraksts db tabulaa 				user_artefact_type-------------
//definee klasi
/*$record = new stdClass();
$record->artefacttype= 'learningstyle';
$lastid=$DB->insert_record('user_artefact_type', $record);
echo "</br>LastId = ".$lastid;*/
//tas dublee so    mysql_query("INSERT INTO {$CFG->prefix}user_artefact_type (artefacttype) VALUES ('learningstyle')");
//-------------------
//vajag kodu, kas atbilstošam artefaktam meklē ID
//man learning stylam bus id=1

//vai ir ieraksts?
$source_ir = $DB->get_record('user_artefact_all', array('userid'=>$USER->id,'source'=>$testname));

if ($source_ir==false)
{
//echo "Ieraksta 2. tabula";
//-----		ieraksta tabulaa					user_artefact_all-----------

$record = new stdClass();
$record->artefacttypeid= 1;
$record->userid= $USER->id;
$record->ctime= time();
$record->source= $testname;
$record->description= 'mācīšanās stils';
//dabūt artefactid
$lastid=$DB->insert_record('user_artefact_all', $record);

//------------		ieraksta tabulaa			user_learningstyle-----
$recordlsv = new stdClass();
$recordlsv->artefactallid= $lastid;
$recordlsv->lstylename= 'visual';
$recordlsv->value= $viz;
$DB->insert_record('user_learningstyle', $recordlsv,false);

$recordlsa = new stdClass();
$recordlsa->artefactallid= $lastid;
$recordlsa->lstylename= 'aural';
$recordlsa->value= $dzirdes;
$DB->insert_record('user_learningstyle', $recordlsa);

$recordlsk = new stdClass();
$recordlsk->artefactallid= $lastid;
$recordlsk->lstylename= 'kinesthetic';
$recordlsk->value= $taustes;
$DB->insert_record('user_learningstyle', $recordlsk);

echo "</br>Dati ierakstīti datu bāzē!";
} else echo "</br>Jūs šo testu jau esiet veicis agrāk, tāpēc ieraksts datu bāzē netika veikts!</br>";


//-------------- ieraksta beigas db

	
            echo "<div id='results'>Dzirdes atmiņas punkti:</br>  $dzirdes / 40 </div>";
		    echo "<div id='results'>Redzes atmiņas punkti:</br>  $viz / 40 </div>";
		    echo "<div id='results'>Taustes atmiņas punkti:</br>  $taustes / 40 </div>";
if($dzirdes==$taustes&&$dzirdes==$viz){echo "<h3>Tests norāda ka jums ir visi trīs atmiņas veidi. </br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Irakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";	
exit;
}		
if ($viz>$taustes&&$viz>$dzirdes)echo "<h3>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";
if ($taustes>$viz&&$taustes>$dzirdes)echo "<h3>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</h3>";
if ($dzirdes>$taustes&&$dzirdes>$viz)echo "<h3>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Rakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</h3>";
if ($dzirdes==$viz)echo "<h3>Tests norāda ka jums ir dzirdes un redzes atmiņa. </br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Irakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";
if($viz==$taustes)echo "<h3>Tests norāda ka jums ir taustes un redzes atmiņa. </br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir redzes atmiņa, tad katrā gadījumā centieties aplūkot 
visus izdotos materiālus. Lietojiet tabulas, kartes, bildes un pierakstus. 
Trennējieties iztēloties vārdus un idejas vizuāli sev galvā. Pierakstiet visu tā, lai viss ir labi saskatāms un saprotams.</h3>";
if($dzirdes==$taustes)echo "<h3>Tests norāda ka jums ir taustes un dzirdes atmiņa. </br>Ja jums ir taustes atmiņa sekojiet līdzi vārdiem kamēr tos sakiet. Faktus, kurus nepieciešams iemācities, vajadzētu pārrakstīt vairākas reizes.
Nēsājiet līdzi papildus lapiņas, lai varētu to īstenot. Veikt un saglabāt lekciju pierakstus ir ļoti svarīgi. Mācoties arī centieties veikt pierakstus.</br></br>Ja jums ir dzirdes atmiņa, jums varbūt vajadzētu lietot ierakstus. Irakstiet lekcijas, lai aizpildītu visus atmiņas caurumus.
Bet tas, ka ierakstiet lekcijas nenozīmē ka nav jāklausās un jāpieraksta. Lekcijās izvēlieties vietu, kur variet labi un skaidri dzirdēt.
Kad esiet kaut ko jaunu izlasījuši, apkopojiet informāciju un pārlasiet to skaļi.</h3>";
            
        ?>
	
	</div>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Moodle</a>

</body>
</html>