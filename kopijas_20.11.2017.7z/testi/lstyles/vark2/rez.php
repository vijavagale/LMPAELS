﻿<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
<h1>VAK mācīšanās stila rezultāti (VARK2)</h1>
<?php
require_once("../../../config.php") ;
$testname = "vark2";
$c_visual=0;
$c_auditory=0;
$c_kinesthetic=0;

foreach(array_keys($_POST) as $i){
if (substr($i,0,1)=='s') $c_visual+=$_POST[$i];
if (substr($i,0,1)=='x') $c_auditory+=$_POST[$i];
if (substr($i,0,1)=='y') $c_kinesthetic+=$_POST[$i];
}

//paarbaude

$source_ir = $DB->get_record('user_artefact_all', array('userid'=>$USER->id,'source'=>$testname));

if ($source_ir==false)
{
//echo "Ieraksta 2. tabula";

//-----		ieraksta tabulaa					user_artefact_all-----------

$record = new stdClass();
$record->artefacttypeid= 1;
$record->userid= $USER->id;
$record->ctime= time();
$record->source= $testname;
$record->description= 'mācīšanās stils';
//dabūt artefactid
$lastid=$DB->insert_record('user_artefact_all', $record);

//------------		ieraksta tabulaa			user_learningstyle-----
$recordlsv = new stdClass();
$recordlsv->artefactallid= $lastid;
$recordlsv->lstylename= 'visual';
$recordlsv->value= $c_visual;
$DB->insert_record('user_learningstyle', $recordlsv,false);

$recordlsa = new stdClass();
$recordlsa->artefactallid= $lastid;
$recordlsa->lstylename= 'aural';
$recordlsa->value= $c_auditory;
$DB->insert_record('user_learningstyle', $recordlsa);

$recordlsk = new stdClass();
$recordlsk->artefactallid= $lastid;
$recordlsk->lstylename= 'kinesthetic';
$recordlsk->value= $c_kinesthetic;
$DB->insert_record('user_learningstyle', $recordlsk);
echo "</br>Dati ierakstīti datu bāzē!";
} else echo "</br>Jūs šo testu jau esiet veicis agrāk, tāpēc ieraksts datu bāzē netika veikts!</br>";
//-------------- ieraksta beigas db
        
		
echo '</br>Kopējais punktu skaits katram mācīšanās stilam : </br></br>';

echo '<table border="2" cellpadding="6" width="50%">
<tr>
<td align="center"><b>Vizuālais mācīšanās stils</b></td>
<td align="center"><b>Dzirdes mācīšanās stils</b></td>
<td align="center"><b>Kinestētiskais mācīšanās stils</b></td>
</tr>
<td align="center">Punktu skaits :<br/>'.$c_visual.'</td>
<td align="center">Punktu skaits:<br/>'.$c_auditory.'</td>
<td align="center">Punktu skaits:<br/>'.$c_kinesthetic.'</td>
<tr>

</tr>
</table>';

echo '</br>Jums ne obligāti jāizvēlas mācīšanās stilu pēc lielākā punktu skaita, <br>
 tas drīzāk ir vēlamais mācīšanās stils, jūs varat izmantot visus trīs mācīšanās stilus.</br></br>';


?>
<a href='javascript:window.history.go(-2);'>Atpakaļ uz Moodle</a>	
</body>
</html>