<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Newblock block caps.
 *
 * @package    block_newblock
 * @copyright  Vija Vagale <vija.vagale@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();
require_once($CFG->dirroot.'/config.php') ;
//prieks js
require_once($CFG->libdir . '/pagelib.php');

global $PAGE;
$PAGE->requires->js( new moodle_url($CFG->wwwroot . '/blocks/tmm/view.js') );


class block_tmm extends block_base {
//-------------------------------------------------------------------fja
public function testa_nosaukums($tema_num){
global $USER, $DB;
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
	//iegūst studenta dl
//$rez = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$userid),'userid','userid,dlevel');
$peddata = $DB->get_record('v_user_pedagogical_data', array('userid'=>$userid,'courseid'=>$courseid));
if (!empty($peddata))$dl = $DB->get_field('v_user_pedagogical_data', 'dlevel', array('userid' => $userid, 'courseid' => $courseid), MUST_EXIST); else $dl="";
//$dl=$rez[$userid]; 
$testa_nosaukums=$dl."Tests".$tema_num;
	return $testa_nosaukums;
}
//-------------------------------------------------------------------fja
public function ierakstito_atzimju_seciba(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (!empty($lerndata->topic_grade))	
	return $lerndata->topic_grade;
			else return 0;
}
//-------------------------------------------------------------------fja
public function tsecibas_variants_pedejais(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (!empty($lerndata))
return $this->last_number($lerndata->topic_choices_variants);
	else
return 0;
}
//-------------------------------------------------------------------fja
public function pedeja_apguta_tema(){
//temas bez pedejaas
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$visastemas=$lerndata->topic_sequence;
$ptema=$this->last_number($lerndata->topic_sequence);

//echo "<br>ped_tema= ".$ptema;
return $ptema;
}
//-------------------------------------------------------------------fja
public function temu_seciba_bezpedejas(){
//temas bez pedejaas
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$visastemas=$lerndata->topic_sequence;
$ptema=$this->last_number($lerndata->topic_sequence);
$ko=','.$ptema;
$temas_bezpedejas=str_replace($ko,'',$visastemas);
return $temas_bezpedejas;
}
//--------------------------------------------------------------------fja
public function temas_apgutas_plus_saites(){
//apguutās+jaunā tema
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$ts=$lerndata->topic_sequence;
$st=$this->temas_pec_saites();
if (!empty($st)){
$starray = explode(",", $st);
$n2=sizeof($starray);
//echo "<br>st n2=".$n2;
if ($n2>0){
		for ($i=0;$i<$n2;$i++)
		$ts.=','.$starray[$i];	}
		//echo "<br>ts=".$ts;
		}
	return $ts;
}
//-------------------------------------------------------------------fja
public function temas_pec_saites(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;	

//--------------------------
//vai bija pedeja tema
$ptemas_num=$this->course_allsections_number();

//meklē vai apgūta peedeejaa tema
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$param = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
	$tts=$param->teacher_topic_sequence;
	$ts=$lerndata->topic_sequence;
	$ttsarray = explode(",", $tts); 
	$tsarray = explode(",", $ts); 
	$ttsskaits=sizeof($ttsarray);
	$tsskaits=sizeof($tsarray);
	$k=0;
		for ($j=0;$j<$tsskaits;$j++)
		if ($tsarray[$j]==$ptemas_num) $k=1;
		//echo "<br> k=".$k;
		//echo "k=1 tad bija ped tema apguuta";						
//------------------------------
//meklee temas peec saites
$ped_tema=$this->last_number($lerndata->topic_sequence);
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
//1:2,3,5;2:3,4,5;3:4,5;4:5,7;5:6,7;6:7;7:5,8,10;8:9,10;9:10
			$visassaites=$re->topic_link;
			$skaits=strlen($visassaites);
			//echo "<br>fja-------------- temas pec saites";
			$st=$ped_tema.':';
			//echo "<br>st=".$st;
			$pos=strpos($visassaites,$st);
			
			//echo "<br> visas saites=".$visassaites;
			//echo "<br>no kuras saakas pos= ".$pos.'<br>';
			
			$k=0;
			$next_topic="";
			$ntopic="";
			$temas_garums=strlen($ped_tema);
			
			for ($i=$pos+$temas_garums+1;$i<$skaits;$i++)
				{if ($visassaites[$i]==';') break;
				$ntopic[$k]=$visassaites[$i]; $k++;
				}
				
			//echo "Nakamas saites (piem pec pedejas)= ";
			//print_r($ntopic);
//jaamekle vai saites bija apskatiitas
			$ntopic2=implode($ntopic);
			//echo "<br>ntopic2=".$ntopic2;
			$sarray = explode(",", $ntopic2); 
			//echo "<br>sarray=";
			//print_r($sarray);
			$sskaits=sizeof($sarray);
			//vai ieguutas saites jau apskatiitas
			$mas=array();
				$a=0;
					for ($j=0;$j<$sskaits;$j++)
					{$k=0;
					for ($i=0;$i<$tsskaits;$i++)
					{	if ($sarray[$j]==$tsarray[$i]) $k=1;}
					if ($k==1) 	{$mas[$a]=$k;$a++;}
					}
					//mas ar saišu esamību
					//echo "<pre>".print_r(mas)."</pre>";
			if ($a!=0){		
					//echo "<br>mas=";
					//print_r($mas);
			//echo "<br>sskaits=".$sskaits;	echo "<br>array_sum(mas)=".array_sum($mas);		
			if (array_sum($mas)==$sskaits) $visas_temas_saites_apskatitas=1; else
			if (array_sum($mas)==0) $visas_temas_saites_apskatitas=0; else
			if (array_sum($mas)<$sskaits && array_sum($mas)>0 ) $visas_temas_saites_apskatitas=2; //daleji apguutas
						}
						else $visas_temas_saites_apskatitas=-1;//pirma reize
			
			
				
if ($visas_temas_saites_apskatitas==0 or $visas_temas_saites_apskatitas==2 or $visas_temas_saites_apskatitas==-1)	{$next_topic=$ntopic2;}
						
	//ja ir apguuta pedeja un saisu vairs nav
if ($k==1 && $visas_temas_saites_apskatitas==1)
				{//jameklee kuras nav apguutas
				$a=0;//$b ierobezoja uz vienu temu
					for ($i=0;$i<$ttsskaits;$i++)
					{	$k=0;
						for ($j=0;$j<$tsskaits;$j++)
							if ($ttsarray[$i]==$tsarray[$j]) $k=1;
						if ($k==0) 	{$rez[$a]=$ttsarray[$i];$a++;}
						
					}//$next_topic=$rez[0];
				if ($a!=0){
						$n2=sizeof($rez);
						//echo "<br> n2=".$n2."<br>rez= ";
						//print_r($rez);
						$next_topic='';
						if ($n2>0){
								for ($i=0;$i<$n2;$i++)
								{$next_topic.=$rez[$i];
								if (!empty($rez[$i+1]))	$next_topic.=',';
								}
								}
						//echo "Nakamas saites2= ".$next_topic;
						}
			}
return $next_topic;
}
//-------------------------------------------------------------------fja
public function vai_si_tema_ierakstiita($displaysection){
//panemt no jau ierakstiistaas secībass
$vtemas=$this->ierakstito_temu_seciba();
//saliidzinaat ar displaysection
$vtemas = explode(",", $vtemas);
$skaits=sizeof($vtemas);
$m=0;	
for ($i=0;$i<$skaits;$i++) 	
	if ($vtemas[$i]==$displaysection) $m=1;
	
//ja nav tad ierakstiit
return $m;
}
//-------------------------------------------------------------------fja
public function datu_ierakstisana_cts(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;	

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (!empty($lerndata)) {
						$coursedata = $DB->get_record('v_course_topic_sequence', array('uldid'=>$lerndata->id));
						if (empty($coursedata)) {
						$record1 = new stdClass();
						$record1->uldid=$lerndata->id;
						$record1->courseid=$lerndata->courseid;
						$record1->topic_sequence=$lerndata->topic_sequence;
						$record1->course_grade=$lerndata->course_grade;
						$lastid=$DB->insert_record('v_course_topic_sequence', $record1);}
						else {//update
						
						}}
}
//-------------------------------------------------------------------fja
public function kursa_atzimes_saglabasana(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;	

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$katzime=$this->kursa_kopeja_atzimi();
//ieraksta tabulaa
//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->course_grade=$katzime;
						$sql = $DB->update_record('v_user_learning_data', $record2);
}		
//-------------------------------------------------------------------fja
public function kursa_kopeja_atzimi(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$visas_atzimes=$lerndata->topic_grade;
	$v_atzimes = explode(",", $visas_atzimes);
$skaits=sizeof($v_atzimes);
$sum=0;	
for ($i=0;$i<$skaits;$i++) 	
	$sum=$sum+$v_atzimes[$i];
$gala_atzime=$sum/$skaits;	
return $gala_atzime;
}
//-------------------------------------------------------------------fja
public function ierakstito_atzimju_skaits(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (!empty($lerndata->topic_grade)){	
	$visas_atzimes=$lerndata->topic_grade;
	$a_skaits=substr_count($visas_atzimes,',')+1;}
		else $a_skaits=0;
return $a_skaits;
}
//--------------------------------------------------------------------fja
public function ierakstito_temu_skaits(){
$visas_temas=$this->ierakstito_temu_seciba();
$t_skaits=substr_count($visas_temas,',')+1;
return $t_skaits;
}
//------------------- -----------------------------------------------fja
public function ierakstito_temu_seciba(){
//apguutās+jaunā tema
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	
		if (!empty($lerndata)) return $lerndata->topic_sequence; else return 0;
}
//--------------------------------------------------------------------fja
public function init() {
	         			 $this->title = get_string('tmm', 'block_tmm');
			 
    }
//--------------------------------------------------------------------fja
public function dzest_meginajumu($displaysection){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$testa_nosaukums=$this->testa_nosaukums($displaysection);
$quiz = $DB->get_record('quiz', array('course'=>$courseid,'name'=>$testa_nosaukums));
//$quiz_attempt = $DB->get_record('quiz_attempts', array('quiz'=>$quiz->id,'userid'=>$userid,'attempt'=>'1'));
$select='quiz='.$quiz->id.' and userid='.$userid.' and attempt=1';
$DB->delete_records_select('quiz_attempts', $select);

}
//--------------------------------------------------------------------fja
public function course_allsections_number(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

//kursa sekciju skaita iegūsana
$re = $DB->get_record('course_format_options',array('courseid'=>$courseid,'format'=>'onebyone','name'=>'numsections'));
return $re->value;
}
//--------------------------------------------------------------------fja
public function show_topic_list($tema_num){
				if ($this->was_quizattempt($tema_num)==1){
				$tatzime=$this->quiz_grade($tema_num);
				if ($tatzime>=4) {
					//$this->write_topic_grade($tema_num);
					$can_next=1;}
				else {$can_next=0;}
				}//bija tests pildtts
				return $can_next;
}
//--------------------------------------------------------------------fja
public function was_quizattempt($tema_num){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
$quiz='';
$quiz_attempt='';	
$testa_nosaukums=$this->testa_nosaukums($tema_num);
	//echo "<br>Testa numurs= ".$testa_nosaukums;
	//panemt no user_learning_data topica numuru
	$quiz = $DB->get_record('quiz', array('course'=>$courseid,'name'=>$testa_nosaukums));
	if (!empty($quiz)) $quiz_attempt = $DB->get_record('quiz_attempts', array('quiz'=>$quiz->id,'userid'=>$userid,'attempt'=>'1'));
	//echo "<br>tests= ";
	//print_r($quiz_attempt);
	if (!empty($quiz_attempt)) return 1; else 0;
	
}
//--------------------------------------------------------------------fja
/*
public function student_param_assignment(){
$write=0; 
	$kursa_grupas = $DB->get_records('v_clg',array('courseid'=>$courseid)); 
	$grupu_skaits=count($kursa_grupas);
	echo "<br>grupu skaits= ".$grupu_skaits;
				if ($kursa_grupas==true)
					{$write=1;echo "<br>kursam ir grupas";} 
					else {$write=0;		echo "<br>kursam nav grupu";}
				
				if ($write==1)
					{	//2.lielakā iekava	
					//ta ka ir grupas, tad notiks studentu ieklasificēsana grupās
					$aclg=array();
					$ald=array();
					$result=array();
					$stud=array();
			//veido aclg nem datus no clg tabulas
//echo "<br/>";
//echo "<pre>";
//print_r($kursa_grupas);
//echo "</pre>";
						$pk = $DB->get_record('v_adaptation_features', array('feature'=>'pk'));// izvelk pazīmes id
						$dl = $DB->get_record('v_adaptation_features', array('feature'=>'dl'));// izvelk pazīmes id
						$ls = $DB->get_record('v_adaptation_features', array('feature'=>'ls'));// izvelk pazīmes id
						//echo "<br>pkid= ".$pk->id;
						//echo "<br>pkid= ".$dl->id;
						//echo "<br>pkid= ".$ls->id;
$k=1;				
for ($i=1;$i<=$grupu_skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br>kursa_grupas->group_number= ".$kursa_grupas[$i]->group_number;//ir
			//pec grupas numura jaapanem
						//mas
						$visas_pazimes = $DB->get_records('v_clg_description', array('clgid'=>$kursa_grupas[$i]->group_number));// izvelk šis grupas pazīmes
						//echo "<pre>";
						//print_r($visas_pazimes);
						//echo "</pre>";
						$pazimju_skaits=count($visas_pazimes);//ir
						//echo "<br>pazimju skaits= ".$pazimju_skaits;
						for($j=1;$j<=$pazimju_skaits;$j++)
						{
						//echo "<br><br>pazimes id= ".$visas_pazimes[$k]->adaptation_features_valueid;
						
						$v2 = $DB->get_record('v_adaptation_features_values', array('id'=>$visas_pazimes[$k]->adaptation_features_valueid)); //izvelk pazīmes, veertības id
						//echo "<br>featureid= ".$v2->featureid;
						//echo "<br>feature value= ".$v2->value;
						
						if ($v2->featureid==$pk->id) $aclg[$i-1][0]=$v2->value;
						if ($v2->featureid==$dl->id) $aclg[$i-1][1]=$v2->value;
						if ($v2->featureid==$ls->id) $aclg[$i-1][2]=$v2->value;
		
						$k++;}//for pa j
			
}//for lielais	

//parbaudei izvads
echo "<br>aclg izvads<br>";
for ($i=0;$i<30;$i++){
			echo "N ".($i+1)." ".$aclg[$i][0]." ".$aclg[$i][1].' '. $aclg[$i][2].'<br/>';
}
	
			
$coursestudents=array();			 
//tas bija no lielā 
//$coursestudents = $DB->get_records_sql($sql, null, IGNORE_MISSING);
$course = $DB->get_record('course', array('id'=>$courseid), '*', MUST_EXIST);
$context = context_course::instance($course->id, MUST_EXIST);
//echo "<pre>";
//print_r($context);
//echo "</pre>";

$coursestudents = get_role_users(5, $context);
//---------------------

//echo "<pre>";
//print_r($coursestudents);
//echo "</pre>";

			//masiiva ald aizpildiisana, dati par apmācāmo
//nem studentu un tad visas vajadziigaas ipasiibas
echo "<br/>";
//sadi dabuuju studentu id
$skaits=0; //studentu skaits
echo "<H4>Kursa studenti:</H4>";
	foreach ($coursestudents as $id => $student) {
					//echo "id= ".$student->id."<br/>";
					$stud[$skaits]=$student->id;
					
					echo "n= ".$skaits." "." id= ".$stud[$skaits]."<br/>";
					$skaits++;}//cikla aizversana
					
		//jau pasa masiiva ald aizpildiisana
			$p=0;//varbuut nevajag
$vai_dati=array();
	for ($i=0;$i<$skaits;$i++){
			//panem vienu rindinu ar datiem no db
			//echo "<br><br>Darbiiba studentam ".$stud[$i];
$rez1 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$stud[$i]),'userid','userid,preknow'); 
$rez2 = $DB->get_records_menu('v_user_pedagogical_data',array('userid'=>$stud[$i]),'userid','userid,dlevel'); 
$rez3 = $DB->get_records_menu('v_user_personality_data',array('userid'=>$stud[$i],'property'=>'learningstyle'),'userid','userid,value');


//echo "<br>Triju masiivu izdruka";
//echo "<br>";
//print_r($rez1);echo "<br>";
//print_r($rez2);echo "<br>";
//print_r($rez3);echo "<br>";
			if (!empty($rez1)&& !empty($rez3))
			{$vai_dati[$i]=1;
			//echo "<br>vai_dati[i]=".$vai_dati[$i];
						
			//echo "<br>"; print_r($rez1);
			//echo "<br>pk=".($rez1[$stud[$i]]);
			//echo "<br>dl=".($rez2[$stud[$i]]);
			//echo "<br>style=".($rez3[$stud[$i]]);
			$ald[$i][0]=$stud[$i];
			$ald[$i][1]=$rez1[$stud[$i]];
			$ald[$i][2]=$rez2[$stud[$i]];
			$ald[$i][3]=$rez3[$stud[$i]];
			//echo "<br>Dati ierakstiiti masiivaa";
			} 
		else {echo "<br>".$stud[$i]." nav izieta testēšana vai nav atjaunināti dati!";
				$vai_dati[$i]=0;$p++;
				//echo " vai_dati[i]=".$vai_dati[$i];
				}
		
}//for masiivs ald aizpildīts	
//echo "<br/>";
//echo "<pre>";
//print_r($ald);
//echo "<pre>";
					
			//tad aclg un ald masiivu saliidzinasana
			if (!empty($ald))
			{
$temp=array();

//-----------------
//print_r($vai_dati);
//echo "<br>atdala<br>";
//for ($a=0;$a<$skaits;$a++) echo $vai_dati[$a]." ";


//echo "talak iet if";
	if (!empty($vai_dati)) 
	{//ir vismaz viens ko klasificēt
for($ii=0;$ii<$skaits;$ii++)			
{
	//echo "<br>vai dati= ".$vai_dati[$ii];
	if ($vai_dati[$ii]==1)
	{
	
			for($j=0;$j<30;$j++){
			$csum=0;
			//echo "<br>ald mas= ".$ald[$ii][1]." aclg mas= ".$aclg[$j][0];
				if ($ald[$ii][1]==$aclg[$j][0]) $csum++;	
				if ($ald[$ii][2]==$aclg[$j][1]) $csum++;
				if ($ald[$ii][3]==$aclg[$j][2]) $csum++;
			//echo "<br>csum= ".$csum." ";
			$temp[$j]=$csum;
			}
$result[$ii]=max($temp); $m=array_search(max($temp), $temp);
//echo "<br>result sum= ".$result[$ii]." ";
if ($result[$ii]==3) {
		//ieraksta datus masiivaa clg_members
				//DB tabulas "clg_members" aizpildisana
	//vai taads user ir tabulaa
		$rez5 = $DB->get_records_menu('v_clg_members',array('userid'=>$ald[$ii][0]),'userid','userid,group_number');
		if (empty($rez5))	
					{echo "<br>User= ".$ald[$ii][0]."piešķirta grupa= ".($m+1)." dati ierakstīti tabulā!";
						$record = new stdClass();
						$record->userid=$ald[$ii][0];
						$record->group_number=$m+1;
						$table='v_clg_members';
						$lastid=$DB->insert_record($table, $record);
				} else echo "<br/>User ".$ald[$ii][0]." grupa= ". ($m+1)." ir jau piešķirta grupa!";
			}
	}//if 
	}//for $ii
	} //else echo "Nav studentu, ko ieklasificēt grupās!";
} //if not empty
}//write==1

}
*/
//--------------------------------------------------------------------fja
public function general(){
	global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];
$userid=$USER->id;

//$blockinstance= new block_tmm();
			//echo "edit=".$USER->editing;
			if ($this->user_rights()==1)  
				{
				//vai dati par kursu ir?
				$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));								
				if (empty($re)) { echo "<br><h5>Skolotāja modulis:</h5>";
								//forma kursa parametru ievadei ar funkciju
								$this->course_parametrs();
								}//if empty
									//else echo "<br>Dati par kursu aizpildīti";
				//$blockinstance->visible_first_section();
				}//user_rights
				else 
				{//echo "<br><h5>Studenta modulis:</h5>";
				
				
				$this->topic_choice();	
				
				}//studenta modulis	
}
//-------------------------------------------------------------------fja
public function next_topic(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$visivarianti=$lerndata->topic_choices_variants;
$tsp=$this->last_number($visivarianti);
$ko=','.$tsp;
$tsvbezpedeja=str_replace($ko,'',$visivarianti);
$tspp=$this->last_number($tsvbezpedeja);
	$param = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
	$tts=$param->teacher_topic_sequence;
		//echo "Teacher topic_sequence=".$param->teacher_topic_sequence;
		//print_r($tts);
	$ts=$lerndata->topic_sequence;
	$ots=$lerndata->user_ots;
	//$st=$this->temas_pec_saites();
	
	$ptema=$this->last_number($ts);
	
	//$ttsskaits=strlen($param->teacher_topic_sequence);
	//$tsskaits=strlen($lerndata->topic_sequence);
	//$otsskaits=strlen($lerndata->user_ots);
	$ttsarray = explode(",", $tts); 
	$tsarray = explode(",", $ts); 
	$otsarray = explode(",", $ots);
	
	$ttsskaits=sizeof($ttsarray);
	$tsskaits=sizeof($tsarray);
	$otsskaits=sizeof($otsarray);
//fikseet parejas
	$rez=array();
	//echo "<br>tts";print_r($tts);
	//echo "<br>ptema";print_r($ptema);
	//if ($displaysection==$ptema)
	
	if ($tsp==1 and ($tspp==1 or empty($tspp))){
					for ($i=0;$i<$ttsskaits && $ttsarray[$i]!=$ptema;$i++);   
					$next_topic=$ttsarray[$i+1];
					//echo "<br>nexttopic=".$next_topic;
				}			
	if (($tsp==2 and $tspp==2) or ($tsp==2 and empty($tspp)) or 
		($tsp==2 and $tspp==1)){
					//echo "<br>Vai liidz sejienei nonaak! 387 rindina";
					$next_topic=$this->temas_pec_saites();
				}
	if ($tsp==3 and ($tspp==3 or empty($tspp))){
					for ($i=0;$i<$otsskaits && $otsarray[$i]!=$ptema;$i++);   
					$next_topic=$otsarray[$i+1];
				}
	if ($tsp==1 and ($tspp==2 or $tspp==3)) {
	//varbuut kluda
					$b=0;$a=0;
					for ($i=0;$i<$ttsskaits&& $b==0;$i++)
					{	$k=0;
						for ($j=0;$j<$tsskaits;$j++)
							if ($ttsarray[$i]==$tsarray[$j]) $k=1;
						if ($k==0) 	{$rez[$a]=$ttsarray[$i];$a++;$b=1;}
						
					}$next_topic=$rez[0];
				}
	if ($tsp==3 and ($tspp==1 or $tspp==2)) {
					
					//echo "<br>ots=".$ots;
					//echo "<br>ts=".$ts;
					//echo "<br>otsskaits=".$otsskaits;
					//echo "<br>tsskaits=".$tsskaits;
					$b=0;$a=0;
					for ($i=0;$i<$otsskaits&& $b==0;$i++)
					{	$k=0;
						for ($j=0;$j<$tsskaits;$j++)
							{if ($otsarray[$i]==$tsarray[$j]) $k=1;
							//echo "<br>otsarray[".$i."]= ".$otsarray[$i];
							//echo "<br>tsarray[".$j."]= ".$tsarray[$j];
							}
						if ($k==0) 	{$rez[$a]=$otsarray[$i];$a++;$b=1;
						//echo "<br>rez[".($a-1)."]= ".$rez[$a-1];
						}
					}$next_topic=$rez[0];
				}			
return $next_topic;
}
//-------------------------------------------------------------------fja
public function write_topic_sequence($displaysection){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
//ierakstiit tabulaa next topic
	$v=0;
	//panemt kada seciiba izveeleta, ja 1,3 tad raksta, 
	$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$tchoice=$this->last_number($lerndata->topic_choices_variants);
	if ($tchoice==1 || $tchoice==3 )
			{$v=1;
			$ntopic=$this->next_topic();
			//echo "<br>ntopic=".$ntopic;
				}

	if ($tchoice==2 && $this->vai_si_tema_ierakstiita($displaysection)==0) {$v=1;$ntopic=$displaysection;}
	//if ($displaysection==1) break;	
	
	if ($v==1){
	$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$alltopic=$lerndata->topic_sequence.','.$ntopic;
						//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_sequence=$alltopic;
						$sql = $DB->update_record('v_user_learning_data', $record2);}


}
//-------------------------------------------------------------------fja
/*
public function write_topic_choice(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
								//panemts no write_GRADE
//panemt izieto temu skaitu
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (empty($lerndata->topic_sequence)) $tssum=0;
						else $tssum=substr_count($lerndata->topic_sequence,',')+1;
//echo "<br>tssum= ".$tssum;
//panemt atziimju skaitu
if (empty($lerndata->topic_grade)) $tchsum=0;
						else $tchsum=substr_count($lerndata->topic_choices_variants,',')+1;
//echo "<br>tgsum= ".$tgsum;
//salidzinaat
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if ($tssum-$tchsum==1){//pievieno
						$alltcv=$lerndata->topic_choices_variants.','.$this->last_number($lerndata->topic_choices_variants);}
if ($tssum-$tchsum==0){//aizvieto
						//iznem pedejo un pievieno citu ka pedejo
							$tchoice=$this->last_number($lerndata->topic_choices_variants);
							$skaits1=strlen($lerndata->topic_choices_variants);
							$skaits2=strlen($tchoice);
							$tcv=$lerndata->topic_choices_variants;
							$k=0;
							for($i=$skaits1;$i>0 && $tcv[$i]!=',';$i--);//{echo "204 ";}
							for($j=$i+1;$i<$skaits1+$skaits2;$j++)
									{$tcv[j]=$tchoice[$k];$k++;}
										echo "<br>jauna tcv= ".$tcv;
							$alltcv=$tcv;
							}
						
						//rezultaatu ieraksta DB
						//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_choices_variants=$alltcv;
						$sql = $DB->update_record('v_user_learning_data', $record2);
}
*/
//-------------------------------------------------------------------fja
public function write_topic_grade2($displaytopic){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

//panemt izieto temu skaitu
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (empty($lerndata->topic_sequence)) $tssum=0;
						else $tssum=substr_count($lerndata->topic_sequence,',')+1;
//echo "<br>tssum= ".$tssum;
//panemt atziimju skaitu
if (empty($lerndata->topic_grade)) $tgsum=0;
						else $tgsum=substr_count($lerndata->topic_grade,',')+1;
//echo "<br>tgsum= ".$tgsum;
//salidzinaat

if ($tssum-$tgsum==1){
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (empty($lerndata->topic_grade)) {$allgrades=round($tatzime,2);}
				else {$allgrades=$lerndata->topic_grade.','.round($tatzime,2);}
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_grade=$allgrades;
						$sql = $DB->update_record('v_user_learning_data', $record2);

}
						/*
						//ja nemainija izveli seciibas
						//panem pedejo un pievienot
						$ped_tcv=$this->last_number($lerndata->topic_choices_variants);
						$new_tcv=$lerndata->topic_choices_variants.','.$ped_tcv;
						
						//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_choices_variants=$new_tcv;
						$record2->topic_grade=$allgrades;
						$sql = $DB->update_record('v_user_learning_data', $record2);}}*/
}
public function write_topic_grade($displaytopic){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

//temai indeksuu
//pec indeksa atziimi
//ja nav atziimes, paarbauda meg, ja bija ieliek atziimi

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$izietas_temas=$lerndata->topic_sequence;
$iz_temas = explode(",", $izietas_temas);
$skaits=sizeof($iz_temas);
//echo "<br>------------------- write_topic_grade temas = ";
for ($i=0;$i<$skaits && $iz_temas[$i]!=$displaytopic;$i++)
	{//echo $iz_temas[$i]." ";
	}
$tindex=$i;
//echo "<br>temuas index=".$tindex;//+	 

$iegutas_atzimes=$lerndata->topic_grade;
//varbiit paarbaudi pirms ieraksta
//echo "<br>lerndata->topic_sequence= ".$lerndata->topic_sequence;
//echo "<br>lerndata->topic_grade= ".$lerndata->topic_grade;
$ieg_atzimes = explode(",", $iegutas_atzimes);
//ja atzimes veel nav, tad index neder
//garumus paarbaudiit
//visu atziimju skaits
$ieg_atzimes_skaits=sizeof($ieg_atzimes);
if ($tindex<$ieg_atzimes_skaits)
$atzimepecindex=$ieg_atzimes[$tindex]; else $atzimepecindex=null;
//
//echo "<br>Funkcija -------------write_topic_grade--- atzime pec indeksa= ".$atzimepecindex." tindex= ".$tindex;

//ja nav atziimes
if ($atzimepecindex==null) 
	{
	$testa_nosaukums=$this->testa_nosaukums($displaytopic);
	$quiz = $DB->get_record('quiz', array('course'=>$courseid,'name'=>$testa_nosaukums));
	$quiz_attempt = $DB->get_record('quiz_attempts', array('quiz'=>$quiz->id,'userid'=>$userid,'attempt'=>'1'));
	$tatzime=$quiz_attempt->sumgrades;
	

/*	
//panemt izieto temu skaitu
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (empty($lerndata->topic_sequence)) $tssum=0;
						else $tssum=substr_count($lerndata->topic_sequence,',')+1;
//echo "<br>tssum= ".$tssum;
//panemt atziimju skaitu
if (empty($lerndata->topic_grade)) $tgsum=0;
						else $tgsum=substr_count($lerndata->topic_grade,',')+1;

if ($tssum-$tgsum==1){
*/
//ierakstiit
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
if (empty($lerndata->topic_grade)) {$allgrades=round($tatzime,2);}
				else {$allgrades=$lerndata->topic_grade.','.round($tatzime,2);}
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_grade=$allgrades;
						$sql = $DB->update_record('v_user_learning_data', $record2);

}
						
}
//-------------------------------------------------------------------fja
public function last_number($s){
					//echo "<br>s= ".$s;
					$skaits=strlen($s);
					$rez=array();
					//echo "<br/>skaits=".$skaits;
					for ($i=$skaits-1;$i>=0 && $s[$i]!=',';$i--);
							$j=0;
					for ($i=$i+1;$i<$skaits;$i++)
								{$rez[$j]=$s[$i];
								$j++;}
					//echo "<pre>";
					//print_r($rez);
					//echo "</pre>";
					$skaitlis=implode($rez);	
return $skaitlis;
}
//-------------------------------------------------------------------- fja
public function last_recorded_topic(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

//panem temas numuru 
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));	
if (!empty($lerndata)) {
$temu_seciiba=$lerndata->topic_sequence;
$tema_num=$this->last_number($temu_seciiba);}
	else $tema_num=0;
return $tema_num;
}

//-------------------------------------------------------------------- fja
public function quiz_grade($tema_num){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
	
	//$tema_num=$this->topic_number_current();
$testa_nosaukums=$this->testa_nosaukums($tema_num);
	
	//echo "<br>Testa numurs= ".$testa_nosaukums;
	//panemt no user_learning_data topica numuru
	$quiz = $DB->get_record('quiz', array('course'=>$courseid,'name'=>$testa_nosaukums));
	$quiz_attempt = $DB->get_record('quiz_attempts', array('quiz'=>$quiz->id,'userid'=>$userid));	
	return $quiz_attempt->sumgrades;
	}
//------------------- -----------------------------------------------fja
public function course_parametrs(){
	global $USER, $DB;
	$tmminstance=$_SESSION['tmminstance'];
	$courseid=$_SESSION['courseid'];	
	$userid=$USER->id;
	//kursa parametri
	//unset($_POST);$_POST = array();
	
			echo '<table border="0" style="font-size: 14px; background-color:#f5f5f5; vertical-align: bottom;">';
			echo '<form action='.$_SERVER["PHP_SELF"].'?id='.$courseid.'&section=1 method="POST">';
			//echo '<form action='.$_SERVER["PHP_SELF"].'?id='.$courseid.' method="POST">';
			echo '<tr>
					<td> <label id ="a1" >Ievadiet skolotāja tēmu secību (piem.: 1,2,3):</label></td>';
			echo '<td><input type="text" name="ts"  id="ts" size="6px"  /></td></tr>';
			echo '<tr>
					<td> <label id ="a2" >Ievadiet saites starp tēmām (piem.; 1:2,3,5;2:3,5):</label></td>';
			echo '<td><input type="text" name="tl"  id="tl" size="6px"  /></td></tr>';
			echo '<tr><td></td><td align="right"><input type="submit" name="submit" value="Go!" id="go" />';
			echo '	</td></tr></form> </table>'; 

			//sanemt datus un ierakstiit tabulaa
			if(isset($_POST['submit']))
								{
								//datu piešķirsana
								$tsequence=$_POST['ts'];
								$topiclink=$_POST['tl'];
								//echo "<br>tsequence= ".$tsequence;
								//echo "<br>topiclink= ".$topiclink;
								//paarbaudiit vai tabulaa ir
							//echo "<br>course=".$courseid;
								$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));								
								if (empty($re)) 
											{//ierakstiit tabulaa
											//pirmo reizi dati tiek ierakstiiti
											$record1 = new stdClass();
											$record1->courseid=$courseid;
											$record1->topic_link=$topiclink;
											$record1->optimal_topic_sequence=$tsequence;
											$record1->teacher_topic_sequence=$tsequence;
											$lastid=$DB->insert_record('v_course_teaching_parametrs', $record1);
											//echo "<br/>Dati ierakstīti tabulā"; 
											}//empty
											else echo "<br/>Dati jau ir";
						
			}//submit
}//fja	
	
//------------------- ------------------------------------------fja		
public function visible_first_section() {
global $CFG, $OUTPUT;
		global $USER, $DB;
		global $SESSION, $PAGE;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$allsections = $DB->get_records_menu('course_sections',array('course'=>$courseid),'id','id,section');
//print_r($allsections);

foreach ($allsections as $key => $value)
		{ //echo "<br>key=".$key. ' value='.$value;
		if ($value>1){//buus update
				//$record = new stdclass; 	//$record->id=$key; //$record->visible=1; //$sql = $DB->update_record('course_sections', $record); 
				//sis variants labaak, sistema to saprot labaak;
				set_section_visible($courseid, $value, 1);
				}
		}	
}

//------------------- ------------------------------------------fja		
public function topic_choice() {
//ieraksta temas seciibas variantu 
		global $CFG, $OUTPUT;
		global $USER, $DB;
		global $SESSION, $PAGE;
$displaysection=$_SESSION['displaysection'];			
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
	
		//parbaudes
$peddata = $DB->get_record('v_user_pedagogical_data', array('userid'=>$userid,'courseid'=>$courseid));
$personalitydata = $DB->get_record('v_user_personality_data', array('userid'=>$userid,'property'=>'learningstyle'));
 if (empty($personalitydata)) {	$pd=" un tests \"VARK3\"";} else $pd="";
					if (empty($peddata)) {	
					echo "<br>Lai izmantotu adaptīvu kursu, Jums jāizpilda tests \"Course Data\"".$pd."!";}
else { //ir ped dati beidzas fijas beigaas
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
							//nolasiit temu secību vai tabulaa v_user_learning_data ir ieraksts par studentu
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
					$m=0;
					if (empty($lerndata)) {
						//javeido ieraksts tabulaa par so studentu
						$record1 = new stdClass();
						$record1->userid=$userid;
						$record1->courseid=$courseid;
						$record1->user_ots=$re->optimal_topic_sequence;
						$record1->topic_choices_variants=1;
						$record1->topic_sequence=1;
						$lastid=$DB->insert_record('v_user_learning_data', $record1);
						$tchoice=1;
						//$tsequence=0;
						$m=1;
						} 
		if (isset($_POST['submit'])) {$tchoice=$_POST['sequence'];
										unset($_POST);$_POST = array();
										}
							else {
							if ($m==1) $tchoice=1; else 
										$tchoice=$this->last_number($lerndata->topic_choices_variants);}
							
					$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));			
					if (empty($lerndata->topic_sequence)) $tssum=0;
											else $tssum=substr_count($lerndata->topic_sequence,',')+1;
					//echo "<br>tssum= ".$tssum;
					//panemt atziimju skaitu
					if (empty($lerndata->topic_choices_variants)) $tcsum=0;
											else $tcsum=substr_count($lerndata->topic_choices_variants,',')+1;
					//echo "<br>tgsum= ".$tcsum;
					//salidzinaat
					
					//--------------
					
					if ($tssum-$tcsum==1){
					//buus ieraksts ar pievienosanu
							$newtc=$lerndata->topic_choices_variants.','.$tchoice;}
					if ($tssum-$tcsum==0){
								if ($tcsum==1 && $tssum==1)
								{$newtc=$tchoice;}
								else{
					//buus ieraksts ar aizvietosanu
							//iznem pedejo un pievieno citu ka pedejo
							//$lastchoice=$this->last_number($lerndata->topic_choices_variants);
							$skaits1=strlen($lerndata->topic_choices_variants);
							$skaits2=strlen($tchoice);
							$tcv=$lerndata->topic_choices_variants;
							//echo "<br>Skaits1= ".$skaits1;
							for($i=$skaits1-1;$i>0 && $tcv[$i]!=',';$i--);
							$k=0;
							for($j=$i+1;$j<$i+1+$skaits2;$j++)
									{$tcv[$j]=$tchoice[$k];$k++;}
										//echo "<br>jauna tcv= ".$tcv;
							$newtc=$tcv;
							} //else
							//echo "<br>jauna tcv= ".$newtc;
							}//summu starpiba=0
						
						//rezultaatu ieraksta DB
						//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_choices_variants=$newtc;
						$sql = $DB->update_record('v_user_learning_data', $record2);
							//----------------------
							
					//------------------	
					//izvadam paarveidosana
						//nosaliit no tabulas
						$dlevel=$peddata->dlevel;
						//$tchoice=$newtc;
	//$lerndata2 = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
						//$tchoice=$lerndata2->topic_choices_variants;
						//vajag pedejo izveeli panemt
						$tchoice=$this->tsecibas_variants_pedejais();
						/*
						if ($tchoice==1) $iztchoice='Skolotāja';
						if ($tchoice==2) $iztchoice='Studenta';
						if ($tchoice==3) $iztchoice='Optimālā';
						if ($dlevel==1) $izdlevel='Zems';
						if ($dlevel==2) $izdlevel='Vidējais';
						if ($dlevel==3) $izdlevel='Augstākais';*/
						if ($tchoice==1) $iztchoice='Teacher';
						if ($tchoice==2) $iztchoice='Learner';
						if ($tchoice==3) $iztchoice='Optimal';
						if ($dlevel==1) $izdlevel='Low';
						if ($dlevel==2) $izdlevel='Medium';
						if ($dlevel==3) $izdlevel='High';
//izveles izvads
		/*echo '<table border="0" style="font-size: 14px; background-color:#f5f5f5; vertical-align: bottom;">
		<tr ><td></td></tr >
		<tr >
			<td>Your choice: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;topic sequence</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';*/
		echo '<table border="0" style="font-size: 14px; background-color:#f5f5f5; vertical-align: bottom;">
		<tr ><td></td></tr >
		<tr >
			<td>Jūsu izvēle: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tēmu secība:</td>
			<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>';
		echo '<form name="form2" id="form2" method="POST"  >';
		//echo '<form action='.$_SERVER["PHP_SELF"].'?id='.$courseid.' method="POST">';
		echo '<td><input type="text" name="izsequence"  value="'.$iztchoice.'" id="izsequence" size="6px" readonly="readonly"  /></td>';
		/*echo '<td>&nbsp;&nbsp;&nbsp;level of acquisition</td>
			<td>&nbsp;&nbsp;&nbsp;</td>';*/
		echo '<td>&nbsp;&nbsp;&nbsp;kursa apguves grūtības pakāpe:</td>
			<td>&nbsp;&nbsp;&nbsp;</td>';	
		echo '<td><input type="text" name="izdlevel"  value="'.$izdlevel.'" id="izdlevel" size="6px" readonly="readonly"  /></td>
		</form> ';
		echo '	</td>
			</tr>
		</table>';
		
	//else {
			/*echo '<table border="0" style="font-size: 14px" >
			<tr >
				<td>Change course topic sequence: </td>
				<td>&nbsp;&nbsp;&nbsp;</td>
				<td>';*/
			echo '<table border="0" style="font-size: 14px" >
			<tr >
				<td>Nomainīt kursa tēmu secību: </td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td>';
//$displaysection=2;
				//seciibas izveele
			/*echo '<form action='.$_SERVER["PHP_SELF"].'?id='.$courseid.'&section='.$displaysection.' method="POST">'.
					'<select size="1" height="1" name ="sequence" id="sequence" onchange="sequenceapstrade(this.form.elements[0])" >'.
						'<option value="0" selected>Choice</option>
						<option value="1">Teacher</option>
						<option value="2">Learner</option>
						<option value="3">Optimal</option>
					</select></td>';
			echo '<td>&nbsp;&nbsp;&nbsp;</td>
				<td> <label id ="al" style="visibility:hidden;">level of acquisition: </label></td>
				<td>&nbsp;&nbsp;</td>';
			echo '<td><input type="text" name="dlevel"  value="'.$izdlevel.'" id="dlevel" size="6px" readonly="readonly" style="visibility:hidden;" /></td>
				<td>&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Go!" id="go" style="visibility:hidden;" /></form> ';*/
				
				//latviski
			echo '<form action='.$_SERVER["PHP_SELF"].'?id='.$courseid.'&section='.$displaysection.' method="POST">'.
					'<select size="1" height="1" name ="sequence" id="sequence" onchange="sequenceapstrade(this.form.elements[0])" >'.
						'<option value="0" selected>Izvēle</option>
						<option value="1">Teacher</option>
						<option value="2">Learner</option>
						<option value="3">Optimal</option>
					</select></td>';
			echo '<td>&nbsp;&nbsp;&nbsp;</td>
				<td> <label id ="al" style="visibility:hidden;">&nbsp;kursa apguves grūtības pakāpe:</label></td>
				<td>&nbsp;&nbsp;</td>';
			echo '<td><input type="text" name="dlevel"  value="'.$izdlevel.'" id="dlevel" size="6px" readonly="readonly" style="visibility:hidden;" /></td>
				<td>&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="Izpildīt!" id="go" style="visibility:hidden;" /></form> ';	
			echo '	</td>
				</tr>
			</table>'; 
//}//3isset

 

}//ja vajadziigie dati ir notiek apmaciba
	
}//fias izvads beigas

// -------------------------------------                fja lietotaja tiesiibu iegusanai ----------------------------
public	function user_rights(){
//tas liekams uz fju
global $CFG;
global $COURSE;
global $DB;
global $USER;
//14.01.2017
//$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
//1. lomas id meklesana
$rez1=array();
$s1=	'manager';		
$rez1 = $DB->get_records_menu('role',array('shortname'=>$s1),'id','shortname,id'); 
		$manid=$rez1[$s1];
$rez2=array();		
$s2=	'coursecreator';		
$rez2 = $DB->get_records_menu('role',array('shortname'=>$s2),'id','shortname,id'); 
		$ccid=$rez2[$s2];
$rez3=array();		
$s3=	'editingteacher';		
$rez3 = $DB->get_records_menu('role',array('shortname'=>$s3),'id','shortname,id'); 
		$etid=$rez3[$s3];
		
$s4=	'teacher';	
$rez4=array();	
$rez4 = $DB->get_records_menu('role',array('shortname'=>$s4),'id','shortname,id'); 
		$tid=$rez4[$s4];

//print_r($DB->get_record('role', array('id'=>$CFG->guestroleid))); 
		
//useram kada loma
//(SELECT userid FROM {$CFG->prefix}role_assignments WHERE (roleid='$role_student'))))
$userid=$USER->id;
//echo "<br>Jūsu userid = ".$userid;

//-----------------------------------------
//izvelk kursam context id
//echo "<br>courseid= ".$courseid;
$course_context_id = $DB->get_records_menu('context',array('instanceid'=>$courseid,'contextlevel'=>CONTEXT_COURSE),'id','instanceid,id'); 
$cci=$course_context_id[$courseid];

// no tabulas role_assignments
$sql="SELECT
			ra.id,
			ra.roleid,
			ra.contextid
			FROM
				 mdl_role_assignments ra
			WHERE
			ra.userid = '$userid'
			 ORDER BY ra.contextid";
$result=array();			
$results = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($results);
//echo "</pre>";
		$z=0;
		foreach ($results as $id => $record) {
				if ($record->contextid==$cci) {$userrol=$record->roleid; 
											$z=1; break;}
											}

if ($z==1) $userrole=$userrol; 
	else if ($z==0) $userrole=$manid; else $userrole=$record->roleid; //lai admin vareetu
//echo "<br>userrole=".$userrole;

if ($userrole==$manid || $userrole==$ccid || $userrole==$etid || $userrole==$tid)
				{//echo "Ir";
				return 1;} else 
								{//echo "Nav";
								return 0;}
}
//------------------- ------------------------------------------fja		
//block contents
public function get_content() {
        global $CFG, $OUTPUT;
		global $USER, $DB;
		global $SESSION, $PAGE;
	
$_SESSION['tmminstance']=$this->instance->id;
$_SESSION['courseid']=$this->page->course->id; 
$tmminstanceid=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
        if ($this->content !== null) {
            return $this->content;
        }

        if (empty($this->instance)) {
            $this->content = '';
            return $this->content;
        }

        $this->content = new stdClass();
        $this->content->items = array();
        $this->content->icons = array();
        $this->content->footer = '';

        // user/index.php expect course context, so get one if page has module context.
        $currentcontext = $this->page->context->get_course_context(false);

        if (! empty($this->config->text)) {
            $this->content->text = $this->config->text;
        }

        $this->content = '';
        if (empty($currentcontext)) {
            return $this->content;
        }
        if ($this->page->course->id == SITEID) {
            $this->context->text .= "site context";
        }

        if (! empty($this->config->text)) {
            $this->content->text .= $this->config->text;
        }
		//mans teksts
		// $this->content->items[] = html_writer::tag('a', 'Menu Option 1', array('href' => 'some_file.php'));
		 $this->content->items[] = html_writer::tag('a', 'Menu Option 1');
  //$this->content->icons[] = html_writer::empty_tag('img', array('src' => 'images/icons/1.gif', 'class' => 'icon'));
$this->content->text='';

//teksts boldaa $this->content->text= html_writer::tag('B', get_string('temp1', 'block_tmm'), array('class'=>'computer_released'));
$user_ir = $DB->get_records('user',array('id'=>$userid)); 
					if (!empty($user_ir)) {	$cgr="Exist";} else {$cgr="Not Exist";}
//$this->content->text.=$cgr;
//$this->content->text.=$this->title;
$this->content->text.="<br>For teachers</br>";
$this->content->text.='<ol>
	<li><a href="'.$CFG->wwwroot.'/blocks/tmm/ots.php">Create OTS</a>'.'</li>
							</ol>  ';
		$this->content->text.=" id=".$tmminstanceid;
		$this->content->text.=" cid= ".$courseid;
		return $this->content;
		
//no cita bloka
/*		
 if(is_siteadmin($USER->id) || isguestuser($USER->id)) {
            return $this->content;
        }

        if(isset($SESSION->exam_access_key)) {
            $this->content->text = html_writer::tag('B', get_string('computer_released', 'block_exam_actions'), array('class'=>'computer_released'));
            return $this->content;
        }

        if(!isset($SESSION->exam_user_functions)) {
            $SESSION->exam_user_functions = array();
        }

        $links = array();
        if(is_a($PAGE->context, 'context_course')) {
            if($PAGE->course->id == 1) {
                $links[1] = html_writer::link(new moodle_url('/blocks/exam_actions/release_computer.php'), get_string('release_this_computer', 'block_exam_actions'));
            } else {
                if(empty($SESSION->exam_user_functions) || in_array('student', $SESSION->exam_user_functions)) {
                    return $this->content;
                }
                if (has_capability('moodle/backup:backupactivity', $PAGE->context)) {
                    $links[5] = html_writer::link(new moodle_url('/blocks/exam_actions/export_exam.php', array('courseid'=>$PAGE->context->instanceid)),
                                                 get_string('export_exam', 'block_exam_actions'));
                }
                if (has_capability('moodle/course:managegroups', $PAGE->context)) {
                    $links[4] = html_writer::link(new moodle_url('/blocks/exam_actions/sync_groups.php', array('courseid'=>$PAGE->context->instanceid)),
                                                 get_string('sync_groups', 'block_exam_actions'));
                }
                $conduct = false;
                if ((has_capability('block/exam_actions:conduct_exam', $PAGE->context) && $PAGE->course->visible)) {
                    $links[1] = html_writer::link(new moodle_url('/blocks/exam_actions/generate_access_key.php', array('courseid'=>$PAGE->context->instanceid)),
                                                 get_string('generate_access_key', 'block_exam_actions'));
                    $conduct = true;
                }
                if ((has_capability('block/exam_actions:monitor_exam', $PAGE->context) && $PAGE->course->visible)) {
                    $links[2] = html_writer::link(new moodle_url('/blocks/exam_actions/monitor_exam.php', array('courseid'=>$PAGE->context->instanceid)),
                                                 get_string('monitor_exam', 'block_exam_actions'));
                }
                if ($conduct || in_array('editor', $SESSION->exam_user_functions)) {
                    $links[3] = html_writer::link(new moodle_url('/blocks/exam_actions/load_students.php', array('courseid'=>$PAGE->context->instanceid)),
                                                 get_string('load_students', 'block_exam_actions'));
                }
            }
        } else if(is_a($PAGE->context, 'context_user')) {
            if(in_array('editor', $SESSION->exam_user_functions)) {
                $links[2] = html_writer::link(new moodle_url('/blocks/exam_actions/remote_courses.php'), get_string('new_course', 'block_exam_actions'));
            }
            if(in_array('proctor', $SESSION->exam_user_functions)) {
                $links[1] = html_writer::link(new moodle_url('/blocks/exam_actions/generate_access_key.php'), get_string('generate_access_key', 'block_exam_actions'));
            }
            if(!empty($SESSION->exam_user_functions) && ! in_array('student', $SESSION->exam_user_functions)) {
                $links[6] = html_writer::link(new moodle_url('/blocks/exam_actions/review_permissions.php'), get_string('review_permissions', 'block_exam_actions'));
            }
        }

        if(!empty($links)) {
            ksort($links);
            $text = '';
            foreach($links AS $l) {
                $text .= html_writer::tag('LI', $l);
            }
            $this->content->text = html_writer::tag('UL', $text);
        }

        return $this->content;
    }		
		
		
		
*/		
    }
//<a href="http://www.w3schools.com/">Visit W3Schools</a>//
    // my moodle can only have SITEID and it's redundant here, so take it away
public function applicable_formats() {
//no cita bloka return array('my'=>true, 'course-view' => true, 'site' => true);       

	   return array('all' => false,
                     'site' => true,
                     'site-index' => true,
                     'course-view' => true, 
                     'course-view-social' => false,
                     'mod' => true, 
                     'mod-quiz' => false);
    }

public function instance_allow_multiple() {
          return true;
    }

    function has_config() {return false;}

public function cron() {
            mtrace( "Hey, my cron script is running" );
             
                 // do something
                  
                      return true;
    }
}
