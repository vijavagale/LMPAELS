<?php
// This file is part of Moodle - http://moodle.org/
defined('MOODLE_INTERNAL') || die();

/*
$observers = array(
    array(
        'eventname' => '\core\event\user_loggedin',
        'callback' => 'block_tmm_observer::user_loggedin',
    )
    ,
    array(
        'eventname' => '\core\event\course_viewed',
        'callback' => 'block_tmm_observer::course_viewed',
    ),
	array (
        'eventname' => '\core\event\course_viewed',
        'callback'  => 'block_tmm_observer::store',
        'internal'  => false, // This means that we get events only after transaction commit.
        'priority'  => 1000,
    ),*/
//=========================	
	
	
// List of observers.
/*$observers = array(

    array(
        'eventname'   => '\core\event\user_enrolment_deleted',
        'callback'    => 'mod_forum_observer::user_enrolment_deleted',
    ),

    array(
        'eventname' => '\core\event\role_assigned',
        'callback' => 'mod_forum_observer::role_assigned'
    ),

    array(
        'eventname' => '\core\event\course_module_created',
        'callback'  => 'mod_forum_observer::course_module_created',
    ),
);


$observers = array(
        array(
		'includefile' => '/blocks/tmm/classes/observer.php',
		'eventname' =>  '\core\event\user_loggedin',
		'callback'  =>  'rollingsync::login_sync',
	),
);*/