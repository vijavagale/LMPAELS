<?php
function get_resource($courseid, $resource_name) {
    global $DB, $CFG;
    $sql = "SELECT cm.id as cmid FROM {course_modules} cm, {resource} res
        WHERE res.name = '" . $resource_name . "'
        AND cm.course = " . $courseid . "
        AND cm.instance = res.id";
        

    if (! $coursemodule = $DB->get_record_sql($sql)) {

        $letters = range('A', 'Z');
        
        require_once($CFG->dirroot.'/course/lib.php');

        echo "\tCreate new resouces\n";

        foreach($letters as $key => $letter) {
            
            $course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
            // get module id
            $module = $DB->get_record('modules', array('name' => 'resource'), '*', MUST_EXIST);
            // get course section
            $cw = get_course_section(0, $course->id);
            $sectionid = $DB->get_record('course_sections', array('course' => $this->courseid, 'section' => $cw->id), '*', MUST_EXIST);
            
            $resource_data = new stdClass();
            $resource_data->course = $course->id;
            $resource_data->name = 'Files ' . strtoupper($letter);
            $resource_data->intro = '<p>'.'Files ' . strtoupper($letter).'</p>';
            $resource_data->introformat = 1;
            $resource_data->tobemigrated = 0;
            $resource_data->legacyfiles = 0;
            $resource_data->display = 0;
            $resource_data->displayoptions = 'a:2:{s:12:"printheading";i:0;s:10:"printintro";i:1;}';
            $resource_data->revision = 1;
            $resource_data->completion = 1;
            $resource_data->showavailability = 1;
            $resource_data->timemodified = time();

            $resource_id = $DB->insert_record('resource', $resource_data);

            // add course module
            $cm = new stdClass();
            $cm->course = $courseid;
            $cm->module = $module->id; // should be retrieved from mdl_modules
            $cm->instance = $resource_id; // from mdl_resource
            $cm->section = $sectionid->id; // from mdl_course_sections
            $cm->visible = 1;
            $cm->visibleold = 1;
            $cm->showavailability = 1;
            $cm->added = time();

            $cmid = $DB->insert_record('course_modules', $cm);

            // add module to course section so it'll be visible
            if ($DB->record_exists('course_sections', array('course' => $courseid, 'section' => 1))) {
                $sectionid = $DB->get_record('course_sections', array('course' => $courseid, 'section' => 1));

                // if sequence is not empty, add another course_module id
                if (!empty($sectionid->sequence)) {
                    $sequence = $sectionid->sequence . ',' . $cmid;
                } else {
                    // if sequence is empty, add course_module id
                    $sequence = $cmid;
                }

                $course_section = new stdClass();
                $course_section->id = $sectionid->id;
                $course_section->course = $courseid;
                $course_section->section = 1;
                $course_section->sequence = $sequence;
                $csid = $DB->update_record('course_sections', $course_section);

            } else {
                $sequence = $cmid;

                $course_section = new stdClass();
                $course_section->course = $courseid;
                $course_section->section = 1;
                $course_section->sequence = $sequence;

                $csid = $DB->insert_record('course_sections', $course_section);

            }

            // force clear module cache
            $modulecache = new stdClass();
            $modulecache->id = $courseid;
            $modulecache->sectioncache = 'NULL';
            $DB->update_record('course', $modulecache);
           
        } // foreach

        // get context again, this time with all resources present
        $context = get_resource($courseid, $resource_name);
        return $context;

    } else {
        
        $context = get_context_instance(CONTEXT_MODULE, $coursemodule->cmid);

        return $context;
    }


} // get_resource

?>