<?php
//defined('MOODLE_INTERNAL') || die();
global $CFG;
global $COURSE;
global $PAGE;
global $DB;
global $USER;

//start_session();
require_once($CFG->dirroot.'/config.php') ;
require_once($CFG->dirroot.'/lib/blocklib.php') ;
require_once($CFG->libdir .'/setuplib.php'); 
include_once($CFG->dirroot . '/course/lib.php');
include_once($CFG->libdir . '/coursecatlib.php'); 

$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

$instid= $_SESSION['instance'];
//echo "instance =".$instid;
		
// ------                fja kursa id iegusanai ----------------------------
		function get_courseid(){
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];

$instid= $_SESSION['instance'];
echo "instance =".$instid;
		
		//nav jau vajadziibas
global $CFG;
global $COURSE;
global $PAGE;
global $DB;
global $USER;
$block_name=(get_string('pluginname', 'block_learnerdata'));//tas strada

$block_record = $DB->get_record('block', array('name'=>$block_name)) ;
$rez_id = $DB->get_records_menu('context',array('instanceid'=>$instid),'id','instanceid,id'); 
$rez_path = $DB->get_records_menu('context',array('instanceid'=>$instid),'id','instanceid,path'); 
//echo "<br>rez_id= ".$rez_id[$instid];
//echo "<br>rez_path_ ".$rez_path[$instid];

$rez1=array();
$rez1=explode('/'.$rez_id[$instid],$rez_path[$instid] );
//echo "<pre>";
//print_r($rez1);
//echo "</pre>";
//echo "<br/>kk= ".$rez1[0];

//nem masiivu no otra gala mekle '/' un tad iet uz masiiva beigaam , ieguust pedejo skaitli
$skaits=strlen($rez1[0]);
$rez11=array();
//echo "<br/>skaits=".$skaits;
for ($i=$skaits-1;$i>=0 && $rez1[0][$i]!='/';$i--);
		$j=0;
for ($i=$i+1;$i<$skaits;$i++)
			{$rez11[$j]=$rez1[0][$i];
			$j++;}
//echo "<pre>";
//print_r($rez11);
//echo "</pre>";
$skaitlis=implode($rez11);	
//echo "<br/>skaitlis = ".$skaitlis;

$rez_clevel = $DB->get_records_menu('context',array('id'=>$skaitlis),'id','id,contextlevel');
$rez_instid = $DB->get_records_menu('context',array('id'=>$skaitlis),'id','id,instanceid'); 
//echo "<br>rez_clevel= ".$rez_clevel[$skaitlis];
//echo "<br>rez_instid= ".$rez_instid[$skaitlis];
	
	if ($rez_clevel[$skaitlis]==CONTEXT_COURSE)
	{//echo "<br/>Kursa id = ".$rez_instid[$skaitlis];
	return $rez_instid[$skaitlis];
	}
			else {//echo "<br/>Kursa id vēl neatrada!";
				return 0;
					}

/*
echo "<pre>";
print_r(context::instance_by_id(61));
echo "</pre>";
*/

} //fjas beigas

//------------------------------------------------------------------------------------------
// ------                fja lietotaja tiesiibu iegusanai ----------------------------
		function user_rights(){
//tas liekams uz fju
global $CFG;
global $COURSE;
global $DB;
global $USER;
$instanceid=$_SESSION['instance'];
$courseid=$_SESSION['courseid'];
//1. lomas id meklesana
$rez1=array();
$s1=	'manager';		
$rez1 = $DB->get_records_menu('role',array('shortname'=>$s1),'id','shortname,id'); 
		$manid=$rez1[$s1];
$rez2=array();		
$s2=	'coursecreator';		
$rez2 = $DB->get_records_menu('role',array('shortname'=>$s2),'id','shortname,id'); 
		$ccid=$rez2[$s2];
$rez3=array();		
$s3=	'editingteacher';		
$rez3 = $DB->get_records_menu('role',array('shortname'=>$s3),'id','shortname,id'); 
		$etid=$rez3[$s3];
		
$s4=	'teacher';	
$rez4=array();	
$rez4 = $DB->get_records_menu('role',array('shortname'=>$s4),'id','shortname,id'); 
		$tid=$rez4[$s4];

//print_r($DB->get_record('role', array('id'=>$CFG->guestroleid))); 
		
//useram kada loma
//(SELECT userid FROM {$CFG->prefix}role_assignments WHERE (roleid='$role_student'))))
$userid=$USER->id;
//echo "<br>Jūsu userid = ".$userid;

//-----------------------------------------
//izvelk kursam context id
//echo "<br>courseid= ".$courseid;
$course_context_id = $DB->get_records_menu('context',array('instanceid'=>$courseid,'contextlevel'=>CONTEXT_COURSE),'id','instanceid,id'); 
$cci=$course_context_id[$courseid];

// no tabulas role_assignments
$sql="SELECT
			ra.id,
			ra.roleid,
			ra.contextid
			FROM
				 mdl_role_assignments ra
			WHERE
			ra.userid = '$userid'
			 ORDER BY ra.contextid";
$result=array();			
$results = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($results);
//echo "</pre>";
		$z=0;
		foreach ($results as $id => $record) {
				if ($record->contextid==$cci) {$userrol=$record->roleid; 
											$z=1; break;}
											}
if ($z==1) $userrole=$userrol; else $userrole=$record->roleid; 
//echo "<br>userrole=".$userrole;
if ($userrole==$manid || $userrole==$ccid || $userrole==$etid || $userrole==$tid)
				{//echo "Ir";
				return 1;} else 
								{//echo "Nav";
								return 0;}
							
}

?>