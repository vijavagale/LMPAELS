<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<a href='javascript:window.history.go(-1);'>Atpakaļ uz Kursu</a>
<?php

require_once("../../config.php") ;
//require_once($CFG->libdir . '/pagelib.php');
require_once("my_lib.php") ;
//require_once('block_tmm.php');
global $CFG;
global $COURSE;
global $DB;
global $USER;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;


require_login();
function cmp($a, $b){
if($a['skaits'] == $b['skaits']){
  if($a['tema'] == $b['tema']){
   return 0;
  }
  elseif($a['tema'] < $b['tema']){
   return -1;
  }
  elseif($a['tema'] > $b['tema']){
   return 1;
  }
}
elseif($a['skaits'] > $b['skaits']){
  return -1;
}
elseif($a['skaits'] < $b['skaits']){
  return 1;
}
}
//--------------------------------
function multiSort() { 
    //get args of the function 
    $args = func_get_args(); 
    $c = count($args); 
    if ($c < 2) { 
        return false; 
    } 
    //get the array to sort 
    $array = array_splice($args, 0, 1); 
    $array = $array[0]; 
    //sort with an anoymous function using args 
    usort($array, function($a, $b) use($args) { 

        $i = 0; 
        $c = count($args); 
        $cmp = 0; 
        while($cmp == 0 && $i < $c) 
        { 
            $cmp = strcmp($a[ $args[ $i ] ], $b[ $args[ $i ] ]); 
           // if ($args[$i]='skaits') {$cmp=skaitssort($a[ $args[ $i ] ], $b[ $args[ $i ] ]);
			//if ($args[$i]='tema') $cmp=temasort3($a[ $args[ $i ] ], $b[ $args[ $i ] ]);}
			if ($args[$i]='skaits' && $cmp<0) $cmp=1;
				//if ($args[$i]='skaits' && $cmp>0) $cmp=-1;
			if ($args[$i]='tema' && $cmp=0) $cmp=1;
			$i++; 
        } 

        return $cmp; 

    }); 

    return $array; 

} 



//----------------------------------------------
function temasort($a, $b) {
  //$a = $a['skaits'];
 // $b = $b['skaits'];
  if ($a == $b)
   {    
  $c = $a['tema'];
  $d = $b['tema']; 
   return ($c > $d) ? -1 : 1; }
 return 0;
}

function temasort2($a, $b) {
   $c = $a['tema'];
  $d = $b['tema']; 
     return ($c > $d) ? -1 : 1; 

}


function skaitssort($a, $b) {
  $a = $a['skaits'];
  $b = $b['skaits'];
  if ($a == $b)
  {return 0;
  //$k=temasort2($a,$b); return $k;
  }
  return ($a > $b) ? -1 : 1;
}
function temasort3($a, $b) {
    if ($a == $b)
  {return 0;
  
  }
  return ($a >$b) ? -1 : 1;
}

$instanceid=$_SESSION['instance'];//neizmanto
$courseid=$_SESSION['courseid'];

echo "<H3>Optimālās tēmu secības izveide</H3>";
echo "<br>courseid= ".$courseid;
if (user_rights()==1)
{			//siim lomaam ir tiesiibas veikt klasificeesanu
	$secibas = $DB->get_records('v_course_topic_sequence',array('courseid'=>$courseid)); 
	
	if (!empty($secibas))
	{	echo "<br>Kursam ir secības!";
	
$sql="SELECT 
			cts.id, cts.topic_sequence, cts.course_grade
			FROM
			 mdl_v_course_topic_sequence cts
			WHERE
			 cts.courseid = $courseid
			ORDER BY cts.topic_sequence";
$visassecibas=array();			 
$visassecibas = $DB->get_records_sql($sql, null, IGNORE_MISSING);
//echo "<pre>";
//print_r($visassecibas);
//echo "</pre>";
$mas_seciba=array();
$mas_atzimes=array();
	$k=0;$sum=0;
foreach ($visassecibas as $id => $seciba) {
					//echo "id= ".$student->id."<br/>";
					$mas_seciba[$k]=$seciba->topic_sequence;
					$mas_atzimes[$k]=$seciba->course_grade;
					
					$k++;}//cikla aizversana
echo "<pre>";
print_r($mas_seciba);
echo "</pre>";
echo "<pre>";
print_r($mas_atzimes);
echo "</pre>";
					$grupa_secibu=array();
					$grupa_atzimes=array();
					
					$grupa_secibu[0]=$mas_seciba[0];
					$sum=$mas_atzimes[0];
					$count=1;
					$k=0;
					$n_visusecibu=sizeof($mas_seciba);
					
					
					echo "<br>Kopā secību n=".$n_visusecibu;
					for ($i=1;$i<$n_visusecibu;$i++)
					{if (strcmp($grupa_secibu[$k],$mas_seciba[$i])!=0) {
											$k++;
											$grupa_secibu[$k]=$mas_seciba[$i];
											$grupa_atzimes[$k-1]=$sum/$count; 
											$sum=$mas_atzimes[$i];
											$count=1;}
					else {
					//echo "<br>sum= ".$sum;
					//echo "<br>count= ".$count;
					$sum=$sum+$mas_atzimes[$i];$count++;}
					
					}
					//pedejp atziimi
					$grupa_atzimes[$k]=$sum/$count; 
					$n=$k+1;
					echo "<br>Grupu skaits = ".$n;
					
					echo "<pre>";
					print_r($grupa_secibu);
					echo "</pre>";
					echo "<pre>";
					print_r($grupa_atzimes);
					echo "</pre>";
//sameklēt vislielako atzīmi, ja viena tad secība tada, ja vairakas, tad jameklē
					//$max=max($grupa_atzimes);
					//echo "<br>Max atzīme = ".$max;		
					//$maxi = array_keys($grupa_atzimes, max($grupa_atzimes))
					$max=0;$ind=array();
					$ii=0;
					$ind[$ii]=0;
					for($i=0;$i<$n;$i++){
					if ($max<$grupa_atzimes[$i]) {
									$max=$grupa_atzimes[$i];
									$ii=0;
									$ind[$ii]=$i;
									}
					if ($max==$grupa_atzimes[$i]) { $ind[$ii]=$i;$ii++;}}
					echo "<br>Max atzīme = ".$max;
					echo "<br>Max atzīmju grupu skaits = ".$ii;
					if ($ii==1) {$ots=$grupa_secibu[$ind[0]];
								echo "<br>OTS = ".$ots;}
								else{
					
					//-------------------------------------
					echo "<br>Jāmeklē pec algoritma";
					//veido temu secibu pa soliem
					$temu_skaits=substr_count($mas_seciba[0],',')+1;
								
					echo "<br>tēmu skaits 1 secībā = ".$temu_skaits;
					
					for($i=0;$i<$ii;$i++){
					$sarray[$i] = explode(",", $grupa_secibu[$ind[$i]]); }
					//echo "<pre>";	
					//print_r($sarray);
					//echo "</pre>";
					$vermas=array();
					
					$sk=0;
			
	for($j=0;$j<$temu_skaits;$j++)
					{	
					//vermas indeksacija
					$m=0;//$vermas[$i][$m]=$sarray[0][$i];
					$sk=1;
					//$vermas[0][$m]=array("tema"=>$sarray[$i][0], "skaits"=>$sk);
					$vermas[$j][$m]["tema"]=$sarray[0][$j];
					$vermas[$j][$m]["skaits"]=$sk;
					
					for($i=1;$i<$ii;$i++)
					{ //$sk=0;
					//echo "<br>J= ".$j;
					if ($vermas[$j][$m]["tema"]==$sarray[$i][$j]) $sk++;
								else {
								//ja nav vienaadi
								$naktema=$sarray[$i][$j];
								$izmers = $m;
								//paarbaudīt vai jau bijis
								$t=0;
								
								for ($p=0;$p<$izmers;$p++)
									{
									if ($vermas[$j][$p]["tema"]==$naktema) {
										//ja bija tikai skaitiitaaju palielina par 1
										$t=1;
										$vermas[$j][$p]["skaits"]=$vermas[$j][$p]["skaits"]+1;
										break;
										}}
																				
										if ($t==0)
													{
													//if ($m<$temu_skaits) 
													$m++;
													$sk=1;
													$vermas[$j][$m]["tema"]=$naktema;
													$vermas[$j][$m]["skaits"]=$sk;
													}
										
										}//beidz vienadibas paarbaudi
								$vermas[$j][$m]["skaits"]=$sk;
								}	//for pa i
					}//for j
					//echo "<pre>";	
					//print_r($vermas);
					//echo "</pre>";
				
//ots veidosana

//lai nesabojaatu masiivu
$vermas2=$vermas;
$ots='';
//iepriekseja piemera saites
//1:2,3,5;2:3,4,5;3:4,5;4:5,7;5:6,7;6:7;7:5,8,10;8:9,10;9:10;
//sī piemera saites:
//1:2,3;2:3,5;3:4;4:5,7;5:6;6:4,7,8;7:8,9;8:2,9,10;9:10;10:2;
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
			$visassaites=$re->topic_link;
			$skaits=strlen($visassaites);
			echo "<br>visassaites= ".$visassaites;
			for ($i=0;$i<$temu_skaits;$i++)
				{usort($vermas2[$i], "cmp");}
				echo "<br>kartots pec skaita un temas <pre>";	
				print_r($vermas2);
				echo "</pre>";
//--------------------------------------------------------------------------------				
				for($j=0;$j<$temu_skaits;$j++){
				$i=0;$kp=0;$pp=0;
				do{
				//meklēs kuru temu ierakstuiit
				if ($i<sizeof($vermas2[$j]))
						{
						$maxtema=$vermas2[$j][$i]["tema"];
						echo "<br>maxtema cikla sakumaa = ".$maxtema;
						echo "<br>j=".$j;
						$mazakatema=0;
						}
									else
												{	//if (empty($maxtema))
												//mekleet ots vel neierakstiitu mazaako temu
												//echo "<br>Nav maxtemas";
												$temas=explode(',',$ots);
												$sk=sizeof($temas);
												print_r($temas);
												$t=1;
												do{$d=0;
													for($s=0;$s<$sk;$s++)
													{if ($t==$temas[$s]) $d=1;
													//echo "<br>t= ".$t." "."ots[s]= ".$temas[$s];
													}
												$t++;
												}
												while ($d==1);
												$maxtema=$t-1;
										echo "<br>maxtema cita pec numura = ".$maxtema;
										$ots=$ots.$maxtema.',';
										echo "<br>ierakstiita ots tema=".$maxtema;
										$ped_otstema=$maxtema;
										$mazakatema=1;
										
										}
			if ($mazakatema==1) break;
				$n=strlen($ots);
				echo "<br>maxtema= ".$maxtema;
				//atrada
				
				//vai raksta 1.reizi
				if ($n>0 && $mazakatema==0 ){
						$pos = strpos($ots, $maxtema);
						//echo "<br>temas pos= ".$pos;
						if ($pos===false) 
						{//temas nav  ots
						//paarbauda saite no iepriekseja vai ir
								//atrod ieprieksejas temas saites
								$ped_otstema2=$ped_otstema.':';
								$pos2=strpos($visassaites,$ped_otstema2);
								echo "<br>iepriekseja tema= ".$ped_otstema;
								$temas_garums=strlen($ped_otstema);
								//echo "<br>temas_garums= ".$temas_garums;
								$k=0;
								$ntopic='';
								
								for ($i2=$pos2+$temas_garums+1;$i2<$skaits;$i2++)
											{if ($visassaites[$i2]==';') break;
											$ntopic[$k]=$visassaites[$i2]; $k++;
											}
								echo "<br>ieprieksejas temas saites";print_r($ntopic);
								
								//($maxtema - atrasta tema, $ntopic saites no ieprieksejaas)
								//temas veel nebija ots
								//vai ir saite no iepriekseja uz 
								$ntopic2=implode($ntopic);
								$pos3=strpos($ntopic2,$maxtema);
								echo "<br>pos3= ".$pos3;
								if ($pos3!==false)
								{
												//ir saite uz šo temu
												//tad temu ieraksta
												$pp=1;$kp=1;
								} 
								else							
													{//ja nav saites, nem nakamo temu pec biežuma
													$i++;
													echo "<br>Nav saites, jaanem cita tema";
													$kp=0;
													}						
						}//pos
					
						else		{//ja tema bija ots, nem nakamo pec biežuma
								$i++;
								$kp=0;
								}
						}//n
						else {
								//bija ots tuksa, tad ieraksta 1. temu
								
								$pp=1;
								$kp=1;
								} //n
					}while($kp==0);
					//echo "<br>AAAAAAAAAAAAAAAAAAAAAAA";
						if ($pp==1)	
						{//tad ieraksts
							$ots=$ots.$maxtema.',';
							echo "<br>ierakstiita ots tema=".$maxtema;
						$ped_otstema=$maxtema;}
				
				}//for pa j
				
						
						
						
						echo "<br> nex ots= ".$ots;
						//nonemt pedejo komatu
						$ot=rtrim($ots, ",");
						echo "<br> nex ots= ".$ot;


				
					
					
					
				}//else ots
					
					
					
		} else echo "<br>Kursam nav izveidotu tēmu secību!";	
} else echo "<br/>Jums nav tiesību veikt šo darbību!";



/*
				//meklēt stabiņa pēc skaita vislielako
				$p=0;//
				$maxtemuarray=array();
				//$k=1;
			for($j=0;$j<$temu_skaits;$j++){
						$max=$vermas2[$j][0]["skaits"];
						$ind=0;
						$izmers=sizeof($vermas2[$j]);
						//echo "<br>izmers=".$izmers;
			for($i=1;$i<$izmers;$i++){
						if ($max<$vermas2[$j][$i]["skaits"]) {$max= $vermas2[$j][$i]["skaits"];$ind=$i;}
						if ($max==$vermas2[$j][$i]["skaits"] && $vermas2[$j][$ind]["tema"]>$vermas2[$j][$i]["tema"])
															{$max= $vermas2[$j][$i]["skaits"];$ind=$i;}
						}
						//echo "<br>max =".$max;
						//
						//paarbauda vai tada ir ots
						$n=strlen($ots);
						$maxtema=$vermas2[$j][$ind]["tema"];
						$pos = strpos($ots, $maxtema);
						//echo "<br>pos= ".$pos;
						if ($pos==false) 
						{$ots=$ots.$maxtema.',';
						$k=0;}
							else{
							//ja bija, jaameklē citu max
							/*
							$key = array_search($maxtema, $maxtemuarray); // $key = 2;
							if ($key==false) {$maxtemuarray[$p]=$maxtema;$p++;}
							$vermas2[$j][$ind]["skaits"]=0;
							$k=1;$j=$j-1;*/
							//}
						//}//for j
			
	//--------------------------------------------------------		
				//sakartot masiivu pec skaita no lielaka uz mazako , tad varees nemt pec kartas
							/*echo "<br>kartots pec skaita un temas";				
							for ($i=0;$i<$temu_skaits;$i++)
							$mas[$i]=multiSort($vermas2[$i], 'skaits', 'tema'); 
							echo "<pre>";	
							print_r($mas); 
							echo "</pre>";
				for ($i=0;$i<$temu_skaits;$i++)
				{usort($vermas2[$i], "skaitssort");}
				echo "<br>kartots pec skaita <pre>";	
				print_r($vermas2);
				echo "</pre>";*/
				/*
					for ($i=0;$i<$temu_skaits;$i++)
					{usort($vermas2[$i], "temasort");}
					echo "<brkartots pec temas><pre>";	
					print_r($vermas2);
					echo "</pre>";
					*/
					//kartejo reizi
					/*define("CSORT_ASC",     1); 
					define("CSORT_DESC",     -1); 

					function csort_cmp(&$a, &$b) 
					{ 
						global $csort_cmp; 

						if ($a->$csort_cmp['key'] > $b->$csort_cmp['key']) 
							return $csort_cmp['direction']; 

						if ($a->$csort_cmp['key'] < $b->$csort_cmp['key']) 
							return -1 * $csort_cmp['direction']; 

						return 0; 
					} 

					function csort(&$a, $k, $sort_direction=CSORT_ASC) 
					{ 
						global $csort_cmp; 

						$csort_cmp = array( 
							'key'           => $k, 
							'direction'     => $sort_direction 
						); 

						usort($a, "csort_cmp"); 

						unset($csort_cmp); 
					} 
					
					 csort($vermas2, "skaits", CSORT_DESC);
					
					echo "<br>kartots pec skaita<pre>";	
					print_r($vermas2);
					echo "</pre>";
					*/
					//----------------------------------------------------------------

?>