Labdien!

Izmantojiet iespēju atkārtot kursu "Programmēsanas pamati C++ I" un papildus iegūt vienu balli šī kursa II daļai.

Adaptīvas sistēmas izveides nolūkos, lūdzu notestējiet kursu "Programmēšanas pamati (adaptīvais kurss)".
Sistēmas lietošanas pamācība:
1) Pirms sākt kursa apgūšanu, lūdzu izpildiet testus blokā "Learning Data" kreisajā pusē. Obligātie testi ir "Course Data" un "VARK3". Pārējie testi nav obligāti, taču pildīt var.
2) Sākot apmācību, varat izvēlēties tēmu secību, t.i., kā sistēmai piedāvāt nākamo apgūstāmo tēmu un tēmu secību var mainīt visa apmācības procesa laikā.
3) Studenta tēmu secība tiek veidota, balstoties uz saitēm starp tēmām, tāpēc sistēma var piedāvāt vairākas saites vienlaicīgi. Jums jāizvēlas nākamā tēma un sistēma pāriet uz šo tēmu. 
4) Tēmas teoretiskajā daļā ir faili, kas bija izmantoti mācību laikā. Praktiska daļa tikai sevis pārbaudei. Vertēsanas daļā ir tests, kas sastāv no 5 jautājumiem.
5) Izpildot testu sistēma piedāvās nākamo tēmu.
6) Nākamā tēma būs pieejama, ja testā tiks iegūta atzīme, kas ir 4 vai vairāk. Tad vēlreiz ieejot tikko apgūtajā (pēdējā) tēmā varēs izvēlēties nākamo temu.
7) Pa apgūtām tēmām var brīvi pārvietoties.
8) Pēc visu tēmu apguves, pārejot uz pēdējo apgūto tēmu, parādīsies kursā iegūtā atzīme.

Ļoti atvainojos, bet kursa testēšanu vajadzētu veikt līdz pirmdienai (07.02.2016 23:59). Tikai tiem, kas to izdarīs būs papildus punkts.
Kursu varēs aprobet arī velak, bet bez papildus bonusa.
Ar cieņu, Vija Vagale