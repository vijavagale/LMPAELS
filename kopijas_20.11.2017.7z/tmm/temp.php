<?php
public function next_topic(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
//panem pedejo izveeli	
$tchoice=$this->last_number($lerndata->topic_choices_variants);
//echo "<br/>esosa temu izvele=".$tchoice;
//panemt pedejo apguuto temu
$ped_tema=$this->last_number($lerndata->topic_sequence);
//echo "<br>ped tema=".$ped_tema;
	//ja skolotaja seciiba izveleta
	if ($tchoice==1){
			$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
			$teacher=$re->teacher_topic_sequence;
					//meklee nakošo temu
					$pos=strpos($teacher,$ped_tema);
					$skaits=strlen($re->teacher_topic_sequence);
					//echo "<br>skaits= ".$skaits;
					$j=0;
					$rez=array();
					for ($i=$pos+2;$i<$skaits && $teacher[$i]!=',';$i++)   
							{$rez[$j]=$teacher[$i];$j++;}
					$next_topic=$rez[0];
					//echo "<br/>nak tema=".$next_topic;
				}					
	if ($tchoice==2){
					$next_topic=$this->temas_pec_saites();
					}
	if ($tchoice==3){
			//ja optimala seciiba
			$re = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
			$optimal=$re->user_ots;
					//meklee nakošo temu
					$pos=strpos($optimal,$ped_tema);
					$skaits=strlen($optimal);
					$j=0;
					$rez=array();
					for ($i=$pos+2;$i<$skaits && $optimal[$i]!=',';$i++)   
							{$rez[$j]=$optimal[$i];$j++;}
					$next_topic=$rez[0];
					//echo "<br/>nak tema=".$next_topic;
				}
return $next_topic;
}
//-------------------------------------------------------------------fja
public function write_topic_sequence($displaysection){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;
//ierakstiit tabulaa next topic
	$v=0;
	//panemt kada seciiba izveeleta, ja 1,3 tad raksta, 
	$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$tchoice=$this->last_number($lerndata->topic_choices_variants);
	if ($tchoice==1 || $tchoice==3 )
	{	$v=1;
	$next_topic=$this->next_topic();
	//viena vai vairakas tēmas //ja next topic satur komatu, tad vairaki
	/*
	$sk_skaits=substr_count($next_topic,',')+1;
	if ($sk_skaits==1) $ntopic=$next_topic; 
				else {//echo "<br>Nakoso temu ir vairaak par 1 t.i.= ".$sk_skaits;
			}
	}
*/
	if ($tchoice==2 && $this->vai_si_tema_ierakstiita($displaysection)==0) {$v=1;$ntopic=$displaysection;}
	//if ($displaysection==1) break;	
	
	if ($v==1){
	$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
	$alltopic=$lerndata->topic_sequence.','.$ntopic;
						//update record
						$record2 = new stdclass;
						$record2->id=$lerndata->id;
						$record2->topic_sequence=$alltopic;
						$sql = $DB->update_record('v_user_learning_data', $record2);}


}
public function tema_pec_secibu_starpiba(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

//ta ir nakosa tema

//panemt tcv pedejo u priekspedejo
$tsp=$this->tsecibas_variants_pedejais;
$tspp=$this->last_number($tsp);
//ieguut vajadziigaas seciibas
$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));	
	$tts=$re->teacher_topic_sequence;
	$ts=$lerndata->topic_sequence;
	$ots=$lerndata->user_ots;
	$st=$this->temas_pec_saites();
	
	$ttsarray = explode(",", $tts); $ttsskaits=sizeof($tts);
	$tsarray = explode(",", $ts); $tsskaits=sizeof($ts);
	$otsarray = explode(",", $ots); $otsskaits=sizeof($ots);
//fikseet parejas
if ($tsp==1 and ($tspp==2 or $tspp==3)) {
			$rez=array();$a=0;
			for ($i=0;$i<$ttsskaits;$i++)
			{	$k=0;
				for ($j=0;$j<$tsskaits;$j++)
					if ($ttsarray[$i]==$tsarray[$j]) $k=1;
				if ($k==0) 	{$rez[$a]=$ttsarray[$i];$a++;}
			}
		}
if ($tsp==3 and ($tspp==1 or $tspp==2)) {
			$rez=array();$a=0;
			for ($i=0;$i<$otsskaits;$i++)
			{	$k=0;
				for ($j=0;$j<$tsskaits;$j++)
					if ($otsarray[$i]==$tsarray[$j]) $k=1;
				if ($k==0) 	{$rez[$a]=$otsarray[$i];$a++;}
			}
		}
$n=sizeof($rez);
if ($n>0){
		$ts=$ts.','.$rez[0];	
		}		
return $ts;
}
?>