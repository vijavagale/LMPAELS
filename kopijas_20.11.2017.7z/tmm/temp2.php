<?php
public function temas_apgutas_plus_saites(){
//apguutās+jaunā tema
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$ts=$lerndata->topic_sequence;
$st=$this->temas_pec_saites();
echo "<br>Fjas----- temas pec saites rezultāts(94)=";
print_r($st);
if (empty($st)){
//echo "<br>meklee atlikusas veel neapguutās temas";
$ierts=$this->ierakstito_temu_seciba();
$iertsarray = explode(",", $ierts);
$skaits1=sizeof($iertarray);
echo "<br>skaits1=".$skaits1;
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
			$tts=$re->teacher_topic_sequence;
			$ttsarray = explode(",", $tts);
			$skaits2=sizeof($ttsarray);
			echo "<br>skaits2=".$skaits2;
			$st=array();$a=0;
			for ($i=0;$i<$skaits2;$i++)
			{	$k=0;
				for ($j=0;$j<$skaits1;$j++)
					if ($ttsarray[$i]==$iertsarray[$j]) $k=1;
				if ($k==0) 	{$st[$a]=$ttsarray[$i];$a++;}
			}
}
//jaunaa izveidota masiiva izmērs ir
//$n1=$a-1;
//echo "<br>n1=".$n1;
$n2=sizeof($st);
echo "<br>n2=".$n2;
if ($n2>0){
		for ($i=0;$i<$n2;$i++)
		$ts.=','.$st[$i];	}
	return $ts;
}
//-------------------------------------------------------------------fja
public function temas_pec_saites(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;	

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$ped_tema=$this->last_number($lerndata->topic_sequence);
$re = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
			$visassaites=$re->topic_link;
			$skaits=strlen($visassaites);
			//echo "<br>fja-------------- temas pec saites";
			$st=$ped_tema.':';
			//echo "<br>st=".$st;
			$pos=strpos($visassaites,$st);
			
			//echo "<br> visas saites=".$visassaites;
			//echo "<br>no kuras saakas pos= ".$pos.'<br>';
			$k=0;
			$next_topic="";
			for ($i=$pos+2;$i<$skaits;$i++)
				{if ($visassaites[$i]==';') break;
				$next_topic[$k]=$visassaites[$i]; $k++;
				}
			//print_r($next_topic);
return $next_topic;
}
public function next_topic(){
global $USER, $DB;
$tmminstance=$_SESSION['tmminstance'];
$courseid=$_SESSION['courseid'];	
$userid=$USER->id;

$lerndata = $DB->get_record('v_user_learning_data', array('userid'=>$userid,'courseid'=>$courseid));
$visivarianti=$lerndata->topic_choices_variants;
$tsp=$this->last_number($visivarianti);
$ko=','.$tsp;
$tsvbezpedeja=str_replace($ko,'',$visivarianti);
$tspp=$this->last_number($tsvbezpedeja);
	$param = $DB->get_record('v_course_teaching_parametrs',array('courseid'=>$courseid));
	$tts=$param->teacher_topic_sequence;
		//echo "Teacher topic_sequence=".$param->teacher_topic_sequence;
		//print_r($tts);
	$ts=$lerndata->topic_sequence;
	$ots=$lerndata->user_ots;
	//$st=$this->temas_pec_saites();
	
	$ptema=$this->last_number($ts);
	
	//$ttsskaits=strlen($param->teacher_topic_sequence);
	//$tsskaits=strlen($lerndata->topic_sequence);
	//$otsskaits=strlen($lerndata->user_ots);
	$ttsarray = explode(",", $tts); 
	$tsarray = explode(",", $ts); 
	$otsarray = explode(",", $ots);
	
	$ttsskaits=sizeof($ttsarray);
	$tsskaits=sizeof($tsarray);
	$otsskaits=sizeof($otsarray);
//fikseet parejas
	$rez=array();
	//echo "<br>tts";print_r($tts);
	//echo "<br>ptema";print_r($ptema);
	//if ($displaysection==$ptema)
	
	if ($tsp==1 and ($tspp==1 or empty($tspp))){
					for ($i=0;$i<$ttsskaits && $ttsarray[$i]!=$ptema;$i++);   
					$next_topic=$ttsarray[$i+1];
					echo "<br>nexttopic=".$next_topic;
				}			
	if (($tsp==2 and $tspp==2) or ($tsp==2 and empty($tspp)) or 
		($tsp==2 and $tspp==1)){
					$next_topic=$this->temas_pec_saites();
				}
	if ($tsp==3 and ($tspp==3 or empty($tspp))){
					for ($i=0;$i<$otsskaits && $otsarray[$i]!=$ptema;$i++);   
					$next_topic=$otsarray[$i+1];
				}
	if ($tsp==1 and ($tspp==2 or $tspp==3)) {
	//varbuut kluda
					$b=0;$a=0;
					for ($i=0;$i<$ttsskaits&& $b==0;$i++)
					{	$k=0;
						for ($j=0;$j<$tsskaits;$j++)
							if ($ttsarray[$i]==$tsarray[$j]) $k=1;
						if ($k==0) 	{$rez[$a]=$ttsarray[$i];$a++;$b=1;}
						
					}$next_topic=$rez[0];
				}
	if ($tsp==3 and ($tspp==1 or $tspp==2)) {
					
					//echo "<br>ots=".$ots;
					//echo "<br>ts=".$ts;
					//echo "<br>otsskaits=".$otsskaits;
					//echo "<br>tsskaits=".$tsskaits;
					$b=0;$a=0;
					for ($i=0;$i<$otsskaits&& $b==0;$i++)
					{	$k=0;
						for ($j=0;$j<$tsskaits;$j++)
							{if ($otsarray[$i]==$tsarray[$j]) $k=1;
							//echo "<br>otsarray[".$i."]= ".$otsarray[$i];
							//echo "<br>tsarray[".$j."]= ".$tsarray[$j];
							}
						if ($k==0) 	{$rez[$a]=$otsarray[$i];$a++;$b=1;
						//echo "<br>rez[".($a-1)."]= ".$rez[$a-1];
						}
					}$next_topic=$rez[0];
				}			
return $next_topic;
}

?>