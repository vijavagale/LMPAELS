function sequenceapstrade(list) {
//window.alert(5 + 6);
if (list.options[list.selectedIndex].index>0)
{
//datums=list.options[list.selectedIndex].value;
document.getElementById('dlevel').style.height="29px";
document.getElementById('dlevel').style.fontSize="10pt";
document.getElementById("dlevel").style.visibility = "visible";
document.getElementById("go").style.visibility = "visible";
document.getElementById("al").style.visibility = "visible";
//document.getElementById("form2").style.visibility = "visible";
//document.getElementById("myDiv").innerHTML=datums;
}
else {
document.getElementById('dlevel').style.height="29px";
document.getElementById('dlevel').style.fontSize="10pt";
document.getElementById("dlevel").style.visibility = "hidden";
document.getElementById("go").style.visibility = "hidden";
document.getElementById("al").style.visibility = "hidden";
//document.getElementById("form2").style.visibility = "hidden";
}}

function goapstrade(list) {
//window.alert(5 + 6);
if (list.options[list.selectedIndex].index>0)
{
//datums=list.options[list.selectedIndex].value;
//document.getElementById('izdlevel').style.height="29px";
//document.getElementById('izdlevel').style.fontSize="10pt";
document.getElementById("izdlevel").style.visibility = "visible";
//document.getElementById("go").style.visibility = "visible";
//document.getElementById("form2").style.visibility = "visible";
//document.getElementById("myDiv").innerHTML=datums;
}
else {
//document.getElementById('izdlevel').style.height="29px";
//document.getElementById('izdlevel').style.fontSize="10pt";
document.getElementById("dlevel").style.visibility = "hidden";
//document.getElementById("go").style.visibility = "hidden";
//document.getElementById("form2").style.visibility = "hidden";
}}