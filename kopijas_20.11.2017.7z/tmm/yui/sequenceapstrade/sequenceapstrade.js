YUI.add('moodle-block_tmm-sequenceapstrade', function(Y) {
window.alert(5 + 6);
if (Y.list.options[Y.list.selectedIndex].index>0)
{
//datums=list.options[list.selectedIndex].value;
document.getElementById("dlevel").style.visibility = "visible";
document.getElementById("go").style.visibility = "visible";
//document.getElementById("myDiv").innerHTML=datums;
}
else {

document.getElementById("dlevel").style.visibility = "hidden";
document.getElementById("go").style.visibility = "hidden";
}
}
/*
function sequenceapstrade(list) {
window.alert(5 + 6);
if (list.options[list.selectedIndex].index>0)
{
//datums=list.options[list.selectedIndex].value;
document.getElementById("dlevel").style.visibility = "visible";
document.getElementById("go").style.visibility = "visible";
//document.getElementById("myDiv").innerHTML=datums;
}
else {

document.getElementById("dlevel").style.visibility = "hidden";
document.getElementById("go").style.visibility = "hidden";
}
}

*/